"""Excel worksheet-name sanitising and internal hyperlink helpers."""
from __future__ import annotations

import re
from typing import Dict, Hashable, Iterable

MAX_SHEET_NAME = 31
MAX_CELL_CHARS = 32767
_INVALID = re.compile(r"[\[\]:*?/\\\x00-\x1f]")


def sanitize_sheet_name(name: str) -> str:
    cleaned = _INVALID.sub("_", name).strip().strip("'").strip()
    return cleaned or "Sheet"


class SheetNameRegistry:
    """Assigns unique, valid worksheet names and remembers key -> name.

    Excel names are case-insensitive, limited to 31 characters, may not
    contain []:*?/\\ and may not begin or end with an apostrophe.
    """

    def __init__(self, reserved: Iterable[str] = ()):
        self._used = {n.upper() for n in reserved} | {"HISTORY"}
        self.mapping: Dict[Hashable, str] = {}

    def assign(self, key: Hashable, desired: str) -> str:
        if key in self.mapping:
            return self.mapping[key]
        base = sanitize_sheet_name(desired)
        if len(base) <= MAX_SHEET_NAME and base.upper() not in self._used:
            name = base
        else:
            n = 1
            while True:
                suffix = f"_{n:02d}"
                stem = base[:MAX_SHEET_NAME - len(suffix)].rstrip().rstrip("'")
                name = f"{stem}{suffix}"
                if name.upper() not in self._used:
                    break
                n += 1
        self._used.add(name.upper())
        self.mapping[key] = name
        return name


def internal_link(sheet_name: str, cell: str = "A1") -> str:
    return f"internal:'{sheet_name.replace(chr(39), chr(39) * 2)}'!{cell}"


def clip(text: str) -> str:
    if len(text) <= MAX_CELL_CHARS:
        return text
    return text[:MAX_CELL_CHARS - 20] + " ...[truncated]"
