"""Application logging setup."""
from __future__ import annotations

import logging
from pathlib import Path

_FORMAT = "%(asctime)s %(levelname)-7s %(name)s: %(message)s"


def setup_logging(log_path: Path, level: str = "INFO", console_level: str = "WARNING") -> Path:
    """Log to ``log_path`` (overwritten each run) and to the console."""
    log_path.parent.mkdir(parents=True, exist_ok=True)
    root = logging.getLogger()
    for handler in list(root.handlers):
        root.removeHandler(handler)
        handler.close()
    file_level = getattr(logging, level.upper(), logging.INFO)
    con_level = getattr(logging, console_level.upper(), logging.WARNING)
    root.setLevel(min(file_level, con_level))

    file_handler = logging.FileHandler(log_path, mode="w", encoding="utf-8")
    file_handler.setLevel(file_level)
    file_handler.setFormatter(logging.Formatter(_FORMAT))
    root.addHandler(file_handler)

    console = logging.StreamHandler()
    console.setLevel(con_level)
    console.setFormatter(logging.Formatter("%(levelname)s: %(message)s"))
    root.addHandler(console)
    return log_path
