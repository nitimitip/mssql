"""Optional folder-based schema catalogue: tables, columns, indexes, partitioning.

Reads CREATE TABLE / CREATE INDEX / ALTER TABLE ... ADD CONSTRAINT /
CREATE PARTITION SCHEME scripts (for example scripted from SSMS) plus an
optional ``table_metadata.csv`` with size / growth / retention facts.

The scripts are tokenised as untrusted text and never executed. Anything
not understood is skipped with a warning; nothing is guessed. When a table
has no definition here, the performance report says "insufficient
information" instead of claiming an index is missing.
"""
from __future__ import annotations

import csv
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

from models.common import ObjectRef

from .file_reader import FileReadError, read_sql_file
from .parser import render_tokens
from .tokenizer import EOF, GO, NUMBER, OP, QIDENT, WORD, Token, TokenizeError, tokenize

log = logging.getLogger(__name__)

METADATA_FILE = "table_metadata.csv"
METADATA_FIELDS = ("row_count", "data_size_mb", "row_distribution", "growth",
                   "retention_policy", "partitioning", "notes")

_FIXED_BYTES = {
    "TINYINT": 1, "SMALLINT": 2, "INT": 4, "BIGINT": 8, "BIT": 1, "DATE": 3, "TIME": 5,
    "DATETIME": 8, "DATETIME2": 8, "SMALLDATETIME": 4, "DATETIMEOFFSET": 10,
    "UNIQUEIDENTIFIER": 16, "MONEY": 8, "SMALLMONEY": 4, "FLOAT": 8, "REAL": 4,
    "ROWVERSION": 8, "TIMESTAMP": 8, "SYSNAME": 256,
}
_LOB_TYPES = {"TEXT", "NTEXT", "IMAGE", "XML", "GEOGRAPHY", "GEOMETRY", "SQL_VARIANT",
              "HIERARCHYID"}
_DATE_TYPES = {"DATE", "DATETIME", "DATETIME2", "SMALLDATETIME", "DATETIMEOFFSET"}


@dataclass
class ColumnDef:
    name: str
    type_name: str = ""
    type_text: str = ""
    max_bytes: Optional[int] = None    # None = unknown or LOB
    lob: bool = False
    nullable: Optional[bool] = None
    computed: bool = False
    type_args: List[str] = field(default_factory=list)   # e.g. ['2'], ['MAX'], ['10', '2']

    @property
    def is_date(self) -> bool:
        return self.type_name in _DATE_TYPES


@dataclass
class IndexDef:
    name: str
    keys: List[str] = field(default_factory=list)
    includes: List[str] = field(default_factory=list)
    unique: bool = False
    clustered: bool = False
    primary_key: bool = False
    filter: str = ""
    kind: str = "ROWSTORE"             # ROWSTORE | COLUMNSTORE
    partition_column: str = ""
    source: str = ""

    @property
    def description(self) -> str:
        flags = []
        if self.primary_key:
            flags.append("PRIMARY KEY")
        elif self.unique:
            flags.append("UNIQUE")
        flags.append("CLUSTERED" if self.clustered else "NONCLUSTERED")
        if self.kind == "COLUMNSTORE":
            flags.append("COLUMNSTORE")
        text = f"{self.name} [{' '.join(flags)}] ({', '.join(self.keys)})"
        if self.includes:
            text += f" INCLUDE ({', '.join(self.includes)})"
        if self.filter:
            text += f" WHERE {self.filter}"
        return text


@dataclass
class TableDef:
    name: str
    schema: str = ""
    database: str = ""
    columns: Dict[str, ColumnDef] = field(default_factory=dict)
    indexes: List[IndexDef] = field(default_factory=list)
    partition_scheme: str = ""
    partition_column: str = ""
    defined: bool = False              # a CREATE TABLE was seen (not only indexes)
    source_files: List[str] = field(default_factory=list)
    metadata: Dict[str, str] = field(default_factory=dict)

    @property
    def display_name(self) -> str:
        return ".".join(p for p in (self.database, self.schema, self.name) if p)

    def column(self, name: str) -> Optional[ColumnDef]:
        return self.columns.get(name.upper())

    @property
    def clustered_index(self) -> Optional[IndexDef]:
        return next((i for i in self.indexes if i.clustered), None)

    @property
    def unique_indexes(self) -> List[IndexDef]:
        return [i for i in self.indexes if i.unique and not i.filter and i.kind == "ROWSTORE"]


class SchemaCatalog:
    def __init__(self, default_schema: str = "dbo"):
        self.default_schema = default_schema
        self.tables: Dict[Tuple[str, str, str], TableDef] = {}
        self.partition_schemes: Dict[str, str] = {}
        self.warnings: List[str] = []
        self.files_read: List[str] = []
        self.metadata_file: str = ""

    # ------------------------------------------------------------ identity
    def _key(self, database: Optional[str], schema: Optional[str], name: str):
        return ((database or "").upper(), (schema or self.default_schema).upper(), name.upper())

    def lookup(self, obj: ObjectRef) -> Optional[TableDef]:
        table = self.tables.get(self._key(obj.database, obj.schema, obj.name))
        if table is None and obj.database:
            # a definition scripted without the database part still matches
            table = self.tables.get(self._key(None, obj.schema, obj.name))
        return table

    def table(self, parts: List[str], source: str) -> TableDef:
        padded = [""] * (3 - min(len(parts), 3)) + parts[-3:]
        database, schema, name = padded
        key = self._key(database, schema, name)
        table = self.tables.get(key)
        if table is None:
            table = TableDef(name=name, schema=schema or self.default_schema, database=database)
            self.tables[key] = table
        if source and source not in table.source_files:
            table.source_files.append(source)
        return table

    @property
    def table_count(self) -> int:
        return sum(1 for t in self.tables.values() if t.defined)

    @property
    def index_count(self) -> int:
        return sum(len(t.indexes) for t in self.tables.values())


# ---------------------------------------------------------------- DDL reader

class _DdlError(Exception):
    pass


class _Reader:
    def __init__(self, tokens: List[Token], text: str, source: str, catalog: SchemaCatalog):
        self.t = tokens
        self.text = text
        self.i = 0
        self.source = source
        self.cat = catalog

    def peek(self, k: int = 0) -> Token:
        j = self.i + k
        return self.t[j] if j < len(self.t) else self.t[-1]

    def kw(self, *words: str, k: int = 0) -> bool:
        tok = self.peek(k)
        return tok.kind == WORD and tok.upper in words

    def op(self, value: str, k: int = 0) -> bool:
        tok = self.peek(k)
        return tok.kind == OP and tok.value == value

    def advance(self) -> Token:
        tok = self.peek()
        if self.i < len(self.t) - 1:
            self.i += 1
        return tok

    def accept_kw(self, *words: str) -> bool:
        if self.kw(*words):
            self.advance()
            return True
        return False

    def expect_op(self, value: str) -> None:
        if not self.op(value):
            raise _DdlError(f"expected '{value}' at line {self.peek().line}")
        self.advance()

    def ident(self) -> str:
        tok = self.peek()
        if tok.kind not in (WORD, QIDENT):
            raise _DdlError(f"expected a name at line {tok.line}")
        self.advance()
        return tok.value

    def name(self) -> List[str]:
        parts = [self.ident()]
        while self.op("."):
            self.advance()
            if self.op("."):
                parts.append("")
                continue
            parts.append(self.ident())
        return parts

    def at_end(self) -> bool:
        return self.peek().kind in (EOF, GO)

    def skip_parens(self) -> None:
        self.expect_op("(")
        depth = 1
        while depth:
            if self.at_end():
                raise _DdlError("unbalanced parentheses")
            tok = self.advance()
            if tok.kind == OP and tok.value == "(":
                depth += 1
            elif tok.kind == OP and tok.value == ")":
                depth -= 1

    def column_list(self, allow_order: bool = True) -> List[str]:
        self.expect_op("(")
        cols: List[str] = []
        while True:
            cols.append(self.ident())
            if allow_order:
                self.accept_kw("ASC", "DESC")
            if self.op(","):
                self.advance()
                continue
            self.expect_op(")")
            return cols

    # ------------------------------------------------------------ driver
    def run(self) -> None:
        while not self.peek().kind == EOF:
            tok = self.peek()
            if tok.kind == WORD and tok.upper in ("CREATE", "ALTER"):
                start = self.i
                try:
                    self.statement()
                except _DdlError as exc:
                    self.cat.warnings.append(f"{self.source} line {tok.line}: {exc}; statement skipped")
                    self.i = start + 1
                if self.i == start:
                    self.advance()
            else:
                self.advance()

    def statement(self) -> None:
        if self.kw("CREATE") and self.kw("TABLE", k=1):
            self.advance()
            self.advance()
            self.create_table()
        elif self.kw("CREATE") and self.kw("PARTITION", k=1) and self.kw("SCHEME", k=2):
            for _ in range(3):
                self.advance()
            scheme = self.ident()
            self.cat.partition_schemes[scheme.upper()] = scheme
        elif self.kw("CREATE") and self._index_ahead():
            self.advance()
            self.create_index()
        elif self.kw("ALTER") and self.kw("TABLE", k=1):
            self.advance()
            self.advance()
            self.alter_table()
        else:
            self.advance()

    def _index_ahead(self) -> bool:
        k = 1
        while self.kw("UNIQUE", "CLUSTERED", "NONCLUSTERED", "COLUMNSTORE", k=k):
            k += 1
        return self.kw("INDEX", k=k)

    # ------------------------------------------------------------ CREATE TABLE
    def create_table(self) -> None:
        parts = self.name()
        if parts[-1].startswith(("#", "@")):
            return                                   # temp tables are not catalogued
        table = self.cat.table(parts, self.source)
        table.defined = True
        self.expect_op("(")
        while True:
            self.table_item(table)
            if self.op(","):
                self.advance()
                continue
            self.expect_op(")")
            break
        self.storage_clause(table, None)

    def table_item(self, table: TableDef) -> None:
        cname = ""
        if self.accept_kw("CONSTRAINT"):
            cname = self.ident()
        if self.kw("PRIMARY", "UNIQUE"):
            table.indexes.append(self.key_constraint(cname or f"PK/UQ on {table.name}", table))
            return
        if self.kw("INDEX"):
            self.advance()
            idx = IndexDef(name=self.ident(), source=self.source)
            self.index_flags(idx)
            idx.keys = self.column_list()
            self.index_tail(idx, table)
            table.indexes.append(idx)
            return
        if self.kw("FOREIGN", "CHECK", "PERIOD", "CONNECTION", "DEFAULT"):
            self.skip_item()
            return
        # column definition
        col = ColumnDef(name=self.ident())
        if self.accept_kw("AS"):
            col.computed = True
            self.skip_item(col, table)
        else:
            self.data_type(col)
            self.skip_item(col, table)
        table.columns[col.name.upper()] = col

    def skip_item(self, col: Optional[ColumnDef] = None, table: Optional[TableDef] = None) -> None:
        """Skip to the next ',' or ')' at this level, noting inline NULL / keys."""
        depth = 0
        while True:
            if self.at_end():
                raise _DdlError("unterminated table definition")
            tok = self.peek()
            if tok.kind == OP and tok.value == "(":
                depth += 1
            elif tok.kind == OP and tok.value == ")":
                if depth == 0:
                    return
                depth -= 1
            elif tok.kind == OP and tok.value == "," and depth == 0:
                return
            elif col is not None and depth == 0 and tok.kind == WORD:
                if tok.upper == "NOT" and self.kw("NULL", k=1):
                    col.nullable = False
                elif tok.upper == "NULL" and col.nullable is None:
                    col.nullable = True
                elif tok.upper in ("PRIMARY", "UNIQUE") and table is not None:
                    pk = tok.upper == "PRIMARY"
                    self.advance()
                    if pk:
                        self.accept_kw("KEY")
                    clustered = pk
                    if self.accept_kw("CLUSTERED"):
                        clustered = True
                    elif self.accept_kw("NONCLUSTERED"):
                        clustered = False
                    table.indexes.append(IndexDef(
                        name=f"{'PK' if pk else 'UQ'} on {table.name}.{col.name} (inline)",
                        keys=[col.name], unique=True, clustered=clustered, primary_key=pk,
                        source=self.source))
                    if pk:
                        col.nullable = False
                    continue
            self.advance()

    def data_type(self, col: ColumnDef) -> None:
        parts = self.name()
        type_name = parts[-1].upper()
        args: List[str] = []
        if self.op("("):
            self.advance()
            while not self.op(")"):
                if self.at_end():
                    raise _DdlError("unterminated data type")
                tok = self.advance()
                if tok.kind in (NUMBER, WORD):
                    args.append(tok.value.upper())
            self.advance()
        col.type_name = type_name
        col.type_args = args
        col.type_text = parts[-1] + (f"({','.join(args)})" if args else "")
        col.lob = type_name in _LOB_TYPES or "MAX" in args
        if col.lob:
            return
        if type_name in _FIXED_BYTES:
            col.max_bytes = _FIXED_BYTES[type_name]
        elif type_name in ("DECIMAL", "NUMERIC"):
            precision = int(args[0]) if args and args[0].isdigit() else 18
            col.max_bytes = 5 if precision <= 9 else 9 if precision <= 19 else 13 if precision <= 28 else 17
        elif type_name in ("CHAR", "VARCHAR", "BINARY", "VARBINARY"):
            col.max_bytes = int(args[0]) if args and args[0].isdigit() else 1
        elif type_name in ("NCHAR", "NVARCHAR"):
            col.max_bytes = 2 * (int(args[0]) if args and args[0].isdigit() else 1)

    def key_constraint(self, name: str, table: TableDef) -> IndexDef:
        pk = self.kw("PRIMARY")
        self.advance()
        if pk:
            self.accept_kw("KEY")
        idx = IndexDef(name=name, unique=True, primary_key=pk, clustered=pk, source=self.source)
        if self.accept_kw("CLUSTERED"):
            idx.clustered = True
        elif self.accept_kw("NONCLUSTERED"):
            idx.clustered = False
        idx.keys = self.column_list()
        self.index_tail(idx, table, inside_table=True)
        return idx

    # ------------------------------------------------------------ indexes
    def index_flags(self, idx: IndexDef) -> None:
        while True:
            if self.accept_kw("UNIQUE"):
                idx.unique = True
            elif self.accept_kw("CLUSTERED"):
                idx.clustered = True
            elif self.accept_kw("NONCLUSTERED"):
                idx.clustered = False
            elif self.accept_kw("COLUMNSTORE"):
                idx.kind = "COLUMNSTORE"
            else:
                return

    def create_index(self) -> None:
        idx = IndexDef(name="", source=self.source)
        self.index_flags(idx)
        if not self.accept_kw("INDEX"):
            raise _DdlError("expected INDEX")
        idx.name = self.ident()
        if not self.accept_kw("ON"):
            raise _DdlError("expected ON")
        parts = self.name()
        if parts[-1].startswith(("#", "@")):
            return                                   # temp-table indexes are not catalogued
        table = self.cat.table(parts, self.source)
        if self.op("("):
            idx.keys = self.column_list()
        self.index_tail(idx, table)
        table.indexes.append(idx)

    def index_tail(self, idx: IndexDef, table: TableDef, inside_table: bool = False) -> None:
        if self.accept_kw("INCLUDE"):
            idx.includes = self.column_list(allow_order=False)
        if self.kw("WHERE"):
            self.advance()
            start = self.i
            depth = 0
            while not self.at_end():
                tok = self.peek()
                if tok.kind == OP and tok.value == "(":
                    depth += 1
                elif tok.kind == OP and tok.value == ")":
                    if depth == 0:
                        break
                    depth -= 1
                elif depth == 0 and (tok.kind == OP and tok.value in (";", ",")
                                     or tok.kind == WORD and tok.upper in ("WITH", "ON", "CREATE",
                                                                           "ALTER")):
                    break
                self.advance()
            idx.filter = render_tokens(self.t, self.text, (start, self.i))
        self.storage_clause(table, idx, inside_table)

    def storage_clause(self, table: TableDef, idx: Optional[IndexDef],
                       inside_table: bool = False) -> None:
        while True:
            if self.kw("WITH") and self.op("(", k=1):
                self.advance()
                self.skip_parens()
            elif self.kw("ON"):
                self.advance()
                target = self.ident()
                if self.op("("):
                    self.advance()
                    column = self.ident()
                    self.expect_op(")")
                    if idx is None:
                        table.partition_scheme, table.partition_column = target, column
                    else:
                        idx.partition_column = column
                        if idx.clustered and not table.partition_column:
                            table.partition_scheme, table.partition_column = target, column
            elif self.kw("TEXTIMAGE_ON", "FILESTREAM_ON"):
                self.advance()
                self.ident()
            else:
                return

    # ------------------------------------------------------------ ALTER TABLE
    def alter_table(self) -> None:
        table = self.cat.table(self.name(), self.source)
        self.accept_kw("WITH")
        self.accept_kw("CHECK", "NOCHECK")
        if not self.accept_kw("ADD"):
            return
        while True:
            name = ""
            if self.accept_kw("CONSTRAINT"):
                name = self.ident()
            if self.kw("PRIMARY", "UNIQUE"):
                table.indexes.append(self.key_constraint(name or f"PK/UQ on {table.name}", table))
            else:
                return
            if not self.op(","):
                return
            self.advance()


def _read_metadata(path: Path, catalog: SchemaCatalog) -> None:
    try:
        with path.open(newline="", encoding="utf-8-sig") as handle:
            reader = csv.DictReader(handle)
            if not reader.fieldnames or "table" not in [f.strip().lower() for f in reader.fieldnames]:
                catalog.warnings.append(f"{path.name}: missing 'table' column; file ignored")
                return
            for row in reader:
                row = {(k or "").strip().lower(): (v or "").strip() for k, v in row.items()}
                name = row.get("table", "")
                if not name:
                    continue
                parts = [p.strip("[]") for p in name.split(".")]
                table = catalog.table(parts, path.name)
                for key in METADATA_FIELDS:
                    if row.get(key):
                        table.metadata[key] = row[key]
        catalog.metadata_file = path.name
    except (OSError, csv.Error, UnicodeDecodeError) as exc:
        catalog.warnings.append(f"{path.name}: could not be read ({exc})")


def load_schema_catalog(directory: Optional[Path], extensions: Iterable[str] = (".sql",),
                        default_schema: str = "dbo") -> Optional[SchemaCatalog]:
    """Read every DDL script under ``directory``; None when no folder is configured."""
    if directory is None:
        return None
    catalog = SchemaCatalog(default_schema)
    if not directory.is_dir():
        catalog.warnings.append(f"Schema folder not found: {directory}")
        return catalog
    exts = {e.lower() for e in extensions}
    for path in sorted(directory.rglob("*")):
        if not path.is_file():
            continue
        if path.name.lower() == METADATA_FILE:
            _read_metadata(path, catalog)
            continue
        if path.suffix.lower() not in exts:
            continue
        display = path.relative_to(directory).as_posix()
        try:
            text, _, _ = read_sql_file(path, 50 * 1024 * 1024)
            tokens = tokenize(text)
        except (FileReadError, TokenizeError) as exc:
            catalog.warnings.append(f"{display}: {exc}")
            continue
        _Reader(tokens, text, display, catalog).run()
        catalog.files_read.append(display)
    log.info("Schema catalogue: %d tables, %d indexes from %d files (%d warnings)",
             catalog.table_count, catalog.index_count, len(catalog.files_read),
             len(catalog.warnings))
    return catalog
