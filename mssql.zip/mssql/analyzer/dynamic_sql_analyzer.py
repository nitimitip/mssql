"""Static evaluation of dynamic-SQL text.

Tracks string assignments to local variables so that

    SET @SQL = 'SELECT ... FROM Customer WHERE Status = ''A''';
    EXEC sp_executesql @SQL;

can be analysed, while anything that depends on runtime data (parameters,
table data, loops, unknown functions) is reported as Runtime with a
traceable reason instead of being guessed.

Conditional assignments (inside IF/ELSE/WHILE) keep every possible value
as a separate variant, e.g. a base query plus an optional appended filter.
"""
from __future__ import annotations

from typing import Dict, Iterable, List, Union

from . import ast_nodes as A


class Runtime:
    """Marker: the value is only known at runtime."""
    __slots__ = ("reason",)

    def __init__(self, reason: str):
        self.reason = reason

    def __repr__(self) -> str:  # pragma: no cover
        return f"Runtime({self.reason!r})"


Value = Union[List[str], Runtime]


def _references_variable(expr, key: str) -> bool:
    stack = [expr]
    while stack:
        node = stack.pop()
        if node is None or isinstance(node, A.Query):
            continue
        if isinstance(node, A.VariableExpr) and node.name.upper() == key:
            return True
        stack.extend(A.expr_children(node))
    return False


class DynamicSqlTracker:
    def __init__(self, parameters: Iterable[str] = (), max_variants: int = 32):
        self.max_variants = max_variants
        self.values: Dict[str, Value] = {}
        for p in parameters:
            self.values[p.upper()] = Runtime("(procedure parameter)")

    # ------------------------------------------------------------ assignments
    def declare(self, name: str) -> None:
        self.values[name.upper()] = Runtime("(declared but not assigned a static value)")

    def assign(self, name: str, op: str, expr, conditional: bool = False, in_loop: bool = False,
               row_dependent: bool = False) -> None:
        key = name.upper()
        old = self.values.get(key)
        if row_dependent:
            new: Value = Runtime("(assigned from query rows)")
        elif in_loop and (op == "+=" or _references_variable(expr, key)):
            new = Runtime("(built up inside a WHILE loop)")
        else:
            new = self.evaluate(expr)
            if op == "+=":
                new = self._concat(old if old is not None else
                                   Runtime(f"({name} has no prior static value)"), new)
            elif op != "=":
                new = Runtime(f"(modified with operator {op})")
        if conditional and old is not None:
            new = self._union(old, new)
        self.values[key] = new

    # ------------------------------------------------------------ evaluation
    def evaluate(self, expr) -> Value:
        if expr is None:
            return Runtime("(no expression)")
        if isinstance(expr, A.LiteralExpr):
            if expr.kind in ("string", "number"):
                return [expr.value]
            return Runtime(f"(non-string value {expr.value})")
        if isinstance(expr, A.VariableExpr):
            value = self.values.get(expr.name.upper())
            if value is None:
                return Runtime(f"{expr.name} (not declared in this batch)")
            if isinstance(value, Runtime):
                if value.reason.startswith("("):
                    return Runtime(f"{expr.name} {value.reason}")
                return Runtime(f"{expr.name} <- {value.reason}")
            return list(value)
        if isinstance(expr, A.BinaryExpr) and expr.op == "+":
            return self._concat(self.evaluate(expr.left), self.evaluate(expr.right))
        if isinstance(expr, A.FuncExpr):
            fname = expr.name[-1].upper()
            if fname in ("CHAR", "NCHAR") and len(expr.args) == 1 \
                    and isinstance(expr.args[0], A.LiteralExpr) and expr.args[0].kind == "number":
                try:
                    return [chr(int(expr.args[0].value))]
                except ValueError:
                    return Runtime("(invalid CHAR() argument)")
            if fname in ("CAST", "TRY_CAST", "CONVERT", "TRY_CONVERT") and expr.args:
                return self.evaluate(expr.args[0])
            if fname == "QUOTENAME" and len(expr.args) == 1:
                inner = self.evaluate(expr.args[0])
                if isinstance(inner, Runtime):
                    return inner
                return ["[" + v.replace("]", "]]") + "]" for v in inner]
            return Runtime(f"(result of function {'.'.join(expr.name)}())")
        if isinstance(expr, A.ColumnExpr):
            return Runtime(f"(value read from table data: {'.'.join(expr.parts)})")
        if isinstance(expr, A.SubqueryExpr):
            return Runtime("(value read by a query)")
        if isinstance(expr, A.CaseExpr):
            return Runtime("(CASE expression)")
        return Runtime("(runtime expression)")

    def _concat(self, a: Value, b: Value) -> Value:
        if isinstance(a, Runtime):
            return a
        if isinstance(b, Runtime):
            return b
        if len(a) * len(b) > self.max_variants:
            return Runtime(f"(more than {self.max_variants} possible variants)")
        return [x + y for x in a for y in b]

    def _union(self, a: Value, b: Value) -> Value:
        if isinstance(a, Runtime):
            return a
        if isinstance(b, Runtime):
            return b
        merged = list(dict.fromkeys(a + b))
        if len(merged) > self.max_variants:
            return Runtime(f"(more than {self.max_variants} possible variants)")
        return merged
