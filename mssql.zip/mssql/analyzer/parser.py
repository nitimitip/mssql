"""Recursive-descent T-SQL parser.

Produces the AST defined in analyzer.ast_nodes. Scope:

* batches separated by GO, CREATE/ALTER [OR ALTER] PROC[EDURE]
* control flow: BEGIN/END, IF/ELSE, WHILE, TRY/CATCH, cursors
* DML: SELECT (incl. INTO, set operations, CTEs, derived tables, APPLY,
  PIVOT), INSERT, UPDATE ... FROM, DELETE ... FROM, MERGE, TRUNCATE
* DECLARE / SET / EXEC (incl. dynamic SQL forms)

T-SQL semicolons are optional, so statement boundaries come from the
grammar itself: a statement ends where the grammar cannot continue, and
reserved keywords can never be swallowed as implicit aliases.

Error recovery is per statement: a statement the parser cannot handle
becomes an UnparsedStmt (never silently dropped) and parsing resumes at the
next statement boundary.
"""
from __future__ import annotations

from typing import List, Optional

from . import ast_nodes as A
from .keywords import (
    AGGREGATES, ASSIGN_OPS, BUILTIN_ROWSET_FUNCTIONS, COMPARISON_OPS,
    DATEPART_FUNCTIONS, FOR_CLAUSE_OPTIONS, JOIN_HINTS, NILADIC, NOT_ALIAS,
    OPAQUE_ARG_FUNCTIONS, RESERVED, RESERVED_FUNCTIONS, STATEMENT_START,
    TABLE_HINTS,
)
from .tokenizer import EOF, GO, NUMBER, OP, QIDENT, STRING, VARIABLE, WORD, Token

# Statements we recognise but deliberately ignore: they cannot reference
# table data in a way this report covers.
_IGNORED_STATEMENTS = frozenset({
    "COMMIT", "ROLLBACK", "SAVE", "OPEN", "FETCH", "CLOSE", "DEALLOCATE",
    "WAITFOR", "GOTO", "BREAK", "CONTINUE", "USE", "GRANT", "REVOKE", "DENY",
    "DBCC", "KILL", "CHECKPOINT", "REVERT", "RECONFIGURE", "RAISERROR",
    "THROW", "ENABLE", "DISABLE", "BACKUP", "RESTORE", "SETUSER", "SEND",
    "END_CONVERSATION", "MOVE",
})


class ParseError(Exception):
    def __init__(self, message: str, token: Token):
        near = token.value if token.kind not in (EOF, GO) else token.kind
        super().__init__(f"{message} at line {token.line} near '{near}'")
        self.line = token.line


def render_tokens(tokens: List[Token], text: str, span) -> str:
    """Reconstruct readable SQL for a token span (comments already removed)."""
    s, e = span
    out = []
    prev = None
    for tok in tokens[s:e]:
        if tok.kind in (EOF, GO):
            break
        raw = text[tok.start:tok.end]
        if tok.kind != STRING:
            # line breaks inside string literals are data and are kept
            raw = raw.replace("\r", " ").replace("\n", " ")
        if prev is not None:
            is_call = raw == "(" and (
                prev.kind == QIDENT
                or (prev.kind == WORD and (prev.upper not in RESERVED
                                           or prev.upper in RESERVED_FUNCTIONS)))
            no_space = (
                raw in (",", ")", ".")
                or (prev.kind == OP and prev.value in ("(", "."))
                or is_call
            )
            if not no_space:
                out.append(" ")
        out.append(raw)
        prev = tok
    return "".join(out)


class Parser:
    def __init__(self, tokens: List[Token]):
        self.toks = tokens
        self.n = len(tokens)
        self.i = 0

    # ------------------------------------------------------------ helpers
    def peek(self, k: int = 0) -> Token:
        j = self.i + k
        return self.toks[j] if j < self.n else self.toks[-1]

    def advance(self) -> Token:
        tok = self.toks[self.i]
        if self.i < self.n - 1:
            self.i += 1
        return tok

    def at_kw(self, *kws: str, k: int = 0) -> bool:
        tok = self.peek(k)
        return tok.kind == WORD and tok.upper in kws

    def at_op(self, *ops: str, k: int = 0) -> bool:
        tok = self.peek(k)
        return tok.kind == OP and tok.value in ops

    def accept_kw(self, *kws: str) -> Optional[Token]:
        return self.advance() if self.at_kw(*kws) else None

    def accept_op(self, *ops: str) -> Optional[Token]:
        return self.advance() if self.at_op(*ops) else None

    def expect_kw(self, kw: str) -> Token:
        if not self.at_kw(kw):
            self.error(f"Expected {kw}")
        return self.advance()

    def expect_op(self, op: str) -> Token:
        if not self.at_op(op):
            self.error(f"Expected '{op}'")
        return self.advance()

    def at_batch_end(self) -> bool:
        return self.peek().kind in (EOF, GO)

    def error(self, message: str):
        raise ParseError(message, self.peek())

    @staticmethod
    def is_ident(tok: Token, allow_reserved: bool = False) -> bool:
        if tok.kind == QIDENT:
            return True
        return tok.kind == WORD and (allow_reserved or tok.upper not in RESERVED)

    def parse_ident(self, allow_reserved: bool = False) -> str:
        tok = self.peek()
        if not self.is_ident(tok, allow_reserved):
            self.error("Expected identifier")
        self.advance()
        return tok.value

    def parse_object_name(self) -> List[str]:
        parts = [self.parse_ident()]
        while self.at_op("."):
            self.advance()
            if self.at_op("."):
                parts.append("")          # db..table
                continue
            parts.append(self.parse_ident(allow_reserved=True))
        if len(parts) > 4:
            self.error("Object name has more than 4 parts")
        return parts

    def parse_ident_list(self) -> List[str]:
        self.expect_op("(")
        names = [self.parse_ident(allow_reserved=True)]
        while self.accept_op(","):
            names.append(self.parse_ident(allow_reserved=True))
        self.expect_op(")")
        return names

    def parse_alias(self, allow_string: bool = False) -> Optional[str]:
        if self.accept_kw("AS"):
            tok = self.peek()
            if tok.kind in (WORD, QIDENT) or (allow_string and tok.kind == STRING):
                self.advance()
                return tok.value
            self.error("Expected alias after AS")
        tok = self.peek()
        if (tok.kind == QIDENT
                or (tok.kind == WORD and tok.upper not in NOT_ALIAS and not tok.value.startswith("$"))
                or (allow_string and tok.kind == STRING)):
            self.advance()
            return tok.value
        return None

    def skip_parens(self) -> None:
        self.expect_op("(")
        depth = 1
        while depth:
            tok = self.peek()
            if tok.kind in (EOF, GO):
                self.error("Unbalanced parentheses")
            self.advance()
            if tok.kind == OP:
                if tok.value == "(":
                    depth += 1
                elif tok.value == ")":
                    depth -= 1

    def is_cte_start(self, k: int = 0) -> bool:
        """At WITH (offset k): is this a common-table-expression list?"""
        t1 = self.peek(k + 1)
        if not self.is_ident(t1):
            return False
        if t1.kind == WORD and t1.upper == "XMLNAMESPACES":
            return True
        return self.at_kw("AS", k=k + 2) or self.at_op("(", k=k + 2)

    def is_statement_start(self, k: int = 0) -> bool:
        tok = self.peek(k)
        if tok.kind != WORD:
            return False
        if tok.upper == "WITH":
            return self.is_cte_start(k)
        return tok.upper in STATEMENT_START or tok.upper == "THROW"

    def paren_starts_query(self) -> bool:
        k = 0
        while self.at_op("(", k=k):
            k += 1
        if k == 0:
            return False
        return self.at_kw("SELECT", k=k) or (self.at_kw("WITH", k=k) and self.is_cte_start(k))

    def skip_rest_of_statement(self) -> None:
        """Skip tokens up to the next statement boundary (not consuming it)."""
        depth = 0
        case_depth = 0
        while True:
            tok = self.peek()
            if tok.kind in (EOF, GO):
                return
            if tok.kind == OP:
                if tok.value == "(":
                    depth += 1
                elif tok.value == ")":
                    if depth == 0:
                        return
                    depth -= 1
                elif tok.value == ";" and depth == 0:
                    self.advance()
                    return
            elif tok.kind == WORD and depth == 0:
                if tok.upper == "CASE":
                    case_depth += 1
                elif tok.upper == "END" and case_depth:
                    case_depth -= 1
                    self.advance()
                    continue
                elif case_depth == 0 and self.is_statement_start():
                    return
            self.advance()

    def skip_statement(self) -> None:
        """Consume the current (leading) token and the rest of its statement."""
        self.advance()
        self.skip_rest_of_statement()

    # ------------------------------------------------------------ script / statements
    def parse_script(self) -> List[List[A.Stmt]]:
        batches = []
        while True:
            batches.append(self.parse_statement_list(stop_at_end=False))
            if self.peek().kind == GO:
                self.advance()
                continue
            return batches

    def parse_statement_list(self, stop_at_end: bool) -> List[A.Stmt]:
        stmts: List[A.Stmt] = []
        while True:
            while self.accept_op(";"):
                pass
            if self.at_batch_end():
                break
            if stop_at_end and self.at_kw("END"):
                break
            stmts.append(self.parse_statement_safe())
        return stmts

    def parse_statement_safe(self) -> A.Stmt:
        start = self.i
        line = self.peek().line
        try:
            stmt = self.parse_statement()
            if self.i == start:
                self.advance()
            return stmt
        except RecursionError:
            message = "Statement nested too deeply to analyse"
        except ParseError as exc:
            message = str(exc)
        except Exception as exc:  # defensive: parser bug must not kill the file
            message = f"Internal parser error: {type(exc).__name__}: {exc}"
        self.i = start
        if not self.at_batch_end():
            self.skip_statement()
        return A.UnparsedStmt(span=(start, self.i), line=line, error=message)

    def parse_required_statement(self) -> A.Stmt:
        while self.accept_op(";"):
            pass
        if self.at_batch_end() or self.at_kw("END", "ELSE"):
            self.error("Missing statement")
        return self.parse_statement_safe()

    def parse_statement(self) -> A.Stmt:
        tok = self.peek()
        start = self.i
        if tok.kind == OP and tok.value == "(":
            stmt: A.Stmt = A.SelectStmt(query=self.parse_query_expression())
        elif tok.kind != WORD:
            self.error("Unexpected token at start of statement")
        else:
            kw = tok.upper
            if self.at_op(":", k=1) and kw not in RESERVED:
                self.advance()
                self.advance()
                stmt = A.SkippedStmt(keyword="LABEL")
            elif kw == "SELECT":
                stmt = A.SelectStmt(query=self.parse_query_expression())
            elif kw == "WITH":
                stmt = self.parse_with_statement()
            elif kw == "INSERT":
                stmt = self.parse_insert()
            elif kw == "UPDATE":
                stmt = self.parse_update()
            elif kw == "DELETE":
                stmt = self.parse_delete()
            elif kw == "MERGE":
                stmt = self.parse_merge()
            elif kw == "TRUNCATE":
                self.advance()
                self.expect_kw("TABLE")
                stmt = A.TruncateStmt(target=self.parse_table_target())
                self.skip_rest_of_statement()
            elif kw == "DECLARE":
                stmt = self.parse_declare()
            elif kw == "SET":
                stmt = self.parse_set()
            elif kw in ("EXEC", "EXECUTE"):
                stmt = self.parse_exec()
            elif kw == "IF":
                stmt = self.parse_if()
            elif kw == "WHILE":
                self.advance()
                cond = self.parse_expression()
                stmt = A.WhileStmt(condition=cond, body=self.parse_required_statement())
            elif kw == "BEGIN":
                stmt = self.parse_begin()
            elif kw in ("CREATE", "ALTER"):
                stmt = self.parse_create_or_alter()
            elif kw == "DROP":
                stmt = self.parse_drop()
            elif kw in ("PRINT", "RETURN"):
                self.advance()
                exprs = [] if self.at_expression_end() else [self.parse_expression()]
                stmt = A.ExprStmt(keyword=kw, exprs=exprs)
            elif kw == "BULK" and self.at_kw("INSERT", k=1):
                self.advance()
                self.advance()
                stmt = A.InsertStmt(target=self.parse_table_target())
                self.skip_rest_of_statement()
            elif kw in _IGNORED_STATEMENTS:
                if kw in ("GRANT", "REVOKE", "DENY") and self.at_kw("EXEC", "EXECUTE", k=1):
                    self.advance()        # GRANT EXECUTE ON ... is not an EXEC statement
                self.skip_statement()
                stmt = A.SkippedStmt(keyword=kw)
            elif kw in ("END", "ELSE"):
                self.error(f"Unexpected {kw}")
            else:
                self.error(f"Unrecognised statement '{tok.value}'")
        stmt.span = (start, self.i)
        stmt.line = tok.line
        return stmt

    def at_expression_end(self) -> bool:
        tok = self.peek()
        return (tok.kind in (EOF, GO)
                or (tok.kind == OP and tok.value in (";", ")"))
                or self.is_statement_start()
                or (tok.kind == WORD and tok.upper in ("ELSE", "END", "WITH", "AT")))

    # ------------------------------------------------------------ control flow
    def parse_if(self) -> A.IfStmt:
        self.expect_kw("IF")
        cond = self.parse_expression()
        then = self.parse_required_statement()
        stmt = A.IfStmt(condition=cond, then=then)
        save = self.i
        while self.accept_op(";"):
            pass
        if self.accept_kw("ELSE"):
            stmt.else_ = self.parse_required_statement()
        else:
            self.i = save
        return stmt

    def parse_begin(self) -> A.Stmt:
        if self.at_kw("TRAN", "TRANSACTION", "DISTRIBUTED", "DIALOG", "CONVERSATION", k=1):
            self.skip_statement()
            return A.SkippedStmt(keyword="BEGIN TRAN")
        self.advance()
        kind = "BEGIN"
        if self.accept_kw("TRY"):
            kind = "TRY"
        elif self.accept_kw("CATCH"):
            kind = "CATCH"
        elif self.accept_kw("ATOMIC"):
            if self.accept_kw("WITH"):
                self.skip_parens()
        body = self.parse_statement_list(stop_at_end=True)
        block = A.BlockStmt(kind=kind, body=body)
        if self.accept_kw("END"):
            if kind in ("TRY", "CATCH"):
                self.accept_kw(kind)
        else:
            block.unterminated = True
        return block

    # ------------------------------------------------------------ DDL / procedure
    def parse_create_or_alter(self) -> A.Stmt:
        k = 1
        if self.at_kw("CREATE") and self.at_kw("OR", k=1) and self.at_kw("ALTER", k=2):
            k = 3
        if self.at_kw("PROC", "PROCEDURE", k=k):
            return self.parse_procedure(k)
        if self.at_kw("CREATE") and self.at_kw("TABLE", k=1):
            self.advance()
            self.advance()
            target = self.parse_table_target()
            cols = self.parse_table_definition() if self.at_op("(") else []
            self.skip_rest_of_statement()
            return A.CreateTableStmt(target=target, columns=cols)
        if self.at_kw("VIEW", "FUNCTION", "TRIGGER", k=k):
            kind = self.peek(k).upper
            for _ in range(k + 1):
                self.advance()
            name = self.parse_object_name()
            while not self.at_batch_end():
                self.advance()
            return A.NonProcedureObject(kind=kind, name=name)
        self.skip_statement()
        return A.SkippedStmt(keyword=self.toks[self.i - 1].upper or "DDL")

    def parse_procedure(self, k: int) -> A.ProcedureDef:
        for _ in range(k + 1):
            self.advance()
        name = self.parse_object_name()
        if self.at_op(";") and self.peek(1).kind == NUMBER:
            self.advance()
            self.advance()
        params: List[str] = []
        in_paren = bool(self.accept_op("("))
        depth = 0
        while True:
            tok = self.peek()
            if tok.kind in (EOF, GO):
                self.error("Missing AS in procedure definition")
            if tok.kind == OP:
                if tok.value == "(":
                    depth += 1
                elif tok.value == ")":
                    depth -= 1
                    if depth < 0 and in_paren:
                        depth = 0
                        in_paren = False
            elif tok.kind == VARIABLE and depth == 0:
                params.append(tok.value)
            elif tok.kind == WORD and depth == 0 and not in_paren:
                if tok.upper == "AS" and self.toks[self.i - 1].kind != VARIABLE:
                    break
                if tok.upper == "WITH":
                    self.advance()
                    self.parse_procedure_options()
                    continue
            self.advance()
        self.expect_kw("AS")
        body = self.parse_statement_list(stop_at_end=False)
        return A.ProcedureDef(name=name, params=params, body=body)

    def parse_procedure_options(self) -> None:
        while True:
            if self.at_kw("EXECUTE", "EXEC") and self.at_kw("AS", k=1):
                self.advance()
                self.advance()
                self.advance()       # CALLER | SELF | OWNER | 'user'
            elif self.at_kw("RECOMPILE", "ENCRYPTION", "NATIVE_COMPILATION", "SCHEMABINDING"):
                self.advance()
            else:
                return
            if not self.accept_op(","):
                return

    def parse_table_definition(self) -> List[str]:
        """Column names from a CREATE TABLE / DECLARE TABLE definition."""
        self.expect_op("(")
        cols: List[str] = []
        depth = 1
        expect_name = True
        while depth:
            tok = self.peek()
            if tok.kind in (EOF, GO):
                self.error("Unterminated table definition")
            self.advance()
            if tok.kind == OP and tok.value == "(":
                depth += 1
                continue
            if tok.kind == OP and tok.value == ")":
                depth -= 1
                continue
            if depth == 1 and tok.kind == OP and tok.value == ",":
                expect_name = True
                continue
            if depth == 1 and expect_name:
                expect_name = False
                if tok.kind == QIDENT or (tok.kind == WORD and tok.upper not in RESERVED
                                          and tok.upper != "PERIOD"):
                    cols.append(tok.value)
        return cols

    def parse_drop(self) -> A.Stmt:
        if not self.at_kw("TABLE", k=1):
            self.skip_statement()
            return A.SkippedStmt(keyword="DROP")
        self.advance()
        self.advance()
        if self.at_kw("IF") and self.at_kw("EXISTS", k=1):
            self.advance()
            self.advance()
        targets = [self.parse_table_target()]
        while self.accept_op(","):
            targets.append(self.parse_table_target())
        return A.DropTableStmt(targets=targets)

    def parse_data_type(self) -> None:
        tok = self.peek()
        if not (tok.kind in (WORD, QIDENT)):
            self.error("Expected data type")
        self.advance()
        if tok.kind == WORD and tok.upper == "DOUBLE":
            self.accept_kw("PRECISION")
        elif tok.kind == WORD and tok.upper == "NATIONAL":
            while self.at_kw("CHAR", "CHARACTER", "VARYING", "TEXT"):
                self.advance()
        while self.at_op("."):
            self.advance()
            self.parse_ident(allow_reserved=True)
        if self.at_op("("):
            self.skip_parens()
        self.accept_kw("VARYING")

    # ------------------------------------------------------------ DECLARE / SET / EXEC
    def parse_declare(self) -> A.Stmt:
        self.expect_kw("DECLARE")
        tok = self.peek()
        if tok.kind in (WORD, QIDENT):
            name = self.advance().value
            while not self.at_kw("CURSOR"):
                if self.at_batch_end() or self.at_op(";"):
                    self.error("Expected CURSOR")
                self.advance()
            self.advance()
            return self.parse_cursor_body(name)
        decls: List[A.Stmt] = []
        while True:
            var = self.peek()
            if var.kind != VARIABLE:
                self.error("Expected variable name in DECLARE")
            self.advance()
            self.accept_kw("AS")
            if self.accept_kw("TABLE"):
                decls.append(A.DeclareTableVarStmt(name=var.value, columns=self.parse_table_definition(),
                                                   line=var.line))
            elif self.accept_kw("CURSOR"):
                decls.append(A.DeclareVarStmt(name=var.value, line=var.line))
            else:
                self.parse_data_type()
                value = self.parse_expression() if self.accept_op("=") else None
                decls.append(A.DeclareVarStmt(name=var.value, value=value, line=var.line))
            if not self.accept_op(","):
                break
        if len(decls) == 1:
            return decls[0]
        return A.BlockStmt(kind="DECLARE", body=decls)

    def parse_cursor_body(self, name: str) -> A.DeclareCursorStmt:
        while not self.at_kw("FOR"):
            if self.at_batch_end() or self.at_op(";"):
                self.error("Expected FOR in cursor declaration")
            self.advance()
        self.advance()
        query = self.parse_query_expression()
        stmt = A.DeclareCursorStmt(name=name, query=query)
        if self.at_kw("FOR"):
            self.advance()
            if self.accept_kw("UPDATE"):
                stmt.for_update = True
                if self.accept_kw("OF"):
                    self.parse_ident(allow_reserved=True)
                    while self.accept_op(","):
                        self.parse_ident(allow_reserved=True)
            else:
                self.accept_kw("READ")
                self.accept_kw("ONLY")
        return stmt

    def parse_set(self) -> A.Stmt:
        if self.peek(1).kind == VARIABLE:
            self.advance()
            var = self.advance()
            op = self.peek()
            if op.kind == OP and op.value in ASSIGN_OPS:
                self.advance()
                if self.accept_kw("CURSOR"):
                    return self.parse_cursor_body(var.value)
                return A.SetVarStmt(name=var.value, op=op.value, value=self.parse_expression())
            self.error("Unsupported SET form")
        self.skip_statement()
        return A.SkippedStmt(keyword="SET")

    def parse_exec(self) -> A.ExecStmt:
        self.advance()  # EXEC / EXECUTE
        stmt = A.ExecStmt()
        if self.at_op("("):
            self.advance()
            exprs = [self.parse_expression()]
            while self.accept_op(","):
                exprs.append(self.parse_expression())
            self.expect_op(")")
            stmt.dynamic_expr = exprs[0]
            stmt.dynamic_form = "EXEC()"
            stmt.args = exprs[1:]
            self.parse_exec_tail()
            return stmt
        if self.peek().kind == VARIABLE and self.at_op("=", k=1):
            self.advance()
            self.advance()
        tok = self.peek()
        if tok.kind == VARIABLE:
            self.advance()
            stmt.proc_variable = tok.value
        else:
            stmt.proc_name = self.parse_object_name()
            if self.at_op(";") and self.peek(1).kind == NUMBER:
                self.advance()
                self.advance()
        stmt.args = self.parse_exec_args()
        if stmt.proc_name and stmt.proc_name[-1].upper() == "SP_EXECUTESQL":
            stmt.dynamic_form = "sp_executesql"
            stmt.dynamic_expr = stmt.args[0] if stmt.args else None
        self.parse_exec_tail()
        return stmt

    def parse_exec_args(self) -> List[A.Expr]:
        args: List[A.Expr] = []
        if self.at_expression_end():
            return args
        while True:
            if self.peek().kind == VARIABLE and self.at_op("=", k=1):
                self.advance()
                self.advance()
            if self.at_kw("DEFAULT"):
                tok = self.advance()
                args.append(A.LiteralExpr(kind="other", value="DEFAULT", span=(self.i - 1, self.i)))
            else:
                args.append(self.parse_expression())
            self.accept_kw("OUTPUT", "OUT", "READONLY")
            if not self.accept_op(","):
                return args

    def parse_exec_tail(self) -> None:
        while True:
            if self.at_kw("AS") and self.at_kw("LOGIN", "USER", k=1):
                self.advance()
                self.advance()
                self.expect_op("=")
                self.advance()
            elif self.at_kw("AT") and not self.at_kw("TIME", k=1):
                self.advance()
                self.advance()
            elif self.at_kw("WITH") and self.at_kw("RECOMPILE", "RESULT", k=1):
                self.advance()
                if self.accept_kw("RESULT"):
                    self.accept_kw("SETS")
                    if self.at_op("("):
                        self.skip_parens()
                    else:
                        self.advance()   # UNDEFINED | NONE
                else:
                    self.advance()
            else:
                return

    # ------------------------------------------------------------ DML
    def parse_with_statement(self) -> A.Stmt:
        if not self.is_cte_start():
            self.error("Unsupported WITH clause")
        ctes = self.parse_ctes()
        if self.at_kw("SELECT") or self.at_op("("):
            query = self.parse_query_expression()
            query.ctes = ctes
            return A.SelectStmt(query=query)
        if self.at_kw("INSERT"):
            stmt = self.parse_insert()
        elif self.at_kw("UPDATE"):
            stmt = self.parse_update()
        elif self.at_kw("DELETE"):
            stmt = self.parse_delete()
        elif self.at_kw("MERGE"):
            stmt = self.parse_merge()
        else:
            self.error("Expected SELECT/INSERT/UPDATE/DELETE/MERGE after WITH")
        stmt.ctes = ctes
        return stmt

    def parse_ctes(self) -> List[A.CTE]:
        self.expect_kw("WITH")
        ctes: List[A.CTE] = []
        while True:
            if self.at_kw("XMLNAMESPACES"):
                self.advance()
                self.skip_parens()
            else:
                line = self.peek().line
                name = self.parse_ident()
                cols = self.parse_ident_list() if self.at_op("(") else None
                self.expect_kw("AS")
                self.expect_op("(")
                query = self.parse_query_expression()
                self.expect_op(")")
                ctes.append(A.CTE(name=name, columns=cols, query=query, line=line))
            if not self.accept_op(","):
                return ctes

    def parse_table_target(self) -> A.TableRef:
        tok = self.peek()
        start = self.i
        if tok.kind == VARIABLE:
            self.advance()
            return A.TableRef(name=[tok.value], line=tok.line, span=(start, self.i))
        name = self.parse_object_name()
        return A.TableRef(name=name, line=tok.line, span=(start, self.i))

    def parse_top(self) -> Optional[str]:
        """TOP clause -> its text without parentheses, e.g. '1', '@n', '10 PERCENT'."""
        if not self.accept_kw("TOP"):
            return None
        start = self.i
        if self.at_op("("):
            self.skip_parens()
            inner = self.toks[start + 1:self.i - 1]
        else:
            self.advance()
            inner = self.toks[start:self.i]
        text = "".join(t.value for t in inner)
        if self.accept_kw("PERCENT"):
            text += " PERCENT"
        if self.at_kw("WITH") and self.at_kw("TIES", k=1):
            self.advance()
            self.advance()
            text += " WITH TIES"
        return text

    def parse_option_clause(self) -> None:
        if self.at_kw("OPTION") and self.at_op("(", k=1):
            self.advance()
            self.skip_parens()

    def parse_output_clauses(self) -> List[A.OutputClause]:
        outs: List[A.OutputClause] = []
        while self.at_kw("OUTPUT"):
            self.advance()
            clause = A.OutputClause(items=self.parse_select_items())
            if self.accept_kw("INTO"):
                clause.into = self.parse_table_target()
                if self.at_op("(") and not self.paren_starts_query():
                    self.parse_ident_list()
            outs.append(clause)
        return outs

    def parse_insert(self) -> A.InsertStmt:
        self.expect_kw("INSERT")
        self.parse_top()
        self.accept_kw("INTO")
        stmt = A.InsertStmt(target=self.parse_table_target())
        self.parse_table_hints()
        if self.at_op("(") and not self.paren_starts_query():
            stmt.columns = self.parse_ident_list()
        stmt.output = self.parse_output_clauses()
        if self.accept_kw("VALUES"):
            stmt.values = self.parse_values_rows()
        elif self.at_kw("DEFAULT") and self.at_kw("VALUES", k=1):
            self.advance()
            self.advance()
        elif self.at_kw("EXEC", "EXECUTE"):
            start = self.i
            line = self.peek().line
            stmt.exec_stmt = self.parse_exec()
            stmt.exec_stmt.span = (start, self.i)
            stmt.exec_stmt.line = line
        elif self.at_kw("SELECT") or self.at_op("(") or (self.at_kw("WITH") and self.is_cte_start()):
            if self.at_kw("WITH"):
                ctes = self.parse_ctes()
                stmt.query = self.parse_query_expression()
                stmt.query.ctes = ctes
            else:
                stmt.query = self.parse_query_expression()
        else:
            self.error("Unsupported INSERT source")
        self.parse_option_clause()
        return stmt

    def parse_set_items(self) -> List[A.SetItem]:
        items: List[A.SetItem] = []
        while True:
            tok = self.peek()
            if tok.kind == VARIABLE:
                self.advance()
                op = self.peek()
                if not (op.kind == OP and op.value in ASSIGN_OPS):
                    self.error("Expected assignment operator")
                self.advance()
                item = A.SetItem(target=[tok.value], op=op.value, is_variable=True)
                if self.is_ident(self.peek()) and self.at_op("=", k=1):
                    # SET @v = column = expression
                    self.advance()
                    self.advance()
                item.value = self.parse_expression()
            else:
                parts = self.parse_object_name()
                if self.at_op("("):
                    self.skip_parens()        # column.WRITE(...) / UDT mutator
                    item = A.SetItem(target=parts, op="WRITE")
                else:
                    op = self.peek()
                    if not (op.kind == OP and op.value in ASSIGN_OPS):
                        self.error("Expected assignment operator")
                    self.advance()
                    item = A.SetItem(target=parts, op=op.value, value=self.parse_expression())
            items.append(item)
            if not self.accept_op(","):
                return items

    def parse_where_or_current_of(self, stmt) -> None:
        if not self.accept_kw("WHERE"):
            return
        if self.at_kw("CURRENT") and self.at_kw("OF", k=1):
            self.advance()
            self.advance()
            self.accept_kw("GLOBAL")
            stmt.current_of = self.advance().value
        else:
            stmt.where = self.parse_expression()

    def parse_update(self) -> A.Stmt:
        if self.at_kw("STATISTICS", k=1):
            self.skip_statement()
            return A.SkippedStmt(keyword="UPDATE STATISTICS")
        self.expect_kw("UPDATE")
        top = self.parse_top()
        stmt = A.UpdateStmt(target=self.parse_table_target(), top=top)
        self.parse_table_hints()
        self.expect_kw("SET")
        stmt.set_items = self.parse_set_items()
        stmt.output = self.parse_output_clauses()
        if self.accept_kw("FROM"):
            stmt.from_items = self.parse_from_list()
        self.parse_where_or_current_of(stmt)
        self.parse_option_clause()
        return stmt

    def parse_delete(self) -> A.DeleteStmt:
        self.expect_kw("DELETE")
        top = self.parse_top()
        self.accept_kw("FROM")
        stmt = A.DeleteStmt(target=self.parse_table_target(), top=top)
        self.parse_table_hints()
        stmt.output = self.parse_output_clauses()
        if self.accept_kw("FROM"):
            stmt.from_items = self.parse_from_list()
        self.parse_where_or_current_of(stmt)
        self.parse_option_clause()
        return stmt

    def parse_merge(self) -> A.MergeStmt:
        self.expect_kw("MERGE")
        self.parse_top()
        self.accept_kw("INTO")
        stmt = A.MergeStmt(target=self.parse_table_target())
        self.parse_table_hints()
        stmt.target.alias = self.parse_alias()
        self.expect_kw("USING")
        stmt.source = self.parse_joined_source()
        self.expect_kw("ON")
        stmt.condition = self.parse_expression()
        while self.accept_kw("WHEN"):
            when = A.MergeWhen()
            if self.accept_kw("NOT"):
                self.expect_kw("MATCHED")
                when.match = "NOT MATCHED"
                if self.accept_kw("BY"):
                    if self.advance().upper == "SOURCE":
                        when.match = "NOT MATCHED BY SOURCE"
            else:
                self.expect_kw("MATCHED")
            if self.accept_kw("AND"):
                when.condition = self.parse_expression()
            self.expect_kw("THEN")
            if self.accept_kw("UPDATE"):
                self.expect_kw("SET")
                when.action = "UPDATE"
                when.set_items = self.parse_set_items()
            elif self.accept_kw("DELETE"):
                when.action = "DELETE"
            elif self.accept_kw("INSERT"):
                when.action = "INSERT"
                if self.at_op("("):
                    when.insert_columns = self.parse_ident_list()
                if self.accept_kw("VALUES"):
                    self.expect_op("(")
                    when.values = [self.parse_expression()]
                    while self.accept_op(","):
                        when.values.append(self.parse_expression())
                    self.expect_op(")")
                else:
                    self.expect_kw("DEFAULT")
                    self.expect_kw("VALUES")
            else:
                self.error("Expected UPDATE, DELETE or INSERT in MERGE WHEN clause")
            stmt.whens.append(when)
        stmt.output = self.parse_output_clauses()
        self.parse_option_clause()
        return stmt

    # ------------------------------------------------------------ queries
    def parse_query_expression(self) -> A.Query:
        start = self.i
        query = self.parse_query_term()
        while self.at_kw("UNION", "EXCEPT", "INTERSECT"):
            op = self.advance().upper
            if op == "UNION" and self.accept_kw("ALL"):
                op = "UNION ALL"
            right = self.parse_query_term()
            query = A.SetOpQuery(op=op, left=query, right=right)
        if self.at_kw("ORDER") and self.at_kw("BY", k=1):
            query.order_by = self.parse_order_by()
        self.parse_query_tail()
        query.span = (start, self.i)
        return query

    def parse_query_term(self) -> A.Query:
        if self.at_op("("):
            self.advance()
            query = self.parse_query_expression()
            self.expect_op(")")
            return query
        return self.parse_select_core()

    def parse_order_by(self) -> List[A.Expr]:
        self.advance()
        self.advance()
        exprs = []
        while True:
            exprs.append(self.parse_expression())
            self.accept_kw("ASC", "DESC")
            if not self.accept_op(","):
                return exprs

    def parse_over(self) -> List[A.Expr]:
        """OVER (PARTITION BY ... ORDER BY ... [frame]) -> the partition / order expressions.

        A named window (OVER w) has no expressions here. Anything the window
        parser does not understand is skipped as before rather than failing
        the statement.
        """
        if not self.at_op("("):
            self.advance()
            return []
        start = self.i
        try:
            self.advance()
            exprs: List[A.Expr] = []
            if self.at_kw("PARTITION") and self.at_kw("BY", k=1):
                self.advance()
                self.advance()
                exprs.append(self.parse_expression())
                while self.accept_op(","):
                    exprs.append(self.parse_expression())
            if self.at_kw("ORDER") and self.at_kw("BY", k=1):
                exprs.extend(self.parse_order_by())
            while not self.at_op(")"):       # ROWS / RANGE frame
                if self.peek().kind in (EOF, GO):
                    self.error("Unbalanced parentheses")
                if self.at_op("("):
                    self.skip_parens()
                else:
                    self.advance()
            self.advance()
            return exprs
        except ParseError:
            self.i = start
            self.skip_parens()
            return []

    def parse_query_tail(self) -> None:
        if self.at_kw("OFFSET"):
            self.advance()
            self.parse_additive()
            self.accept_kw("ROW", "ROWS")
            if self.accept_kw("FETCH"):
                self.accept_kw("FIRST", "NEXT")
                self.parse_additive()
                self.accept_kw("ROW", "ROWS")
                self.accept_kw("ONLY")
        if self.at_kw("FOR") and self.at_kw("XML", "JSON", "BROWSE", k=1):
            self.advance()
            while True:
                if self.at_op("("):
                    self.skip_parens()
                elif self.at_op(","):
                    self.advance()
                elif self.peek().kind == WORD and self.peek().upper in FOR_CLAUSE_OPTIONS:
                    self.advance()
                else:
                    break
        self.parse_option_clause()

    def parse_select_core(self) -> A.SelectQuery:
        start = self.i
        line = self.peek().line
        self.expect_kw("SELECT")
        distinct = bool(self.accept_kw("ALL", "DISTINCT")) and self.toks[self.i - 1].upper == "DISTINCT"
        top = self.parse_top()
        query = A.SelectQuery(items=self.parse_select_items(), line=line, top=top,
                              distinct=distinct)
        if self.accept_kw("INTO"):
            query.into = self.parse_table_target()
        if self.accept_kw("FROM"):
            query.from_items = self.parse_from_list()
        if self.accept_kw("WHERE"):
            query.where = self.parse_expression()
        if self.at_kw("GROUP") and self.at_kw("BY", k=1):
            self.advance()
            self.advance()
            self.accept_kw("ALL")
            query.group_by = self.parse_group_by_list()
            if self.at_kw("WITH") and self.at_kw("ROLLUP", "CUBE", k=1):
                self.advance()
                self.advance()
        if self.accept_kw("HAVING"):
            query.having = self.parse_expression()
        query.span = (start, self.i)
        return query

    def parse_group_by_list(self) -> List[A.Expr]:
        exprs = []
        while True:
            if self.at_kw("GROUPING") and self.at_kw("SETS", k=1):
                self.advance()
                self.advance()
                self.skip_parens()
            else:
                exprs.append(self.parse_expression())
            if not self.accept_op(","):
                return exprs

    def parse_select_items(self) -> List[A.SelectItem]:
        items: List[A.SelectItem] = []
        while True:
            start = self.i
            tok = self.peek()
            nxt = self.peek(1)
            if tok.kind == VARIABLE and nxt.kind == OP and nxt.value in ASSIGN_OPS:
                self.advance()
                op = self.advance().value
                item = A.SelectItem(expr=self.parse_expression(), assign_var=tok.value, assign_op=op)
            elif (nxt.kind == OP and nxt.value == "="
                  and (tok.kind in (QIDENT, STRING) or (tok.kind == WORD and tok.upper not in RESERVED))):
                self.advance()
                self.advance()
                item = A.SelectItem(expr=self.parse_expression(), alias=tok.value)
            else:
                expr = self.parse_expression()
                alias = None if isinstance(expr, A.StarExpr) else self.parse_alias(allow_string=True)
                item = A.SelectItem(expr=expr, alias=alias)
            item.span = (start, self.i)
            items.append(item)
            if not self.accept_op(","):
                return items

    # ------------------------------------------------------------ FROM clause
    def parse_from_list(self) -> List[A.FromItem]:
        items = [self.parse_joined_source()]
        while self.accept_op(","):
            items.append(self.parse_joined_source())
        return items

    def parse_joined_source(self) -> A.FromItem:
        return self.parse_joins(self.parse_table_primary())

    def parse_joins(self, left: A.FromItem) -> A.FromItem:
        while True:
            start = self.i
            line = self.peek().line
            join_type = self.parse_join_type()
            if join_type is None:
                return left
            right = self.parse_table_primary()
            cond = None
            if join_type not in ("CROSS JOIN", "CROSS APPLY", "OUTER APPLY"):
                if not self.at_kw("ON"):
                    right = self.parse_joins(right)     # A JOIN B JOIN C ON .. ON ..
                self.expect_kw("ON")
                cond = self.parse_expression()
            left = A.Join(join_type=join_type, left=left, right=right, condition=cond,
                          line=line, span=(start, self.i))

    def parse_join_type(self) -> Optional[str]:
        if self.at_kw("JOIN"):
            self.advance()
            return "INNER JOIN"
        if self.at_kw("INNER"):
            k = 2 if self.at_kw(*JOIN_HINTS, k=1) else 1
            if not self.at_kw("JOIN", k=k):
                return None
            for _ in range(k + 1):
                self.advance()
            return "INNER JOIN"
        if self.at_kw("LEFT", "RIGHT", "FULL"):
            k = 1
            if self.at_kw("OUTER", k=k):
                k += 1
            if self.at_kw(*JOIN_HINTS, k=k):
                k += 1
            if not self.at_kw("JOIN", k=k):
                return None
            side = self.peek().upper
            for _ in range(k + 1):
                self.advance()
            return f"{side} JOIN"
        if self.at_kw("CROSS"):
            if self.at_kw("JOIN", k=1):
                self.advance()
                self.advance()
                return "CROSS JOIN"
            if self.at_kw("APPLY", k=1):
                self.advance()
                self.advance()
                return "CROSS APPLY"
        if self.at_kw("OUTER") and self.at_kw("APPLY", k=1):
            self.advance()
            self.advance()
            return "OUTER APPLY"
        return None

    def parse_table_hints(self) -> None:
        if self.at_kw("WITH") and self.at_op("(", k=1):
            self.advance()
            self.skip_parens()
        elif self.at_op("(") and self.peek(1).kind == WORD and self.peek(1).upper in TABLE_HINTS:
            self.skip_parens()

    def parse_derived_alias(self, item) -> None:
        item.alias = self.parse_alias()
        if item.alias and self.at_op("("):
            item.column_aliases = self.parse_ident_list()

    def parse_table_primary(self) -> A.FromItem:
        tok = self.peek()
        start = self.i
        line = tok.line
        item: A.FromItem
        if tok.kind == OP and tok.value == "(":
            if self.paren_starts_query():
                self.advance()
                query = self.parse_query_expression()
                self.expect_op(")")
                item = A.DerivedTable(query=query, line=line)
                self.parse_derived_alias(item)
            elif self.at_kw("VALUES", k=1):
                self.advance()
                self.advance()
                item = A.ValuesTable(rows=self.parse_values_rows(), line=line)
                self.expect_op(")")
                self.parse_derived_alias(item)
            else:
                self.advance()
                item = self.parse_joined_source()
                self.expect_op(")")
        elif tok.kind == VARIABLE:
            self.advance()
            if self.at_op("."):
                self.advance()
                method = self.parse_ident(allow_reserved=True)
                item = A.FunctionSource(name=[tok.value, method], args=self.parse_call_args(),
                                        builtin=True, line=line)
                self.parse_derived_alias(item)
            else:
                item = A.TableRef(name=[tok.value], line=line)
                item.alias = self.parse_alias()
                self.parse_table_hints()
        elif tok.kind == WORD and tok.upper in BUILTIN_ROWSET_FUNCTIONS and self.at_op("(", k=1):
            self.advance()
            if tok.upper in OPAQUE_ARG_FUNCTIONS:
                self.skip_parens()
                args: List[A.Expr] = []
            else:
                args = self.parse_call_args()
            if tok.upper == "OPENJSON" and self.at_kw("WITH") and self.at_op("(", k=1):
                self.advance()
                self.skip_parens()
            item = A.FunctionSource(name=[tok.value], args=args, builtin=True, line=line)
            self.parse_derived_alias(item)
        else:
            name = self.parse_object_name()
            if self.at_op("(") and not (self.peek(1).kind == WORD and self.peek(1).upper in TABLE_HINTS):
                item = A.FunctionSource(name=name, args=self.parse_call_args(), line=line)
                self.parse_derived_alias(item)
            else:
                item = A.TableRef(name=name, line=line)
                self.parse_table_hints()
                if self.at_kw("FOR") and self.at_kw("SYSTEM_TIME", k=1):
                    self.skip_system_time()
                item.alias = self.parse_alias()
                self.parse_table_hints()
                if self.accept_kw("TABLESAMPLE"):
                    self.accept_kw("SYSTEM")
                    self.skip_parens()
                    if self.accept_kw("REPEATABLE"):
                        self.skip_parens()
        item.span = (start, self.i)
        while self.at_kw("PIVOT", "UNPIVOT"):
            kind = self.advance().upper
            self.skip_parens()
            item = A.PivotSource(source=item, kind=kind, alias=self.parse_alias(),
                                 line=line, span=(start, self.i))
        return item

    def skip_system_time(self) -> None:
        self.advance()
        self.advance()
        if self.accept_kw("ALL"):
            return
        if self.accept_kw("AS"):
            self.expect_kw("OF")
            self.parse_additive()
        elif self.accept_kw("FROM"):
            self.parse_additive()
            self.expect_kw("TO")
            self.parse_additive()
        elif self.accept_kw("BETWEEN"):
            self.parse_additive()
            self.expect_kw("AND")
            self.parse_additive()
        elif self.accept_kw("CONTAINED"):
            self.expect_kw("IN")
            self.skip_parens()
        else:
            self.error("Unsupported FOR SYSTEM_TIME form")

    def parse_values_rows(self) -> List[List[A.Expr]]:
        rows = []
        while True:
            self.expect_op("(")
            row = [self.parse_expression()]
            while self.accept_op(","):
                row.append(self.parse_expression())
            self.expect_op(")")
            rows.append(row)
            if not (self.at_op(",") and self.at_op("(", k=1)):
                return rows
            self.advance()

    def parse_call_args(self) -> List[A.Expr]:
        self.expect_op("(")
        args: List[A.Expr] = []
        if self.accept_op(")"):
            return args
        while True:
            self.accept_kw("DISTINCT", "ALL")
            args.append(self.parse_expression())
            if not self.accept_op(","):
                self.expect_op(")")
                return args

    # ------------------------------------------------------------ expressions
    def parse_expression(self) -> A.Expr:
        start = self.i
        left = self.parse_and()
        if self.at_kw("OR"):
            items = [left]
            while self.accept_kw("OR"):
                items.append(self.parse_and())
            left = A.BoolExpr(op="OR", items=items, span=(start, self.i))
        return left

    def parse_and(self) -> A.Expr:
        start = self.i
        left = self.parse_not()
        if self.at_kw("AND"):
            items = [left]
            while self.accept_kw("AND"):
                items.append(self.parse_not())
            left = A.BoolExpr(op="AND", items=items, span=(start, self.i))
        return left

    def parse_not(self) -> A.Expr:
        if self.at_kw("NOT"):
            start = self.i
            self.advance()
            operand = self.parse_not()
            return A.NotExpr(operand=operand, span=(start, self.i))
        return self.parse_predicate()

    def parse_subquery_in_parens(self) -> A.Query:
        self.expect_op("(")
        query = self.parse_query_expression()
        self.expect_op(")")
        return query

    def parse_predicate(self) -> A.Expr:
        start = self.i
        if self.at_kw("EXISTS"):
            self.advance()
            return A.ExistsExpr(query=self.parse_subquery_in_parens(), span=(start, self.i))
        left = self.parse_additive()
        tok = self.peek()
        if tok.kind == OP and tok.value in COMPARISON_OPS:
            op = self.advance().value
            if self.at_kw("ANY", "ALL", "SOME"):
                quant = self.advance().upper
                sub_start = self.i
                query = self.parse_subquery_in_parens()
                right: A.Expr = A.SubqueryExpr(query=query, span=(sub_start, self.i))
                return A.ComparisonExpr(op=op, left=left, right=right, quantifier=quant,
                                        span=(start, self.i))
            right = self.parse_additive()
            return A.ComparisonExpr(op=op, left=left, right=right, span=(start, self.i))
        if self.at_kw("IS"):
            self.advance()
            negated = bool(self.accept_kw("NOT"))
            if self.accept_kw("NULL"):
                return A.IsNullExpr(operand=left, negated=negated, span=(start, self.i))
            if self.accept_kw("DISTINCT"):
                self.expect_kw("FROM")
                right = self.parse_additive()
                op = "IS NOT DISTINCT FROM" if negated else "IS DISTINCT FROM"
                return A.ComparisonExpr(op=op, left=left, right=right, span=(start, self.i))
            self.error("Expected NULL after IS")
        negated = False
        if self.at_kw("NOT") and self.at_kw("IN", "LIKE", "BETWEEN", k=1):
            self.advance()
            negated = True
        if self.accept_kw("IN"):
            if self.paren_starts_query():
                query = self.parse_subquery_in_parens()
                return A.InExpr(operand=left, query=query, negated=negated, span=(start, self.i))
            self.expect_op("(")
            values = [self.parse_expression()]
            while self.accept_op(","):
                values.append(self.parse_expression())
            self.expect_op(")")
            return A.InExpr(operand=left, values=values, negated=negated, span=(start, self.i))
        if self.accept_kw("BETWEEN"):
            low = self.parse_additive()
            self.expect_kw("AND")
            high = self.parse_additive()
            return A.BetweenExpr(operand=left, low=low, high=high, negated=negated, span=(start, self.i))
        if self.accept_kw("LIKE"):
            pattern = self.parse_additive()
            escape = self.parse_additive() if self.accept_kw("ESCAPE") else None
            return A.LikeExpr(operand=left, pattern=pattern, negated=negated, escape=escape,
                              span=(start, self.i))
        if negated:
            self.error("Expected IN, LIKE or BETWEEN after NOT")
        return left

    def parse_additive(self) -> A.Expr:
        start = self.i
        left = self.parse_multiplicative()
        while self.at_op("+", "-", "&", "|", "^"):
            op = self.advance().value
            right = self.parse_multiplicative()
            left = A.BinaryExpr(op=op, left=left, right=right, span=(start, self.i))
        return left

    def parse_multiplicative(self) -> A.Expr:
        start = self.i
        left = self.parse_unary()
        while self.at_op("*", "/", "%"):
            op = self.advance().value
            right = self.parse_unary()
            left = A.BinaryExpr(op=op, left=left, right=right, span=(start, self.i))
        return left

    def parse_unary(self) -> A.Expr:
        if self.at_op("-", "+", "~"):
            start = self.i
            op = self.advance().value
            operand = self.parse_unary()
            return A.UnaryExpr(op=op, operand=operand, span=(start, self.i))
        expr = self.parse_primary()
        while True:
            if self.at_kw("COLLATE"):
                self.advance()
                self.advance()
            elif self.at_kw("AT") and self.at_kw("TIME", k=1) and self.at_kw("ZONE", k=2):
                self.advance()
                self.advance()
                self.advance()
                self.parse_primary()
            else:
                return expr

    def parse_primary(self) -> A.Expr:
        tok = self.peek()
        start = self.i
        kind = tok.kind
        if kind == NUMBER:
            self.advance()
            return A.LiteralExpr(kind="number", value=tok.value, span=(start, self.i))
        if kind == STRING:
            self.advance()
            return A.LiteralExpr(kind="string", value=tok.value, span=(start, self.i))
        if kind == VARIABLE:
            self.advance()
            if self.at_op(".") and self.is_ident(self.peek(1), True) and self.at_op("(", k=2):
                self.advance()
                method = self.advance().value
                args = self.parse_call_args()
                return A.FuncExpr(name=[tok.value, method], args=args, span=(start, self.i))
            return A.VariableExpr(name=tok.value, span=(start, self.i))
        if kind == OP:
            if tok.value == "(":
                if self.paren_starts_query():
                    query = self.parse_subquery_in_parens()
                    return A.SubqueryExpr(query=query, span=(start, self.i))
                self.advance()
                expr = self.parse_expression()
                self.expect_op(")")
                return expr
            if tok.value == "*":
                self.advance()
                return A.StarExpr(span=(start, self.i))
            if tok.value == "{":
                while not self.at_op("}"):
                    if self.at_batch_end():
                        self.error("Unterminated ODBC escape")
                    self.advance()
                self.advance()
                return A.LiteralExpr(kind="other", value="{...}", span=(start, self.i))
            self.error("Unexpected operator")
        if kind == QIDENT:
            return self.parse_identifier_chain()
        if kind == WORD:
            u = tok.upper
            followed_by_paren = self.at_op("(", k=1)
            if u == "NULL":
                self.advance()
                return A.LiteralExpr(kind="null", value="NULL", span=(start, self.i))
            if u == "CASE":
                return self.parse_case()
            if u in ("CAST", "TRY_CAST", "PARSE", "TRY_PARSE") and followed_by_paren:
                self.advance()
                self.expect_op("(")
                inner = self.parse_expression()
                self.expect_kw("AS")
                self.parse_data_type()
                if self.accept_kw("USING"):
                    self.parse_expression()
                self.expect_op(")")
                return A.FuncExpr(name=[tok.value], args=[inner], span=(start, self.i))
            if u in ("CONVERT", "TRY_CONVERT") and followed_by_paren:
                self.advance()
                self.expect_op("(")
                self.parse_data_type()
                self.expect_op(",")
                args = [self.parse_expression()]
                if self.accept_op(","):
                    args.append(self.parse_expression())
                self.expect_op(")")
                return A.FuncExpr(name=[tok.value], args=args, span=(start, self.i))
            if u in DATEPART_FUNCTIONS and followed_by_paren:
                self.advance()
                self.expect_op("(")
                part = self.advance()     # date-part keyword, not a column
                args: List[A.Expr] = [A.LiteralExpr(kind="other", value=part.value,
                                                    span=(self.i - 1, self.i))]
                while self.accept_op(","):
                    args.append(self.parse_expression())
                self.expect_op(")")
                return A.FuncExpr(name=[tok.value], args=args, span=(start, self.i))
            if u == "NEXT" and self.at_kw("VALUE", k=1) and self.at_kw("FOR", k=2):
                self.advance()
                self.advance()
                self.advance()
                self.parse_object_name()
                if self.accept_kw("OVER"):
                    self.skip_parens()
                return A.LiteralExpr(kind="other", value="NEXT VALUE", span=(start, self.i))
            if u in NILADIC and not followed_by_paren:
                self.advance()
                return A.LiteralExpr(kind="other", value=tok.value, span=(start, self.i))
            if u == "DEFAULT":
                self.advance()
                return A.LiteralExpr(kind="other", value="DEFAULT", span=(start, self.i))
            if tok.value.startswith("$"):
                self.advance()
                return A.LiteralExpr(kind="other", value=tok.value, span=(start, self.i))
            if u in RESERVED and not (u in RESERVED_FUNCTIONS and followed_by_paren):
                self.error(f"Unexpected keyword {tok.value}")
            return self.parse_identifier_chain()
        self.error("Unexpected token in expression")

    def parse_identifier_chain(self) -> A.Expr:
        start = self.i
        parts = [self.advance().value]
        while self.at_op("."):
            self.advance()
            if self.at_op("*"):
                self.advance()
                return A.StarExpr(qualifier=parts, span=(start, self.i))
            if self.at_op("."):
                parts.append("")
                continue
            tok = self.peek()
            if tok.kind not in (WORD, QIDENT):
                self.error("Expected identifier after '.'")
            self.advance()
            parts.append(tok.value)
        if self.at_op("::"):
            self.advance()
            parts.append(self.parse_ident(allow_reserved=True))
        if self.at_op("("):
            args = self.parse_call_args()
            fn = A.FuncExpr(name=parts, args=args,
                            aggregate=len(parts) == 1 and parts[0].upper() in AGGREGATES)
            if self.at_kw("WITHIN") and self.at_kw("GROUP", k=1):
                self.advance()
                self.advance()
                self.skip_parens()
            if self.accept_kw("OVER"):
                fn.window = self.parse_over()
            # chained method call on the result, e.g. x.query('..').value('..')
            while self.at_op(".") and self.is_ident(self.peek(1), True) and self.at_op("(", k=2):
                self.advance()
                self.advance()
                self.parse_call_args()
            fn.span = (start, self.i)
            return fn
        return A.ColumnExpr(parts=parts, span=(start, self.i))

    def parse_case(self) -> A.CaseExpr:
        start = self.i
        self.expect_kw("CASE")
        operand = None if self.at_kw("WHEN") else self.parse_expression()
        whens = []
        while self.accept_kw("WHEN"):
            cond = self.parse_expression()
            self.expect_kw("THEN")
            whens.append((cond, self.parse_expression()))
        if not whens:
            self.error("CASE without WHEN")
        else_ = self.parse_expression() if self.accept_kw("ELSE") else None
        self.expect_kw("END")
        return A.CaseExpr(operand=operand, whens=whens, else_=else_, span=(start, self.i))


def parse_tokens(tokens: List[Token]) -> List[List[A.Stmt]]:
    return Parser(tokens).parse_script()
