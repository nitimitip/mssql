"""AST node definitions produced by analyzer.parser.

Every node carries ``span`` = (first token index, end token index exclusive)
into the token list it was parsed from, so the original SQL text of any
node can be recovered for reporting.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional, Tuple, Iterator

Span = Tuple[int, int]


# ---------------------------------------------------------------- expressions

@dataclass(eq=False)
class Expr:
    span: Span = (0, 0)


@dataclass(eq=False)
class ColumnExpr(Expr):
    parts: List[str] = field(default_factory=list)


@dataclass(eq=False)
class StarExpr(Expr):
    qualifier: List[str] = field(default_factory=list)


@dataclass(eq=False)
class LiteralExpr(Expr):
    kind: str = "other"       # string | number | null | other
    value: str = ""


@dataclass(eq=False)
class VariableExpr(Expr):
    name: str = ""


@dataclass(eq=False)
class FuncExpr(Expr):
    name: List[str] = field(default_factory=list)
    args: List[Expr] = field(default_factory=list)
    aggregate: bool = False
    # PARTITION BY / ORDER BY expressions of an OVER (...) window clause
    window: List[Expr] = field(default_factory=list)


@dataclass(eq=False)
class BinaryExpr(Expr):
    op: str = ""
    left: Optional[Expr] = None
    right: Optional[Expr] = None


@dataclass(eq=False)
class UnaryExpr(Expr):
    op: str = ""
    operand: Optional[Expr] = None


@dataclass(eq=False)
class ComparisonExpr(Expr):
    op: str = ""
    left: Optional[Expr] = None
    right: Optional[Expr] = None
    quantifier: Optional[str] = None   # ANY / ALL / SOME (right is SubqueryExpr)


@dataclass(eq=False)
class BoolExpr(Expr):
    op: str = "AND"
    items: List[Expr] = field(default_factory=list)


@dataclass(eq=False)
class NotExpr(Expr):
    operand: Optional[Expr] = None


@dataclass(eq=False)
class IsNullExpr(Expr):
    operand: Optional[Expr] = None
    negated: bool = False


@dataclass(eq=False)
class InExpr(Expr):
    operand: Optional[Expr] = None
    values: List[Expr] = field(default_factory=list)
    query: Optional["Query"] = None
    negated: bool = False


@dataclass(eq=False)
class BetweenExpr(Expr):
    operand: Optional[Expr] = None
    low: Optional[Expr] = None
    high: Optional[Expr] = None
    negated: bool = False


@dataclass(eq=False)
class LikeExpr(Expr):
    operand: Optional[Expr] = None
    pattern: Optional[Expr] = None
    negated: bool = False
    escape: Optional[Expr] = None


@dataclass(eq=False)
class ExistsExpr(Expr):
    query: Optional["Query"] = None


@dataclass(eq=False)
class SubqueryExpr(Expr):
    query: Optional["Query"] = None


@dataclass(eq=False)
class CaseExpr(Expr):
    operand: Optional[Expr] = None
    whens: List[Tuple[Expr, Expr]] = field(default_factory=list)
    else_: Optional[Expr] = None


# ---------------------------------------------------------------- queries

@dataclass(eq=False)
class SelectItem:
    expr: Optional[Expr] = None
    alias: Optional[str] = None
    assign_var: Optional[str] = None   # SELECT @v = expr
    assign_op: str = "="
    span: Span = (0, 0)


@dataclass(eq=False)
class CTE:
    name: str = ""
    columns: Optional[List[str]] = None
    query: Optional["Query"] = None
    line: int = 0


@dataclass(eq=False)
class Query:
    span: Span = (0, 0)
    ctes: List[CTE] = field(default_factory=list)


@dataclass(eq=False)
class SelectQuery(Query):
    items: List[SelectItem] = field(default_factory=list)
    into: Optional["TableRef"] = None
    from_items: List["FromItem"] = field(default_factory=list)
    where: Optional[Expr] = None
    group_by: List[Expr] = field(default_factory=list)
    having: Optional[Expr] = None
    order_by: List[Expr] = field(default_factory=list)
    line: int = 0
    top: Optional[str] = None          # TOP text without parentheses, e.g. '1', '@n'
    distinct: bool = False


@dataclass(eq=False)
class SetOpQuery(Query):
    op: str = "UNION"
    left: Optional[Query] = None
    right: Optional[Query] = None
    order_by: List[Expr] = field(default_factory=list)


# ---------------------------------------------------------------- FROM items

@dataclass(eq=False)
class FromItem:
    span: Span = (0, 0)
    line: int = 0


@dataclass(eq=False)
class TableRef(FromItem):
    name: List[str] = field(default_factory=list)   # 1..4 parts, '' for omitted
    alias: Optional[str] = None


@dataclass(eq=False)
class DerivedTable(FromItem):
    query: Optional[Query] = None
    alias: Optional[str] = None
    column_aliases: Optional[List[str]] = None


@dataclass(eq=False)
class ValuesTable(FromItem):
    rows: List[List[Expr]] = field(default_factory=list)
    alias: Optional[str] = None
    column_aliases: Optional[List[str]] = None


@dataclass(eq=False)
class FunctionSource(FromItem):
    name: List[str] = field(default_factory=list)
    args: List[Expr] = field(default_factory=list)
    alias: Optional[str] = None
    column_aliases: Optional[List[str]] = None
    builtin: bool = False


@dataclass(eq=False)
class PivotSource(FromItem):
    source: Optional[FromItem] = None
    kind: str = "PIVOT"
    alias: Optional[str] = None


@dataclass(eq=False)
class Join(FromItem):
    join_type: str = "INNER JOIN"
    left: Optional[FromItem] = None
    right: Optional[FromItem] = None
    condition: Optional[Expr] = None


# ---------------------------------------------------------------- statements

@dataclass(eq=False)
class Stmt:
    span: Span = (0, 0)
    line: int = 0


@dataclass(eq=False)
class OutputClause:
    items: List[SelectItem] = field(default_factory=list)
    into: Optional[TableRef] = None


@dataclass(eq=False)
class SelectStmt(Stmt):
    query: Optional[Query] = None


@dataclass(eq=False)
class SetItem:
    target: List[str] = field(default_factory=list)   # column parts or ['@var']
    op: str = "="
    value: Optional[Expr] = None
    is_variable: bool = False


@dataclass(eq=False)
class InsertStmt(Stmt):
    ctes: List[CTE] = field(default_factory=list)
    target: Optional[TableRef] = None
    columns: Optional[List[str]] = None
    query: Optional[Query] = None
    values: List[List[Expr]] = field(default_factory=list)
    exec_stmt: Optional["ExecStmt"] = None
    output: List[OutputClause] = field(default_factory=list)


@dataclass(eq=False)
class UpdateStmt(Stmt):
    ctes: List[CTE] = field(default_factory=list)
    target: Optional[TableRef] = None
    set_items: List[SetItem] = field(default_factory=list)
    from_items: List[FromItem] = field(default_factory=list)
    where: Optional[Expr] = None
    current_of: Optional[str] = None
    output: List[OutputClause] = field(default_factory=list)
    top: Optional[str] = None


@dataclass(eq=False)
class DeleteStmt(Stmt):
    ctes: List[CTE] = field(default_factory=list)
    target: Optional[TableRef] = None
    from_items: List[FromItem] = field(default_factory=list)
    where: Optional[Expr] = None
    current_of: Optional[str] = None
    output: List[OutputClause] = field(default_factory=list)
    top: Optional[str] = None


@dataclass(eq=False)
class MergeWhen:
    match: str = "MATCHED"            # MATCHED | NOT MATCHED | NOT MATCHED BY SOURCE
    condition: Optional[Expr] = None
    action: str = "UPDATE"            # UPDATE | DELETE | INSERT
    set_items: List[SetItem] = field(default_factory=list)
    insert_columns: Optional[List[str]] = None
    values: List[Expr] = field(default_factory=list)


@dataclass(eq=False)
class MergeStmt(Stmt):
    ctes: List[CTE] = field(default_factory=list)
    target: Optional[TableRef] = None
    source: Optional[FromItem] = None
    condition: Optional[Expr] = None
    whens: List[MergeWhen] = field(default_factory=list)
    output: List[OutputClause] = field(default_factory=list)


@dataclass(eq=False)
class TruncateStmt(Stmt):
    target: Optional[TableRef] = None


@dataclass(eq=False)
class CreateTableStmt(Stmt):
    target: Optional[TableRef] = None
    columns: List[str] = field(default_factory=list)


@dataclass(eq=False)
class DropTableStmt(Stmt):
    targets: List[TableRef] = field(default_factory=list)


@dataclass(eq=False)
class DeclareVarStmt(Stmt):
    name: str = ""
    value: Optional[Expr] = None


@dataclass(eq=False)
class DeclareTableVarStmt(Stmt):
    name: str = ""
    columns: List[str] = field(default_factory=list)


@dataclass(eq=False)
class DeclareCursorStmt(Stmt):
    name: str = ""
    query: Optional[Query] = None
    for_update: bool = False


@dataclass(eq=False)
class SetVarStmt(Stmt):
    name: str = ""
    op: str = "="
    value: Optional[Expr] = None


@dataclass(eq=False)
class ExecStmt(Stmt):
    # Dynamic forms: EXEC (<expr>) / EXEC sp_executesql <expr>, ...
    dynamic_expr: Optional[Expr] = None
    dynamic_form: str = ""            # "EXEC()" | "sp_executesql" | ""
    proc_name: List[str] = field(default_factory=list)
    proc_variable: Optional[str] = None   # EXEC @procname
    args: List[Expr] = field(default_factory=list)


@dataclass(eq=False)
class ExprStmt(Stmt):
    """PRINT / RETURN / THROW etc. - only the expressions matter (subqueries)."""
    keyword: str = ""
    exprs: List[Expr] = field(default_factory=list)


@dataclass(eq=False)
class IfStmt(Stmt):
    condition: Optional[Expr] = None
    then: Optional[Stmt] = None
    else_: Optional[Stmt] = None


@dataclass(eq=False)
class WhileStmt(Stmt):
    condition: Optional[Expr] = None
    body: Optional[Stmt] = None


@dataclass(eq=False)
class BlockStmt(Stmt):
    kind: str = "BEGIN"               # BEGIN | TRY | CATCH | DECLARE
    body: List[Stmt] = field(default_factory=list)
    unterminated: bool = False        # batch ended before the matching END


@dataclass(eq=False)
class SkippedStmt(Stmt):
    """A statement deliberately ignored (SET NOCOUNT ON, BEGIN TRAN, ...)."""
    keyword: str = ""


@dataclass(eq=False)
class UnparsedStmt(Stmt):
    """A statement the parser could not handle; never silently dropped."""
    error: str = ""


@dataclass(eq=False)
class NonProcedureObject(Stmt):
    kind: str = ""                    # VIEW | FUNCTION | TRIGGER ...
    name: List[str] = field(default_factory=list)


@dataclass(eq=False)
class ProcedureDef(Stmt):
    name: List[str] = field(default_factory=list)
    params: List[str] = field(default_factory=list)
    body: List[Stmt] = field(default_factory=list)


# ---------------------------------------------------------------- traversal

def expr_children(node) -> Iterator:
    """Direct child expressions / queries of an expression node."""
    if isinstance(node, (ColumnExpr, StarExpr, LiteralExpr, VariableExpr)):
        return
    if isinstance(node, FuncExpr):
        yield from node.args
        yield from node.window
    elif isinstance(node, (BinaryExpr, ComparisonExpr)):
        yield node.left
        yield node.right
    elif isinstance(node, (UnaryExpr, NotExpr, IsNullExpr)):
        yield node.operand
    elif isinstance(node, BoolExpr):
        yield from node.items
    elif isinstance(node, InExpr):
        yield node.operand
        yield from node.values
        if node.query is not None:
            yield node.query
    elif isinstance(node, BetweenExpr):
        yield node.operand
        yield node.low
        yield node.high
    elif isinstance(node, LikeExpr):
        yield node.operand
        yield node.pattern
        if node.escape is not None:
            yield node.escape
    elif isinstance(node, (ExistsExpr, SubqueryExpr)):
        yield node.query
    elif isinstance(node, CaseExpr):
        if node.operand is not None:
            yield node.operand
        for cond, res in node.whens:
            yield cond
            yield res
        if node.else_ is not None:
            yield node.else_
