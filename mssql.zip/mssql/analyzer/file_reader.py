"""Discover and read stored-procedure source files.

SSMS "Script As" output is frequently UTF-16 LE with a BOM, so BOMs are
honoured first, then strict UTF-8, then Windows-1252 (with a note). Files
are never modified.
"""
from __future__ import annotations

import codecs
from pathlib import Path
from typing import Iterable, List, Tuple


class FileReadError(Exception):
    pass


def discover_sql_files(directory: Path, extensions: Iterable[str], recursive: bool = True) -> List[Path]:
    exts = {e.lower() if e.startswith(".") else "." + e.lower() for e in extensions}
    pattern = "**/*" if recursive else "*"
    files = [p for p in directory.glob(pattern) if p.is_file() and p.suffix.lower() in exts]
    return sorted(files, key=lambda p: str(p).lower())


def _looks_like_utf16_le(data: bytes) -> bool:
    sample = data[:4096]
    return len(sample) >= 4 and sample[1::2].count(0) > len(sample) // 4


def read_sql_file(path: Path, max_bytes: int = 50 * 1024 * 1024) -> Tuple[str, str, List[str]]:
    """Return (text, encoding, notes). Raises FileReadError if unreadable."""
    try:
        size = path.stat().st_size
        if size > max_bytes:
            raise FileReadError(f"File is {size:,} bytes, above the {max_bytes:,} byte limit")
        data = path.read_bytes()
    except OSError as exc:
        raise FileReadError(f"Cannot read file: {exc}") from exc

    notes: List[str] = []
    try:
        if data.startswith(codecs.BOM_UTF8):
            return data[len(codecs.BOM_UTF8):].decode("utf-8"), "utf-8-sig", notes
        if data.startswith(codecs.BOM_UTF16_LE) or data.startswith(codecs.BOM_UTF16_BE):
            return data.decode("utf-16"), "utf-16", notes
        if _looks_like_utf16_le(data):
            notes.append("No BOM; decoded as UTF-16 LE based on byte pattern")
            return data.decode("utf-16-le"), "utf-16-le", notes
    except UnicodeDecodeError as exc:
        raise FileReadError(f"Encoding error despite byte-order mark: {exc}") from exc

    try:
        return data.decode("utf-8"), "utf-8", notes
    except UnicodeDecodeError:
        pass
    try:
        text = data.decode("cp1252")
        notes.append("Not valid UTF-8; decoded as Windows-1252")
        return text, "cp1252", notes
    except UnicodeDecodeError:
        pass
    notes.append("Not valid UTF-8 or Windows-1252; decoded as Latin-1 (some characters may be wrong)")
    return data.decode("latin-1"), "latin-1", notes
