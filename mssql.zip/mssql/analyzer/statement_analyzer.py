"""Semantic analysis of parsed T-SQL statements.

Walks the AST produced by analyzer.parser and records, per procedure:

* every referenced object with its operations (SELECT/INSERT/UPDATE/...)
* JOIN/ON predicates with resolved left/right columns
* WHERE / HAVING / MERGE WHEN filter columns
* unresolved or ambiguous column references (never guessed)
* dynamic SQL, analysed when its text is statically known

Columns that appear only in SELECT lists, SET clauses, GROUP BY or ORDER BY
are not reported. Subqueries anywhere (including those places) are still
analysed, because their own FROM/WHERE clauses are dependencies.
"""
from __future__ import annotations

import logging
from contextlib import contextmanager
from dataclasses import replace
from typing import Dict, List, Optional, Tuple

from models import (
    AnalysisIssue, ColumnRef, Confidence, DynamicSqlRecord, FilterCondition,
    IssueType, JoinCondition, ObjectRef, ObjectType, ProcedureAnalysis, Severity,
    TableUsage, UnresolvedColumn,
)
from models.common import quote_ident

from . import ast_nodes as A
from .dynamic_sql_analyzer import DynamicSqlTracker, Runtime
from .keywords import RESERVED
from .object_resolver import ObjectResolver
from .options import AnalysisOptions
from .parser import Parser, render_tokens
from .performance import PerfInspector
from .scope_manager import (
    CTE, DERIVED, FUNCTION, OBJECT, PIVOT, VALUES, ColumnLineage, DerivedInfo,
    Scope, Source, find_source, resolve_column, resolve_in_source,
)
from .tokenizer import OP, QIDENT, VARIABLE, WORD, Token, TokenizeError, tokenize

log = logging.getLogger(__name__)

_FLIP = {"<": ">", ">": "<", "<=": ">=", ">=": "<=", "!<": "!>", "!>": "!<"}
_FALLBACK_KEYWORDS = frozenset({"FROM", "JOIN", "INTO", "USING", "MERGE", "TABLE", "APPLY"})

ColItem = Tuple[ColumnRef, Tuple[str, ...], bool]   # (ref, wrapping functions, inside aggregate)
CteEnv = Dict[str, "CteEntry"]


class CteEntry:
    __slots__ = ("name", "info", "in_progress", "recursive")

    def __init__(self, name: str):
        self.name = name
        self.info: Optional[DerivedInfo] = None
        self.in_progress = True
        self.recursive = False


class ProcedureContext:
    """Mutable per-procedure state shared by static and dynamic-SQL analyzers."""

    def __init__(self, result: ProcedureAnalysis, options: AnalysisOptions,
                 resolver: ObjectResolver):
        self.result = result
        self.options = options
        self.resolver = resolver
        self.temp_columns: Dict[str, Optional[set]] = {}
        self.table_var_columns: Dict[str, set] = {}
        self.dynamic_depth = 0
        self._issue_keys: set = set()
        self._unresolved_keys: set = set()

    def issue(self, severity: str, issue_type: str, description: str, line: int = 0) -> None:
        key = (severity, issue_type, description, line)
        if key in self._issue_keys:
            return
        self._issue_keys.add(key)
        self.result.issues.append(AnalysisIssue(severity, issue_type, description, line))
        # Issues are reported in the workbook; the log keeps them at INFO so the
        # console is not flooded on large runs.
        log.info("%s [%s] %s: %s (line %s)", self.result.full_name, severity, issue_type,
                 description, line)

    def use_object(self, obj: ObjectRef, ops: List[str], alias: Optional[str], confidence: str,
                   line: int, context: str, dynamic: bool, fallback: bool = False) -> TableUsage:
        usage = self.result.tables.get(obj.key)
        if usage is None:
            usage = TableUsage(obj=obj, confidence=Confidence.LOW if fallback else confidence)
            self.result.tables[obj.key] = usage
        for op in ops:
            usage.add_operation(op)
        if alias:
            usage.add_alias(alias)
        usage.note_reference(line, context, confidence, dynamic, fallback)
        return usage

    def record_column(self, ref: ColumnRef, bucket: str) -> None:
        if ref.table is None:
            return
        usage = self.result.tables.get(ref.table.key)
        if usage is None:
            usage = TableUsage(obj=ref.table)
            self.result.tables[ref.table.key] = usage
        usage.add_column(bucket, ref.column)

    def add_unresolved(self, clause: str, ref: ColumnRef, context: str, line: int) -> None:
        key = (clause, (ref.original or ref.column).upper(), ref.note, context)
        if key in self._unresolved_keys:
            return
        self._unresolved_keys.add(key)
        self.result.unresolved.append(UnresolvedColumn(clause, ref, context, line))


class StatementAnalyzer:
    def __init__(self, ctx: ProcedureContext, tokens: List[Token], text: str,
                 dynamic: bool = False, context_prefix: str = "", line_override: int = 0,
                 tracker: Optional[DynamicSqlTracker] = None,
                 statement_prefix: Optional[str] = None):
        self.ctx = ctx
        self.tokens = tokens
        self.text = text
        self.dynamic = dynamic
        self.base_confidence = Confidence.MEDIUM if dynamic else Confidence.HIGH
        self.frames: List[str] = [context_prefix] if context_prefix else []
        self.line_override = line_override
        self.tracker = tracker or DynamicSqlTracker(ctx.result.parameters,
                                                    ctx.options.max_dynamic_sql_variants)
        self.done_queries: set = set()
        # Performance review state. Statement IDs: S1, S2 ... for static SQL;
        # S7.D1 (or S7.V2.D1 for a conditional variant) inside dynamic SQL.
        self.statement_prefix = statement_prefix
        self._dynamic_counter = 0
        self.stmt_id = statement_prefix.rstrip(".") if statement_prefix else "S0"
        self.stmt_line_current = line_override
        self.in_loop = False
        self.item_sources: Dict[int, Source] = {}       # id(FromItem) -> Source
        self.join_scope_len: Dict[int, int] = {}        # id(Join) -> sources visible to ON
        self.query_info: Dict[int, DerivedInfo] = {}    # id(Query) -> lineage / correlation
        self.query_scopes: Dict[int, Scope] = {}        # id(SelectQuery) -> its scope
        self.outer_uses: Dict[int, Dict[str, str]] = {}  # source id -> columns used from inner
        self.perf = PerfInspector(self)

    # ------------------------------------------------------------ helpers
    @contextmanager
    def frame(self, label: str):
        self.frames.append(label)
        try:
            yield
        finally:
            self.frames.pop()

    @property
    def context(self) -> str:
        return " > ".join(self.frames)

    def line_of(self, node) -> int:
        if self.line_override:
            return self.line_override
        span = getattr(node, "span", (0, 0))
        if span[1] > span[0]:
            return self.tokens[span[0]].line
        return getattr(node, "line", 0)

    def stmt_line(self, stmt: A.Stmt) -> int:
        return self.line_override or stmt.line

    def orig(self, node) -> str:
        return render_tokens(self.tokens, self.text, node.span)

    # ------------------------------------------------------------ statements
    def analyze_statements(self, stmts: List[A.Stmt], conditional: bool = False,
                           in_loop: bool = False) -> None:
        for stmt in stmts:
            self.analyze_statement_safe(stmt, conditional, in_loop)

    def next_statement_id(self) -> str:
        if self.statement_prefix is None:
            self.ctx.result.statement_ids_assigned += 1
            return f"S{self.ctx.result.statement_ids_assigned}"
        self._dynamic_counter += 1
        return f"{self.statement_prefix}D{self._dynamic_counter}"

    def analyze_statement_safe(self, stmt: A.Stmt, conditional: bool, in_loop: bool) -> None:
        if not isinstance(stmt, (A.BlockStmt, A.IfStmt, A.WhileStmt, A.SkippedStmt)):
            self.ctx.result.statements_total += 1
        if not isinstance(stmt, (A.BlockStmt, A.SkippedStmt)):
            self.stmt_id = self.next_statement_id()
            self.stmt_line_current = self.stmt_line(stmt)
        self.in_loop = in_loop
        try:
            self.analyze_statement(stmt, conditional, in_loop)
        except RecursionError:
            self.ctx.issue(Severity.WARNING, IssueType.INTERNAL_ERROR,
                           "Statement nested too deeply to analyse", self.stmt_line(stmt))
        except Exception as exc:  # one bad statement must not stop the procedure
            log.exception("Analyzer error in %s at line %s", self.ctx.result.full_name,
                          self.stmt_line(stmt))
            self.ctx.issue(Severity.WARNING, IssueType.INTERNAL_ERROR,
                           f"Statement could not be fully analysed: {type(exc).__name__}: {exc}",
                           self.stmt_line(stmt))

    def analyze_statement(self, stmt: A.Stmt, conditional: bool, in_loop: bool) -> None:
        line = self.stmt_line(stmt)
        if isinstance(stmt, A.BlockStmt):
            if stmt.unterminated:
                self.ctx.issue(Severity.WARNING, IssueType.UNSUPPORTED_SYNTAX,
                               f"BEGIN block starting at line {line} has no matching END", line)
            self.analyze_statements(stmt.body, conditional, in_loop)
        elif isinstance(stmt, A.IfStmt):
            with self.frame(f"IF condition (line {line})"):
                self.scan_expr(stmt.condition, None, {})
            if stmt.then is not None:
                self.analyze_statement_safe(stmt.then, True, in_loop)
            if stmt.else_ is not None:
                self.analyze_statement_safe(stmt.else_, True, in_loop)
        elif isinstance(stmt, A.WhileStmt):
            with self.frame(f"WHILE (line {line})"):
                self.perf.check_loop(stmt, line)
            with self.frame(f"WHILE condition (line {line})"):
                self.scan_expr(stmt.condition, None, {})
            if stmt.body is not None:
                self.analyze_statement_safe(stmt.body, True, True)
        elif isinstance(stmt, A.SelectStmt):
            with self.frame(f"SELECT (line {line})"):
                self.analyze_query(stmt.query, None, {}, ["SELECT"], "SELECT",
                                   conditional=conditional, in_loop=in_loop)
                if not self._assigns_variables(stmt.query):
                    self.perf.check_select_star(stmt.query, "result set", line)
        elif isinstance(stmt, A.InsertStmt):
            with self.frame(f"INSERT (line {line})"):
                self.analyze_insert(stmt, line)
        elif isinstance(stmt, A.UpdateStmt):
            with self.frame(f"UPDATE (line {line})"):
                self.analyze_update_delete(stmt, "UPDATE", line)
        elif isinstance(stmt, A.DeleteStmt):
            with self.frame(f"DELETE (line {line})"):
                self.analyze_update_delete(stmt, "DELETE", line)
        elif isinstance(stmt, A.MergeStmt):
            with self.frame(f"MERGE (line {line})"):
                self.analyze_merge(stmt, line)
        elif isinstance(stmt, A.TruncateStmt):
            with self.frame(f"TRUNCATE (line {line})"):
                src = self.make_table_source(stmt.target.name, None, {}, line)
                self.write_to(src, "TRUNCATE", line)
                self.perf.record_write(src, "TRUNCATE", line)
        elif isinstance(stmt, A.CreateTableStmt):
            obj = self.ctx.resolver.object_ref(stmt.target.name)
            if obj.object_type in ObjectType.TEMP_OBJECTS:
                self.ctx.temp_columns[obj.name.upper()] = {c.upper() for c in stmt.columns}
            with self.frame(f"CREATE TABLE (line {line})"):
                self.ctx.use_object(obj, ["CREATE"], None, self.base_confidence, line,
                                    self.context, self.dynamic)
        elif isinstance(stmt, A.DropTableStmt):
            with self.frame(f"DROP TABLE (line {line})"):
                for target in stmt.targets:
                    obj = self.ctx.resolver.object_ref(target.name)
                    self.ctx.use_object(obj, ["DROP"], None, self.base_confidence, line,
                                        self.context, self.dynamic)
        elif isinstance(stmt, A.DeclareTableVarStmt):
            self.ctx.table_var_columns[stmt.name.upper()] = {c.upper() for c in stmt.columns}
            with self.frame(f"DECLARE (line {line})"):
                self.ctx.use_object(ObjectRef(stmt.name, ObjectType.TABLE_VARIABLE), ["DECLARE"],
                                    None, self.base_confidence, line, self.context, self.dynamic)
        elif isinstance(stmt, A.DeclareCursorStmt):
            with self.frame(f"CURSOR {stmt.name} (line {line})"):
                if stmt.query is not None:
                    self.analyze_query(stmt.query, None, {}, ["SELECT"], f"cursor {stmt.name}")
                    self.perf.check_select_star(stmt.query, "cursor", line)
        elif isinstance(stmt, A.DeclareVarStmt):
            if stmt.value is None:
                self.tracker.declare(stmt.name)
            else:
                with self.frame(f"DECLARE (line {line})"):
                    self.scan_expr(stmt.value, None, {})
                self.tracker.assign(stmt.name, "=", stmt.value, conditional, in_loop)
        elif isinstance(stmt, A.SetVarStmt):
            with self.frame(f"SET (line {line})"):
                self.scan_expr(stmt.value, None, {})
            self.tracker.assign(stmt.name, stmt.op, stmt.value, conditional, in_loop)
        elif isinstance(stmt, A.ExecStmt):
            with self.frame(f"EXEC (line {line})"):
                self.analyze_exec(stmt, line)
        elif isinstance(stmt, A.ExprStmt):
            with self.frame(f"{stmt.keyword} (line {line})"):
                for expr in stmt.exprs:
                    self.scan_expr(expr, None, {})
        elif isinstance(stmt, A.UnparsedStmt):
            self.ctx.result.statements_failed += 1
            snippet = render_tokens(self.tokens, self.text, stmt.span)
            if len(snippet) > 160:
                snippet = snippet[:157] + "..."
            self.ctx.issue(Severity.WARNING, IssueType.UNSUPPORTED_SYNTAX,
                           f"Statement not analysed ({stmt.error}). Statement text: {snippet}", line)
            if self.ctx.options.fallback_scan_unparsed:
                self.fallback_scan(stmt.span, line)
        elif isinstance(stmt, A.NonProcedureObject):
            self.ctx.issue(Severity.WARNING, IssueType.MISSING_SP_DEFINITION,
                           f"{stmt.kind} {'.'.join(stmt.name)} is not a stored procedure; "
                           f"its body was not analysed", line)
        elif isinstance(stmt, A.ProcedureDef):
            self.ctx.issue(Severity.WARNING, IssueType.UNSUPPORTED_SYNTAX,
                           f"Nested procedure definition {'.'.join(stmt.name)} ignored", line)
        # SkippedStmt: intentionally nothing

    # ------------------------------------------------------------ CTEs
    def analyze_ctes(self, ctes: List[A.CTE], env: CteEnv) -> CteEnv:
        if not ctes:
            return env
        env = dict(env)
        for cte in ctes:
            entry = CteEntry(cte.name)
            env[cte.name.upper()] = entry
            label = f"CTE {cte.name}"
            with self.frame(f"{label} (line {self.line_override or cte.line})"):
                info = self.analyze_query(cte.query, None, env, ["SELECT"], label)
            if cte.columns:
                info = info.renamed(cte.columns)
            info.label = label
            if entry.recursive:
                info.recursive = True
                self.ctx.issue(Severity.WARNING, IssueType.RECURSIVE_CTE,
                               f"Recursive CTE '{cte.name}': base tables are reported, but column "
                               f"lineage through the recursive member is not traced",
                               self.line_override or cte.line)
            entry.info = info
            entry.in_progress = False
        return env

    # ------------------------------------------------------------ queries
    def analyze_subquery(self, query: A.Query, scope: Optional[Scope], env: CteEnv,
                         label: str = "Subquery") -> DerivedInfo:
        self.done_queries.add(id(query))
        with self.frame(label):
            return self.analyze_query(query, scope, env, ["SELECT"], label)

    def analyze_query(self, query: A.Query, parent: Optional[Scope], env: CteEnv,
                      ops: List[str], label: str, conditional: bool = False,
                      in_loop: bool = False) -> DerivedInfo:
        self.done_queries.add(id(query))
        env = self.analyze_ctes(query.ctes, env)
        if isinstance(query, A.SetOpQuery):
            left = self.analyze_query(query.left, parent, env, ops, label, conditional, in_loop)
            right = self.analyze_query(query.right, parent, env, ops, label, conditional, in_loop)
            for expr in query.order_by:
                self.scan_expr(expr, None, env)
            info = self.merge_set_op(left, right, label)
            info.outer_refs = left.outer_refs | right.outer_refs
            self.query_info[id(query)] = info
            self.record_set_op_order_by(query, info)
            return info

        scope = Scope(parent=parent, label=label)
        self.build_from(query.from_items, scope, env, ops)
        self.commit_sources(scope)
        if query.into is not None:
            self.handle_select_into(query)
        if query.where is not None:
            self.analyze_condition(query.where, scope, env, "WHERE")
        if query.having is not None:
            self.analyze_condition(query.having, scope, env, "HAVING")
        exists_list = "EXISTS" in label   # EXISTS (SELECT * ...) reads no columns
        for item in query.items:
            if isinstance(item.expr, A.StarExpr):
                if not exists_list:
                    self.record_star(item.expr, scope)
            elif item.expr is not None:
                self.record_clause_columns(item.expr, scope, "SELECT")
            if item.expr is not None:
                self.scan_expr(item.expr, scope, env)
            if item.assign_var:
                self.tracker.assign(item.assign_var, item.assign_op, item.expr,
                                    conditional or bool(query.from_items), in_loop,
                                    row_dependent=self._reads_columns(item.expr))
        for expr in query.group_by:
            self.record_clause_columns(expr, scope, "GROUP BY")
            self.scan_expr(expr, scope, env)
        for expr in query.order_by:
            self.record_clause_columns(self.order_by_target(expr, query.items), scope, "ORDER BY")
            self.scan_expr(expr, scope, env)
        self.query_scopes[id(query)] = scope
        self.perf.query_block(query, scope, label)
        info = self.build_derived_info(query, scope, label)
        info.outer_refs = set(scope.outer_refs)
        info.single_row = self.perf.query_single_row(query)
        self.query_info[id(query)] = info
        return info

    @staticmethod
    def _assigns_variables(query) -> bool:
        return isinstance(query, A.SelectQuery) and any(i.assign_var for i in query.items)

    # ------------------------------------------------------------ SELECT / SET / GROUP BY / ORDER BY
    def record_clause_columns(self, expr, scope: Optional[Scope], clause: str) -> None:
        """Record the columns ``expr`` reads under ``clause`` (subqueries are analysed
        separately by scan_expr, so their columns are not attributed here)."""
        if expr is None:
            return
        line = self.line_of(expr)
        for ref, _, _ in self.collect_columns(expr, scope):
            self.record_clause_ref(ref, clause, line)

    def record_clause_ref(self, ref: ColumnRef, clause: str, line: int) -> None:
        self.ctx.record_column(ref, clause)
        # Ambiguous / unresolvable references are listed; a column computed inside
        # a CTE or derived table is not, its source columns were recorded there.
        if ref.confidence == Confidence.LOW and (ref.candidates or not ref.owner_label):
            self.ctx.add_unresolved(clause, ref, self.context, line)

    def record_star(self, star: A.StarExpr, scope: Scope) -> None:
        """SELECT * / SELECT t.* reads every column: recorded as column '*'."""
        if star.qualifier:
            src, _ = find_source(scope, star.qualifier)
            sources = [src] if src is not None else []
        else:
            sources = scope.sources
        for src in sources:
            if src.kind == OBJECT and src.obj is not None:
                self.ctx.record_column(ColumnRef("*", src.obj, src.confidence), "SELECT")

    @staticmethod
    def order_by_target(expr, items: List[A.SelectItem]):
        """ORDER BY binds select-list aliases and ordinals before table columns."""
        if isinstance(expr, A.LiteralExpr) and expr.kind == "number" and expr.value.isdigit():
            idx = int(expr.value) - 1
            if 0 <= idx < len(items) and not isinstance(items[idx].expr, A.StarExpr):
                return items[idx].expr
            return None
        if isinstance(expr, A.ColumnExpr) and len(expr.parts) == 1:
            name = expr.parts[0].upper()
            for item in items:
                if item.alias and item.alias.upper() == name:
                    return item.expr
        return expr

    def record_set_op_order_by(self, query: A.SetOpQuery, info: DerivedInfo) -> None:
        """ORDER BY of a UNION / EXCEPT / INTERSECT names the combined output columns."""
        for expr in query.order_by:
            if not (isinstance(expr, A.ColumnExpr) and len(expr.parts) == 1):
                continue
            lineage = info.columns.get(expr.parts[0].upper())
            if lineage is None:
                continue
            for ref in lineage.refs:
                self.ctx.record_column(ref, "ORDER BY")

    def record_set_targets(self, items: List[A.SetItem], target: Source, scope: Scope) -> None:
        """UPDATE / MERGE ... SET col = value: the assigned column and the columns read."""
        for item in items:
            if not item.is_variable and item.target:
                parts = item.target
                # an unqualified SET column always belongs to the statement's target
                refs = (resolve_in_source(target, parts[0], ".".join(parts)) if len(parts) == 1
                        else resolve_column(scope, parts, ".".join(parts)))
                line = self.line_of(item.value) if item.value is not None else 0
                for ref in refs:
                    self.record_clause_ref(ref, "SET", line)
            self.record_clause_columns(item.value, scope, "SET")

    @staticmethod
    def _reads_columns(expr) -> bool:
        stack = [expr]
        while stack:
            node = stack.pop()
            if node is None:
                continue
            if isinstance(node, (A.ColumnExpr, A.Query)):
                return True
            stack.extend(A.expr_children(node))
        return False

    def merge_set_op(self, left: DerivedInfo, right: DerivedInfo, label: str) -> DerivedInfo:
        info = DerivedInfo(label, base_sources=left.base_sources + right.base_sources)
        if left.star_sources or right.star_sources:
            info.star_sources = left.star_sources + right.star_sources
            return info
        for idx, lcol in enumerate(left.ordered):
            rcol = right.ordered[idx] if idx < len(right.ordered) else None
            refs = []
            seen = set()
            for ref in list(lcol.refs) + (list(rcol.refs) if rcol else []):
                key = (ref.table.key if ref.table is not None else ref.owner_label,
                       ref.column.upper())
                if key not in seen:
                    seen.add(key)
                    refs.append(ref)
            direct = lcol.direct and rcol is not None and rcol.direct
            expr = lcol.expression if rcol is None else f"{lcol.expression} | {rcol.expression}"
            info.add(ColumnLineage(lcol.name, refs, direct, expr))
        return info

    def build_derived_info(self, query: A.SelectQuery, scope: Scope, label: str) -> DerivedInfo:
        info = DerivedInfo(label, base_sources=list(scope.sources))
        for item in query.items:
            expr = item.expr
            if isinstance(expr, A.StarExpr):
                src = None
                if expr.qualifier:
                    src, _ = find_source(scope, expr.qualifier)
                info.star_sources.append((scope, src))
                continue
            if item.assign_var or expr is None:
                continue
            name = item.alias or (expr.parts[-1] if isinstance(expr, A.ColumnExpr) else None)
            if not name:
                continue
            refs = [r for r, _, _ in self.collect_columns(expr, scope)]
            info.add(ColumnLineage(name, refs, isinstance(expr, A.ColumnExpr), self.norm(expr, scope)))
        return info

    def handle_select_into(self, query: A.SelectQuery) -> None:
        target = query.into
        obj = self.ctx.resolver.object_ref(target.name)
        if obj.object_type in ObjectType.TEMP_OBJECTS:
            cols: Optional[set] = set()
            for item in query.items:
                if isinstance(item.expr, A.StarExpr):
                    cols = None
                    break
                name = item.alias or (item.expr.parts[-1] if isinstance(item.expr, A.ColumnExpr) else None)
                if name:
                    cols.add(name.upper())
            self.ctx.temp_columns[obj.name.upper()] = cols
        self.ctx.use_object(obj, ["SELECT INTO"], None, self.base_confidence,
                            self.line_override or target.line, self.context, self.dynamic)

    # ------------------------------------------------------------ FROM clause
    def build_from(self, items: List[A.FromItem], scope: Scope, env: CteEnv, ops: List[str]) -> None:
        for idx, item in enumerate(items):
            item_ops = list(ops) if idx == 0 else list(ops) + ["JOIN"]   # comma join
            self.walk_from_item(item, scope, env, item_ops, join_right=idx > 0)

    def walk_from_item(self, item: A.FromItem, scope: Scope, env: CteEnv, ops: List[str],
                       join_right: bool = False, lateral: bool = False) -> None:
        line = self.line_override or item.line
        if isinstance(item, A.Join):
            self.walk_from_item(item.left, scope, env, ops, join_right)
            if item.join_type in ("CROSS APPLY", "OUTER APPLY"):
                self.walk_from_item(item.right, scope, env, ["SELECT", "APPLY"], True, lateral=True)
            else:
                self.walk_from_item(item.right, scope, env, ["SELECT", "JOIN"], True)
            self.join_scope_len[id(item)] = len(scope.sources)
            if item.condition is not None:
                self.analyze_condition(item.condition, scope, env, "ON", join_type=item.join_type)
            return
        if isinstance(item, A.TableRef):
            src = self.make_table_source(item.name, item.alias, env, line)
            src.ops = list(ops)
            src.join_right = join_right
            scope.add(src)
            self.item_sources[id(item)] = src
            return
        if isinstance(item, A.DerivedTable):
            label = f"Derived table {item.alias or '(unnamed)'}"
            inner_ops = ["SELECT", "APPLY"] if lateral else ["SELECT"]
            with self.frame(label):
                info = self.analyze_query(item.query, scope if lateral else scope.parent, env,
                                          inner_ops, label)
            if item.column_aliases:
                info = info.renamed(item.column_aliases)
            info.label = label
            src = Source(DERIVED, alias=item.alias, derived=info, label=label,
                         obj=ObjectRef(item.alias or "(unnamed)", ObjectType.DERIVED),
                         name_parts=[], confidence=self.base_confidence, line=line)
            src.ops = list(ops)
            src.join_right = join_right
            scope.add(src)
            self.item_sources[id(item)] = src
            return
        if isinstance(item, A.ValuesTable):
            for row in item.rows:
                for expr in row:
                    self.scan_expr(expr, scope, env)
            known = {c.upper() for c in item.column_aliases} if item.column_aliases else None
            src = Source(VALUES, alias=item.alias, known_columns=known,
                         label=f"VALUES {item.alias or ''}".strip(), line=line)
            if len(item.rows) == 1:
                src.single_row = "VALUES with one row"
            scope.add(src)
            self.item_sources[id(item)] = src
            return
        if isinstance(item, A.FunctionSource):
            for arg in item.args:
                self.scan_expr(arg, scope, env)
            obj = self.ctx.resolver.function_ref(item.name, item.builtin)
            known = {c.upper() for c in item.column_aliases} if item.column_aliases else None
            src = Source(FUNCTION, alias=item.alias, obj=obj, name_parts=item.name,
                         known_columns=known, label=f"{obj.display_name}()",
                         confidence=self.base_confidence, line=line)
            src.ops = list(ops)
            src.join_right = join_right
            scope.add(src)
            self.item_sources[id(item)] = src
            fname = obj.display_name
            if fname not in self.ctx.result.functions_called:
                self.ctx.result.functions_called.append(fname)
            return
        if isinstance(item, A.PivotSource):
            inner = Scope(parent=scope.parent, label="PIVOT source")
            self.walk_from_item(item.source, inner, env, ops, join_right, lateral)
            self.commit_sources(inner)
            src = Source(PIVOT, alias=item.alias, label=f"{item.kind} {item.alias or ''}".strip(),
                         line=line)
            scope.add(src)
            self.item_sources[id(item)] = src
            return
        raise TypeError(f"Unsupported FROM item {type(item).__name__}")

    def make_table_source(self, parts: List[str], alias: Optional[str], env: CteEnv,
                          line: int) -> Source:
        if len(parts) == 1 and parts[0].upper() in env and not parts[0].startswith(("#", "@")):
            entry = env[parts[0].upper()]
            if entry.in_progress:
                entry.recursive = True
            return Source(CTE, alias=alias, obj=ObjectRef(entry.name, ObjectType.CTE),
                          name_parts=parts, derived=entry.info, label=f"CTE {entry.name}",
                          confidence=self.base_confidence, line=line)
        obj = self.ctx.resolver.object_ref(parts)
        known = None
        if obj.object_type in ObjectType.TEMP_OBJECTS:
            known = self.ctx.temp_columns.get(obj.name.upper())
        elif obj.object_type == ObjectType.TABLE_VARIABLE:
            known = self.ctx.table_var_columns.get(obj.name.upper())
        return Source(OBJECT, alias=alias, obj=obj, name_parts=parts, known_columns=known,
                      label=obj.display_name, confidence=self.base_confidence, line=line)

    def commit_sources(self, scope: Scope) -> None:
        for src in scope.sources:
            if src.committed or not src.ops or src.obj is None:
                continue
            src.committed = True
            self.ctx.use_object(src.obj, src.ops, src.alias, src.confidence, src.line,
                                self.context, self.dynamic)

    # ------------------------------------------------------------ DML
    def write_to(self, src: Source, op: str, line: int, extra_ops: Tuple[str, ...] = ()) -> None:
        """Record a write (INSERT/UPDATE/DELETE/...) against ``src``."""
        if src.kind == OBJECT:
            self.ctx.use_object(src.obj, [op, *extra_ops], src.alias, src.confidence, line,
                                self.context, self.dynamic)
            src.committed = True
            return
        if src.kind in (CTE, DERIVED):
            if src.obj is not None:
                self.ctx.use_object(src.obj, [op], src.alias, src.confidence, line,
                                    self.context, self.dynamic)
            self.write_through(src, op, line, 0)
            return
        self.ctx.issue(Severity.WARNING, IssueType.LINEAGE,
                       f"{op} target {src.label} is not a table; underlying object unknown", line)

    def write_through(self, src: Source, op: str, line: int, depth: int) -> None:
        info = src.derived
        bases = info.base_sources if info is not None else []
        if len(bases) == 1 and depth < 10:
            base = bases[0]
            if base.kind == OBJECT:
                self.ctx.use_object(base.obj, [op], None,
                                    Confidence.cap(base.confidence, Confidence.MEDIUM), line,
                                    f"{self.context} (through {src.label})", self.dynamic)
                return
            if base.kind in (CTE, DERIVED):
                self.write_through(base, op, line, depth + 1)
                return
        self.ctx.issue(Severity.WARNING, IssueType.LINEAGE,
                       f"{op} through {src.label}: the underlying table cannot be determined "
                       f"statically (it does not read exactly one table)", line)

    def analyze_output(self, outputs: List[A.OutputClause], line: int) -> None:
        for clause in outputs:
            if clause.into is not None:
                with self.frame("OUTPUT INTO"):
                    src = self.make_table_source(clause.into.name, None, {}, line)
                    self.write_to(src, "INSERT", line)

    def analyze_insert(self, stmt: A.InsertStmt, line: int) -> None:
        env = self.analyze_ctes(stmt.ctes, {})
        target = self.make_table_source(stmt.target.name, None, env, line)
        self.write_to(target, "INSERT", line)
        self.perf.record_write(target, "INSERT", line)
        if stmt.query is not None:
            self.analyze_query(stmt.query, None, env, ["SELECT"], "INSERT source")
            self.perf.check_select_star(stmt.query, "INSERT ... SELECT", line)
        for row in stmt.values:
            for expr in row:
                self.scan_expr(expr, None, env)
        if stmt.exec_stmt is not None:
            self.analyze_exec(stmt.exec_stmt, line)
        self.analyze_output(stmt.output, line)

    def find_target(self, scope: Scope, target: A.TableRef) -> Optional[Source]:
        for src in scope.sources:
            if src.matches(target.name):
                return src
        return None

    def analyze_update_delete(self, stmt, op: str, line: int) -> None:
        env = self.analyze_ctes(stmt.ctes, {})
        scope = Scope(label=op)
        if stmt.from_items:
            self.build_from(stmt.from_items, scope, env, ["SELECT"])
        target = self.find_target(scope, stmt.target)
        if target is None:
            target = self.make_table_source(stmt.target.name, None, env, line)
            scope.sources.insert(0, target)
        if target.kind == OBJECT:
            target.ops = [op] + (["JOIN"] if target.join_right else [])
        else:
            self.write_to(target, op, line)
        self.commit_sources(scope)
        if isinstance(stmt, A.UpdateStmt):
            self.record_set_targets(stmt.set_items, target, scope)
            for item in stmt.set_items:
                if item.value is not None:
                    self.scan_expr(item.value, scope, env)
                if item.is_variable:
                    self.tracker.assign(item.target[0], item.op, item.value, True, False,
                                        row_dependent=True)
        if stmt.where is not None:
            self.analyze_condition(stmt.where, scope, env, "WHERE")
        if target.kind == OBJECT:
            self.perf.dml_block(stmt, op, scope, target)
        self.analyze_output(stmt.output, line)

    def analyze_merge(self, stmt: A.MergeStmt, line: int) -> None:
        env = self.analyze_ctes(stmt.ctes, {})
        scope = Scope(label="MERGE")
        target = self.make_table_source(stmt.target.name, stmt.target.alias, env, line)
        actions = []
        for when in stmt.whens:
            if when.action not in actions:
                actions.append(when.action)
        if target.kind == OBJECT:
            target.ops = ["MERGE"] + actions
        else:
            target.ops = ["MERGE"]
            for action in actions:
                self.write_through(target, action, line, 0)
        scope.add(target)
        self.walk_from_item(stmt.source, scope, env, ["SELECT", "MERGE SOURCE"])
        self.commit_sources(scope)
        if stmt.condition is not None:
            self.analyze_condition(stmt.condition, scope, env, "ON", join_type="MERGE ON")
        for when in stmt.whens:
            if when.condition is not None:
                self.analyze_condition(when.condition, scope, env, "MERGE WHEN")
            self.record_set_targets(when.set_items, target, scope)
            for item in when.set_items:
                if item.value is not None:
                    self.scan_expr(item.value, scope, env)
            for expr in when.values:
                self.scan_expr(expr, scope, env)
        if target.kind == OBJECT:
            self.perf.merge_block(stmt, scope, target)
        self.analyze_output(stmt.output, line)

    # ------------------------------------------------------------ EXEC / dynamic SQL
    def analyze_exec(self, stmt: A.ExecStmt, line: int) -> None:
        line = self.line_override or line
        if stmt.dynamic_form:
            self.analyze_dynamic(stmt, line)
        elif stmt.proc_variable:
            self.ctx.result.dynamic_sql.append(DynamicSqlRecord(
                line, "EXEC @variable", stmt.proc_variable,
                "Manual review: procedure name is chosen at runtime"))
            self.ctx.issue(Severity.MANUAL, IssueType.DYNAMIC_SQL,
                           f"EXEC {stmt.proc_variable}: the procedure name is resolved at runtime",
                           line)
        else:
            name = ".".join(p for p in stmt.proc_name if p)
            if name and name not in self.ctx.result.procedures_called:
                self.ctx.result.procedures_called.append(name)
        for arg in stmt.args:
            self.scan_expr(arg, None, {})

    def analyze_dynamic(self, stmt: A.ExecStmt, line: int) -> None:
        form = stmt.dynamic_form
        expr = stmt.dynamic_expr
        expr_text = self.orig(expr) if expr is not None else ""
        if expr is None:
            self.ctx.result.dynamic_sql.append(DynamicSqlRecord(
                line, form, "", "Manual review: no statement argument"))
            self.ctx.issue(Severity.MANUAL, IssueType.DYNAMIC_SQL,
                           f"{form} without a statement argument", line)
            return
        if not self.ctx.options.analyze_dynamic_sql:
            self.ctx.result.dynamic_sql.append(DynamicSqlRecord(
                line, form, expr_text, "Manual review: dynamic SQL analysis disabled"))
            self.ctx.issue(Severity.MANUAL, IssueType.DYNAMIC_SQL,
                           f"Dynamic SQL ({form}) not analysed: disabled in configuration", line)
            return
        value = self.tracker.evaluate(expr)
        if isinstance(value, Runtime):
            reason = value.reason
            self.ctx.result.dynamic_sql.append(DynamicSqlRecord(
                line, form, expr_text, "Manual review: SQL text built at runtime", notes=reason))
            self.ctx.issue(Severity.MANUAL, IssueType.DYNAMIC_SQL,
                           f"Runtime-built dynamic SQL ({form} {expr_text}): {reason}. "
                           f"Objects it touches cannot be determined statically", line)
            return
        if self.ctx.dynamic_depth >= self.ctx.options.max_dynamic_sql_depth:
            self.ctx.result.dynamic_sql.append(DynamicSqlRecord(
                line, form, expr_text, "Manual review: nested dynamic SQL too deep"))
            self.ctx.issue(Severity.MANUAL, IssueType.DYNAMIC_SQL,
                           "Dynamic SQL nested too deeply to analyse", line)
            return
        failures = 0
        for idx, sql in enumerate(value):
            label = f"Dynamic SQL (line {line})"
            prefix = f"{self.stmt_id}."
            if len(value) > 1:
                label += f" variant {idx + 1}/{len(value)}"
                prefix += f"V{idx + 1}."
            if not self.analyze_dynamic_text(sql, line, label, prefix):
                failures += 1
        variants = len(value)
        resolution = "Analyzed (static SQL text)"
        notes = f"{variants} possible variants from conditional assignments" if variants > 1 else ""
        if failures:
            resolution = f"Partially analyzed ({failures} of {variants} variants not parseable)"
        self.ctx.result.dynamic_sql.append(DynamicSqlRecord(line, form, expr_text, resolution,
                                                            variants, notes))
        self.ctx.issue(Severity.INFO, IssueType.DYNAMIC_SQL,
                       f"Dynamic SQL ({form}) with statically known text analysed; "
                       f"results capped at MEDIUM confidence", line)

    def analyze_dynamic_text(self, sql: str, line: int, label: str, prefix: str = "") -> bool:
        try:
            tokens = tokenize(sql)
        except TokenizeError as exc:
            self.ctx.issue(Severity.WARNING, IssueType.DYNAMIC_SQL,
                           f"{label}: SQL text could not be tokenised ({exc})", line)
            return False
        batches = Parser(tokens).parse_script()
        stmts = [s for batch in batches for s in batch]
        sub = StatementAnalyzer(self.ctx, tokens, sql, dynamic=True,
                                context_prefix=" > ".join(self.frames + [label]),
                                line_override=line, statement_prefix=prefix or f"{self.stmt_id}.")
        sub.in_loop = self.in_loop
        before = self.ctx.result.statements_failed
        self.ctx.dynamic_depth += 1
        try:
            sub.analyze_statements(stmts)
        finally:
            self.ctx.dynamic_depth -= 1
        return self.ctx.result.statements_failed == before

    # ------------------------------------------------------------ fallback
    def fallback_scan(self, span: Tuple[int, int], line: int) -> None:
        """Token scan of an unparsed statement: names after FROM/JOIN/INTO...

        Results are LOW confidence, labelled as unverified and excluded from
        the Summary ranking by default.
        """
        s, e = span
        toks = self.tokens
        for i in range(s, e):
            tok = toks[i]
            if tok.kind != WORD or tok.upper not in _FALLBACK_KEYWORDS:
                continue
            j = i + 1
            if j < e and toks[j].kind == WORD and toks[j].upper == "INTO":
                j += 1
            parts: List[str] = []
            if j < e and toks[j].kind == VARIABLE:
                parts = [toks[j].value]
                j += 1
            elif j < e and (toks[j].kind == QIDENT or (toks[j].kind == WORD and toks[j].upper not in RESERVED)):
                parts = [toks[j].value]
                j += 1
                while j + 1 < e and toks[j].kind == OP and toks[j].value == "." \
                        and toks[j + 1].kind in (WORD, QIDENT):
                    parts.append(toks[j + 1].value)
                    j += 2
            if not parts or len(parts) > 4 or (j < e and toks[j].kind == OP and toks[j].value == "("):
                continue
            obj = self.ctx.resolver.object_ref(parts)
            self.ctx.use_object(obj, ["UNPARSED STATEMENT"], None, Confidence.LOW,
                                self.line_override or tok.line,
                                f"{self.context} (token scan of unparsed statement, unverified)".strip(),
                                self.dynamic, fallback=True)

    # ------------------------------------------------------------ expressions
    def scan_expr(self, expr, scope: Optional[Scope], env: CteEnv) -> None:
        """Analyse every not-yet-analysed subquery inside ``expr``."""
        if expr is None:
            return
        stack = [expr]
        while stack:
            node = stack.pop()
            if node is None:
                continue
            if isinstance(node, A.Query):
                if id(node) not in self.done_queries:
                    self.analyze_subquery(node, scope, env)
                continue
            stack.extend(A.expr_children(node))

    def collect_columns(self, expr, scope: Optional[Scope]) -> List[ColItem]:
        out: List[ColItem] = []

        def walk(node, wrappers: Tuple[str, ...], aggregated: bool) -> None:
            if node is None or isinstance(node, A.Query):
                return
            if isinstance(node, A.ColumnExpr):
                for ref in resolve_column(scope, node.parts, self.orig(node)):
                    out.append((ref, wrappers, aggregated))
                return
            if isinstance(node, A.FuncExpr):
                inner = wrappers + (node.name[-1].upper() + "()",)
                for arg in node.args:
                    walk(arg, inner, aggregated or node.aggregate)
                for part in node.window:
                    walk(part, inner + ("OVER",), aggregated)
                return
            if isinstance(node, A.CaseExpr):
                inner = wrappers + ("CASE",)
                for child in A.expr_children(node):
                    walk(child, inner, aggregated)
                return
            for child in A.expr_children(node):
                walk(child, wrappers, aggregated)

        walk(expr, (), False)
        return out

    def analyze_condition(self, expr, scope: Scope, env: CteEnv, clause: str,
                          join_type: Optional[str] = None) -> None:
        full = self.orig(expr) if expr is not None else ""
        for pred, negated, path in self.iter_predicates(expr, False, ()):
            self.record_predicate(pred, negated, scope, env, clause, join_type,
                                  full, " > ".join(path))
        self.scan_expr(expr, scope, env)

    def iter_predicates(self, expr, negated: bool, path: Tuple[str, ...]):
        """Yield (predicate, negated, AND/OR/NOT groups enclosing it)."""
        if isinstance(expr, A.BoolExpr):
            inner = path if path and path[-1] == expr.op else path + (expr.op,)
            for item in expr.items:
                yield from self.iter_predicates(item, negated, inner)
        elif isinstance(expr, A.NotExpr):
            yield from self.iter_predicates(expr.operand, not negated, path + ("NOT",))
        elif expr is not None:
            yield expr, negated, path

    def record_predicate(self, pred, negated: bool, scope: Scope, env: CteEnv, clause: str,
                         join_type: Optional[str], full: str = "", logic: str = "") -> None:
        line = self.line_of(pred)
        original = self.orig(pred)
        right_value = ""
        rcols: List[ColItem] = []
        semi_join: List[ColItem] = []
        is_comparison = False

        if isinstance(pred, A.ExistsExpr):
            self.analyze_subquery(pred.query, scope, env,
                                  "NOT EXISTS subquery" if negated else "EXISTS subquery")
            return
        if isinstance(pred, A.ComparisonExpr):
            is_comparison = True
            op = pred.op + (f" {pred.quantifier}" if pred.quantifier else "")
            lcols = self.collect_columns(pred.left, scope)
            rcols = self.collect_columns(pred.right, scope)
            right_value = self.norm(pred.right, scope)
            left_value = self.norm(pred.left, scope)
        elif isinstance(pred, A.IsNullExpr):
            op = "IS NOT NULL" if pred.negated else "IS NULL"
            lcols = self.collect_columns(pred.operand, scope)
            left_value = self.norm(pred.operand, scope)
        elif isinstance(pred, A.InExpr):
            op = "NOT IN" if pred.negated else "IN"
            lcols = self.collect_columns(pred.operand, scope)
            left_value = self.norm(pred.operand, scope)
            if pred.query is not None:
                right_value = "(subquery)"
                info = self.analyze_subquery(pred.query, scope, env,
                                             "NOT IN subquery" if pred.negated else "IN subquery")
                if len(info.ordered) == 1 and info.ordered[0].direct and info.ordered[0].refs:
                    semi_join = [(r, (), False) for r in info.ordered[0].refs]
            else:
                right_value = "(" + ", ".join(self.norm(v, scope) for v in pred.values) + ")"
                for value in pred.values:
                    rcols.extend(self.collect_columns(value, scope))
        elif isinstance(pred, A.BetweenExpr):
            op = "NOT BETWEEN" if pred.negated else "BETWEEN"
            lcols = self.collect_columns(pred.operand, scope)
            left_value = self.norm(pred.operand, scope)
            right_value = f"{self.norm(pred.low, scope)} AND {self.norm(pred.high, scope)}"
            rcols = self.collect_columns(pred.low, scope) + self.collect_columns(pred.high, scope)
        elif isinstance(pred, A.LikeExpr):
            op = "NOT LIKE" if pred.negated else "LIKE"
            lcols = self.collect_columns(pred.operand, scope)
            left_value = self.norm(pred.operand, scope)
            right_value = self.norm(pred.pattern, scope)
            rcols = self.collect_columns(pred.pattern, scope)
        elif isinstance(pred, A.FuncExpr):
            op = ".".join(pred.name).upper() + "()"
            lcols = self.collect_columns(pred, scope)
            left_value = self.norm(pred, scope)
        else:
            op = "EXPRESSION"
            lcols = self.collect_columns(pred, scope)
            left_value = self.norm(pred, scope)

        if negated:
            op = "NOT " + op
        normalized = self.norm(pred, scope)
        if negated:
            normalized = f"NOT ({normalized})"

        if clause == "ON":
            if not lcols and not rcols:
                return
            if not lcols and rcols:
                lcols, rcols = rcols, lcols
                left_value, right_value = right_value, left_value
                op = _FLIP.get(op, op)
            self.add_join(join_type or "JOIN", lcols, op, rcols,
                          "" if rcols else right_value, original, normalized, line, full, logic)
            return

        for item in lcols:
            self.add_filter(clause, item, op, right_value, original, line, full, logic)
        for item in rcols:
            self.add_filter(clause, item, _FLIP.get(op, op), left_value, original, line, full,
                            logic)

        if semi_join and lcols:
            self.add_join("IN SUBQUERY" if not pred.negated else "NOT IN SUBQUERY", lcols, "=",
                          semi_join, "", original, normalized, line, full, logic)
        elif is_comparison and lcols and rcols:
            lrefs = [r for r, _, _ in lcols]
            rrefs = [r for r, _, _ in rcols]
            all_refs = lrefs + rrefs
            if (all(r.table is not None for r in all_refs)
                    and {r.source_id for r in lrefs}.isdisjoint({r.source_id for r in rrefs})):
                jt = "CORRELATED SUBQUERY" if any(r.outer for r in all_refs) else "WHERE (join predicate)"
                self.add_join(jt, lcols, op, rcols, "", original, normalized, line, full, logic)

    def _notes(self, items: List[ColItem]) -> List[str]:
        notes = []
        for ref, wrappers, aggregated in items:
            if wrappers:
                notes.append(f"{ref.column} inside {', '.join(wrappers)}")
            if ref.note:
                notes.append(f"{ref.column}: {ref.note}")
        return notes

    def add_filter(self, clause: str, item: ColItem, op: str, compared: str, original: str,
                   line: int, full: str = "", logic: str = "") -> None:
        ref, wrappers, aggregated = item
        notes = []
        if wrappers:
            notes.append(f"inside {', '.join(wrappers)}")
            if "CASE" in wrappers:
                notes.append("operator applies to the whole CASE result, not directly to this column")
        if aggregated:
            ref = replace(ref, confidence=Confidence.cap(ref.confidence, Confidence.MEDIUM))
            notes.append("aggregate expression")
        if ref.note:
            notes.append(ref.note)
        if ref.candidates:
            notes.append("candidates: " + ", ".join(ref.candidates))
        self.ctx.result.filters.append(FilterCondition(
            clause=clause, column=ref, operator=op, compared_with=compared, original=original,
            context=self.context, line=line, notes="; ".join(notes), dynamic=self.dynamic,
            full_condition=full or original, logic=logic, locations=[self.context]))
        self.ctx.record_column(ref, "HAVING" if clause == "HAVING" else "WHERE")
        if ref.confidence == Confidence.LOW:
            self.ctx.add_unresolved(clause, ref, self.context, line)

    def add_join(self, join_type: str, lcols: List[ColItem], op: str, rcols: List[ColItem],
                 right_value: str, original: str, normalized: str, line: int,
                 full: str = "", logic: str = "") -> None:
        lrefs = [r for r, _, _ in lcols]
        rrefs = [r for r, _, _ in rcols]
        confidence = Confidence.worst(*(r.confidence for r in lrefs + rrefs))
        notes = self._notes(lcols + rcols)
        self.ctx.result.joins.append(JoinCondition(
            join_type=join_type, left=lrefs, operator=op, right=rrefs, right_value=right_value,
            original=original, normalized=normalized, context=self.context, line=line,
            notes="; ".join(dict.fromkeys(notes)), dynamic=self.dynamic, confidence=confidence,
            full_condition=full or original, logic=logic))
        for ref in lrefs + rrefs:
            self.ctx.record_column(ref, "JOIN")
            if ref.confidence == Confidence.LOW:
                self.ctx.add_unresolved(f"JOIN ({join_type})", ref, self.context, line)

    # ------------------------------------------------------------ normalised text
    def norm(self, expr, scope: Optional[Scope]) -> str:
        """Render an expression with column references replaced by resolved names."""
        if expr is None:
            return ""
        n = self.norm
        if isinstance(expr, A.ColumnExpr):
            refs = resolve_column(scope, expr.parts) if scope is not None else []
            if len(refs) == 1 and (refs[0].table is not None or refs[0].owner_label):
                ref = refs[0]
                owner = ref.table.display_name if ref.table is not None else ref.owner_label
                return f"{owner}.{quote_ident(ref.column)}"
            return ".".join(quote_ident(p) for p in expr.parts)
        if isinstance(expr, A.LiteralExpr):
            if expr.kind == "string":
                return "'" + expr.value.replace("'", "''") + "'"
            return expr.value
        if isinstance(expr, A.VariableExpr):
            return expr.name
        if isinstance(expr, A.StarExpr):
            return ".".join(expr.qualifier + ["*"]) if expr.qualifier else "*"
        if isinstance(expr, A.FuncExpr):
            return f"{'.'.join(expr.name)}({', '.join(n(a, scope) for a in expr.args)})"
        if isinstance(expr, A.BinaryExpr):
            return f"{n(expr.left, scope)} {expr.op} {n(expr.right, scope)}"
        if isinstance(expr, A.UnaryExpr):
            return f"{expr.op}{n(expr.operand, scope)}"
        if isinstance(expr, A.ComparisonExpr):
            quant = f" {expr.quantifier}" if expr.quantifier else ""
            return f"{n(expr.left, scope)} {expr.op}{quant} {n(expr.right, scope)}"
        if isinstance(expr, A.BoolExpr):
            parts = []
            for item in expr.items:
                text = n(item, scope)
                parts.append(f"({text})" if isinstance(item, A.BoolExpr) else text)
            return f" {expr.op} ".join(parts)
        if isinstance(expr, A.NotExpr):
            return f"NOT {n(expr.operand, scope)}"
        if isinstance(expr, A.IsNullExpr):
            return f"{n(expr.operand, scope)} IS {'NOT ' if expr.negated else ''}NULL"
        if isinstance(expr, A.InExpr):
            neg = "NOT " if expr.negated else ""
            if expr.query is not None:
                return f"{n(expr.operand, scope)} {neg}IN (subquery)"
            return f"{n(expr.operand, scope)} {neg}IN ({', '.join(n(v, scope) for v in expr.values)})"
        if isinstance(expr, A.BetweenExpr):
            neg = "NOT " if expr.negated else ""
            return (f"{n(expr.operand, scope)} {neg}BETWEEN {n(expr.low, scope)} "
                    f"AND {n(expr.high, scope)}")
        if isinstance(expr, A.LikeExpr):
            neg = "NOT " if expr.negated else ""
            return f"{n(expr.operand, scope)} {neg}LIKE {n(expr.pattern, scope)}"
        if isinstance(expr, A.ExistsExpr):
            return "EXISTS (subquery)"
        if isinstance(expr, A.SubqueryExpr):
            return "(subquery)"
        if isinstance(expr, A.CaseExpr):
            parts = ["CASE"]
            if expr.operand is not None:
                parts.append(n(expr.operand, scope))
            for cond, res in expr.whens:
                parts.append(f"WHEN {n(cond, scope)} THEN {n(res, scope)}")
            if expr.else_ is not None:
                parts.append(f"ELSE {n(expr.else_, scope)}")
            parts.append("END")
            return " ".join(parts)
        return self.orig(expr)
