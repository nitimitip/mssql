"""Analysis options (decoupled from config.ini parsing)."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import FrozenSet, Optional, Tuple

from models.common import ObjectType


@dataclass
class PerformanceOptions:
    enabled: bool = True
    # Rule IDs (see analyzer.perf_rules.RULES) switched off, upper case.
    disabled_rules: FrozenSet[str] = frozenset()
    max_key_columns: int = 4
    max_include_columns: int = 6
    # partitioning review triggers
    partition_min_range_statements: int = 2
    partition_min_share: float = 0.5

    def rule_enabled(self, rule_id: str) -> bool:
        return self.enabled and rule_id.upper() not in self.disabled_rules


@dataclass
class AnalysisOptions:
    analyze_dynamic_sql: bool = True
    max_dynamic_sql_variants: int = 32
    max_dynamic_sql_depth: int = 3
    view_name_prefixes: Tuple[str, ...] = ("vw_",)
    unknown_object_type: str = ObjectType.PHYSICAL_TABLE
    fallback_scan_unparsed: bool = True
    performance: PerformanceOptions = field(default_factory=PerformanceOptions)
    # Optional analyzer.schema_catalog.SchemaCatalog (folder-based DDL).
    catalog: Optional[object] = None
    extra: dict = field(default_factory=dict)
