"""Classify referenced object names (table, view, temp table, table variable ...)."""
from __future__ import annotations

from typing import Iterable, List

from models.common import ObjectRef, ObjectType


class ObjectResolver:
    """Turns multi-part names into ObjectRefs.

    Without database metadata a plain name cannot be proven to be a table
    rather than a view or synonym. The object type for such names is
    configurable (``unknown_object_type``); names matching a configured view
    prefix are classified as views.
    """

    def __init__(self, view_prefixes: Iterable[str] = ("vw_",),
                 unknown_object_type: str = ObjectType.PHYSICAL_TABLE):
        self.view_prefixes = tuple(p.upper() for p in view_prefixes if p)
        self.unknown_object_type = unknown_object_type

    def object_ref(self, parts: List[str]) -> ObjectRef:
        name = parts[-1]
        if name.startswith("##"):
            return ObjectRef(name, ObjectType.GLOBAL_TEMP_TABLE)
        if name.startswith("#"):
            return ObjectRef(name, ObjectType.TEMP_TABLE)
        if name.startswith("@"):
            return ObjectRef(name, ObjectType.TABLE_VARIABLE)
        padded = [None] * (4 - len(parts)) + [p or None for p in parts]
        server, database, schema = padded[0], padded[1], padded[2]
        object_type = self.unknown_object_type
        if self.view_prefixes and name.upper().startswith(self.view_prefixes):
            object_type = ObjectType.VIEW
        return ObjectRef(name, object_type, schema=schema, database=database, server=server)

    @staticmethod
    def function_ref(parts: List[str], builtin: bool) -> ObjectRef:
        if builtin:
            return ObjectRef(".".join(parts), ObjectType.BUILTIN_FUNCTION)
        padded = [None] * (4 - len(parts)) + [p or None for p in parts]
        return ObjectRef(parts[-1], ObjectType.TABLE_FUNCTION, schema=padded[2],
                         database=padded[1], server=padded[0])
