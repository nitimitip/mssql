"""Per-file orchestration: read -> tokenize -> parse -> analyse -> status."""
from __future__ import annotations

import hashlib
import logging
import time
from pathlib import Path
from typing import Dict, List, Optional

from models import (
    Confidence, IssueType, ProcedureAnalysis, Severity, Status,
)

from . import ast_nodes as A
from .file_reader import FileReadError, read_sql_file
from .object_resolver import ObjectResolver
from .options import AnalysisOptions
from .parser import Parser
from .statement_analyzer import ProcedureContext, StatementAnalyzer
from .tokenizer import TokenizeError, tokenize

log = logging.getLogger(__name__)

INFO_ONLY_CLAUSES = frozenset({"SELECT", "SET", "GROUP BY", "ORDER BY"})


class AnalysisEngine:
    def __init__(self, options: Optional[AnalysisOptions] = None):
        self.options = options or AnalysisOptions()
        self.resolver = ObjectResolver(self.options.view_name_prefixes,
                                       self.options.unknown_object_type)

    # ------------------------------------------------------------ entry points
    def analyze_file(self, path: Path, display_name: Optional[str] = None) -> List[ProcedureAnalysis]:
        display_name = display_name or path.name
        started = time.perf_counter()
        try:
            text, encoding, notes = read_sql_file(
                path, self.options.extra.get("max_file_bytes", 50 * 1024 * 1024))
        except FileReadError as exc:
            return [self.failed_result(display_name, IssueType.ENCODING_ERROR, str(exc))]
        log.debug("Read %s as %s", display_name, encoding)
        results = self.analyze_text(text, display_name)
        elapsed = time.perf_counter() - started
        for result in results:
            for note in notes:
                result.issues.append(_info(IssueType.ENCODING_ERROR, note))
            result.elapsed_seconds = elapsed / max(len(results), 1)
        return results

    def analyze_text(self, text: str, source_file: str = "<text>") -> List[ProcedureAnalysis]:
        try:
            tokens = tokenize(text)
        except TokenizeError as exc:
            return [self.failed_result(source_file, IssueType.PARSING_FAILURE, str(exc), exc.line)]
        try:
            batches = Parser(tokens).parse_script()
        except RecursionError:
            return [self.failed_result(source_file, IssueType.PARSING_FAILURE,
                                 "SQL nested too deeply to parse")]
        except Exception as exc:  # defensive: never let one file stop the run
            log.exception("Parser crashed on %s", source_file)
            return [self.failed_result(source_file, IssueType.INTERNAL_ERROR, f"Parser error: {exc}")]

        procedures = [s for batch in batches for s in batch if isinstance(s, A.ProcedureDef)]
        if procedures:
            return [self._analyze_procedure(p, tokens, text, source_file) for p in procedures]
        return [self._analyze_script(batches, tokens, text, source_file)]

    # ------------------------------------------------------------ internals
    def _analyze_procedure(self, proc: A.ProcedureDef, tokens, text: str,
                           source_file: str) -> ProcedureAnalysis:
        parts = [p or None for p in proc.name]
        padded = [None] * (3 - min(len(parts), 3)) + parts[-3:]
        result = ProcedureAnalysis(source_file=source_file, name=proc.name[-1],
                                   schema=padded[1], database=padded[0],
                                   parameters=list(proc.params), line=proc.line)
        result.definition_hash = _definition_hash(proc, tokens)
        log.info("Procedure detected: %s (%s, line %s)", result.full_name, source_file, proc.line)
        ctx = ProcedureContext(result, self.options, self.resolver)
        StatementAnalyzer(ctx, tokens, text).analyze_statements(proc.body)
        finalize(result, ctx)
        return result

    def _analyze_script(self, batches, tokens, text: str, source_file: str) -> ProcedureAnalysis:
        result = ProcedureAnalysis(source_file=source_file, name=Path(source_file).stem)
        ctx = ProcedureContext(result, self.options, self.resolver)
        statements = [s for batch in batches for s in batch]
        if not any(not isinstance(s, A.SkippedStmt) for s in statements):
            ctx.issue(Severity.ERROR, IssueType.MISSING_SP_DEFINITION,
                      "No stored procedure definition or SQL statements found")
        else:
            ctx.issue(Severity.WARNING, IssueType.MISSING_SP_DEFINITION,
                      "No CREATE/ALTER PROCEDURE statement found; the file was analysed as a "
                      "plain SQL script and named after the file")
            StatementAnalyzer(ctx, tokens, text).analyze_statements(statements)
        finalize(result, ctx)
        return result

    def failed_result(self, source_file: str, issue_type: str, description: str,
                line: int = 0) -> ProcedureAnalysis:
        result = ProcedureAnalysis(source_file=source_file, name=Path(source_file).stem)
        result.issues.append(_issue(Severity.ERROR, issue_type, description, line))
        result.status = Status.FAILED
        result.confidence = Confidence.LOW
        log.error("FAILED %s: %s", source_file, description)
        return result


def _definition_hash(proc: A.ProcedureDef, tokens) -> str:
    span = tokens[proc.span[0]:proc.span[1]]
    # skip CREATE / ALTER [OR ALTER] PROC[EDURE] <name> so dbo.p and p compare equal
    start = next((i for i, t in enumerate(span) if t.upper in ("PROC", "PROCEDURE")), -1)
    start += 1 + max(2 * len(proc.name) - 1, 0)
    digest = hashlib.sha1()
    for tok in span[start:]:
        digest.update(f"{tok.kind}:{tok.upper or tok.value}\x1f".encode("utf-8"))
    return digest.hexdigest()


def _issue(severity: str, issue_type: str, description: str, line: int = 0):
    from models import AnalysisIssue
    return AnalysisIssue(severity, issue_type, description, line)


def _info(issue_type: str, description: str):
    return _issue(Severity.INFO, issue_type, description)


def _dedupe(records) -> list:
    seen: Dict[tuple, object] = {}
    for rec in records:
        key = rec.dedupe_key()
        if key in seen:
            first = seen[key]
            first.occurrences += 1
            for loc in getattr(rec, "locations", ()):
                if loc not in first.locations:
                    first.locations.append(loc)
        else:
            seen[key] = rec
    return list(seen.values())


def _dedupe_findings(findings) -> list:
    """Merge identical findings of one top-level statement (dynamic-SQL variants).

    The key keeps string literals exact, so 'A' and 'a ' never merge."""
    seen: Dict[tuple, object] = {}
    for finding in findings:
        key = finding.dedupe_key()
        first = seen.get(key)
        if first is None:
            seen[key] = finding
            continue
        first.occurrences += 1
        for sid in finding.statement_ids:
            if sid not in first.statement_ids:
                first.statement_ids.append(sid)
    return list(seen.values())


def finalize(result: ProcedureAnalysis, ctx: ProcedureContext) -> None:
    """Deduplicate records, turn unresolved references into issues, set status."""
    result.joins = _dedupe(result.joins)
    result.filters = _dedupe(result.filters)
    result.perf_findings = _dedupe_findings(result.perf_findings)

    for item in result.unresolved:
        ref = item.ref
        text = ref.original or ref.column
        # SELECT / SET / GROUP BY / ORDER BY gaps are listed but, unlike JOIN and
        # filter gaps, do not lower the procedure's status.
        severity = Severity.INFO if item.clause in INFO_ONLY_CLAUSES else Severity.WARNING
        if ref.candidates:
            ctx.issue(severity, IssueType.AMBIGUOUS_COLUMN,
                      f"{text} in {item.clause} is ambiguous; possible tables: "
                      f"{', '.join(ref.candidates)}", item.line)
        elif ref.owner_label or ref.table is not None:
            ctx.issue(severity, IssueType.LINEAGE,
                      f"{text} in {item.clause}: {ref.note}", item.line)
        else:
            ctx.issue(severity, IssueType.UNRESOLVED_REFERENCE,
                      f"{text} in {item.clause}: {ref.note}", item.line)

    severities = {i.severity for i in result.issues}
    all_failed = result.statements_total > 0 and result.statements_failed >= result.statements_total
    if all_failed:
        ctx.issue(Severity.ERROR, IssueType.PARSING_FAILURE,
                  "None of the procedure's statements could be parsed")
        severities.add(Severity.ERROR)

    if Severity.ERROR in severities:
        result.status = Status.FAILED
    elif Severity.MANUAL in severities:
        result.status = Status.MANUAL_REVIEW
    elif Severity.WARNING in severities:
        result.status = Status.PARTIAL
    else:
        result.status = Status.SUCCESS

    if result.status == Status.FAILED:
        result.confidence = Confidence.LOW
    elif result.status == Status.MANUAL_REVIEW:
        result.confidence = Confidence.MANUAL
    else:
        values = [u.confidence for u in result.tables.values() if not u.fallback_only]
        values += [j.confidence for j in result.joins]
        values += [f.confidence for f in result.filters]
        result.confidence = Confidence.worst(*values)

    log.info("Parsing complete: %s status=%s tables=%d joins=%d filters=%d dynamic=%d",
             result.full_name, result.status, len(result.physical_tables), len(result.joins),
             len(result.filters), len(result.dynamic_sql))
