"""Query scopes, sources (FROM items) and column resolution.

A Scope holds the sources visible to one query block. Correlated subqueries
see outer scopes through ``parent``; derived tables and CTE bodies get their
own scopes, so an alias reused in a subquery never leaks to the outer query.

Resolution never guesses. When a column cannot be tied to exactly one
source it comes back unresolved with LOW confidence and the candidate list.
"""
from __future__ import annotations

import itertools
from dataclasses import dataclass, field, replace
from typing import Dict, List, Optional, Set, Tuple

from models.common import ColumnRef, Confidence, ObjectRef

OBJECT = "OBJECT"        # table / view / temp table / table variable
CTE = "CTE"
DERIVED = "DERIVED"
FUNCTION = "FUNCTION"
VALUES = "VALUES"
PIVOT = "PIVOT"

_ids = itertools.count(1)
_MAX_LINEAGE_DEPTH = 25


def _join_notes(*notes: str) -> str:
    return "; ".join(n for n in notes if n)


@dataclass
class ColumnLineage:
    name: str
    refs: List[ColumnRef]
    direct: bool          # plain pass-through of a single column reference
    expression: str


@dataclass
class DerivedInfo:
    """Output-column lineage of a derived table / CTE / subquery."""
    label: str
    columns: Dict[str, ColumnLineage] = field(default_factory=dict)
    ordered: List[ColumnLineage] = field(default_factory=list)
    star_sources: List[Tuple["Scope", Optional["Source"]]] = field(default_factory=list)
    base_sources: List["Source"] = field(default_factory=list)
    recursive: bool = False
    # Why the query provably returns at most one row ('' = not provable).
    single_row: str = ""
    # Ids of outer-scope sources referenced from inside the query (correlation).
    outer_refs: Set[int] = field(default_factory=set)

    def add(self, lineage: ColumnLineage) -> None:
        self.ordered.append(lineage)
        self.columns.setdefault(lineage.name.upper(), lineage)

    def renamed(self, names: List[str]) -> "DerivedInfo":
        info = DerivedInfo(self.label, star_sources=list(self.star_sources),
                           base_sources=list(self.base_sources), recursive=self.recursive,
                           single_row=self.single_row, outer_refs=set(self.outer_refs))
        for idx, name in enumerate(names):
            if idx < len(self.ordered):
                old = self.ordered[idx]
                info.add(ColumnLineage(name, old.refs, old.direct, old.expression))
            else:
                info.add(ColumnLineage(name, [], False, "(column position not traceable)"))
        if names:
            info.star_sources = []
        return info


class Source:
    """One item in a FROM clause (or an UPDATE/DELETE/MERGE target)."""

    def __init__(self, kind: str, alias: Optional[str] = None, obj: Optional[ObjectRef] = None,
                 name_parts: Optional[List[str]] = None, derived: Optional[DerivedInfo] = None,
                 known_columns: Optional[Set[str]] = None, label: str = "",
                 confidence: str = Confidence.HIGH, line: int = 0):
        self.id = next(_ids)
        self.kind = kind
        self.alias = alias
        self.obj = obj
        self.name_parts = name_parts or []
        self.derived = derived
        self.known_columns = known_columns
        self.label = label
        self.confidence = confidence
        self.line = line
        self.ops: List[str] = []
        self.join_right = False
        self.committed = False
        # why the source provably yields at most one row ('' = not provable)
        self.single_row = ""

    @property
    def exposed(self) -> Optional[str]:
        if self.alias:
            return self.alias
        return self.name_parts[-1] if self.name_parts else None

    def matches(self, qualifier: List[str]) -> bool:
        if len(qualifier) == 1:
            exposed = self.exposed
            return exposed is not None and exposed.upper() == qualifier[0].upper()
        if self.alias or not self.name_parts:
            return False
        if self.name_parts[-1].upper() != qualifier[-1].upper():
            return False
        for mine, theirs in zip(reversed(self.name_parts[:-1]), reversed(qualifier[:-1])):
            if mine and theirs and mine.upper() != theirs.upper():
                return False
        return True

    def definitely_has(self, column: str) -> bool:
        cols = self.output_columns()
        return cols is not None and column.upper() in cols

    def may_have(self, column: str) -> bool:
        cols = self.output_columns()
        return cols is None or column.upper() in cols

    def output_columns(self) -> Optional[Set[str]]:
        """Known output column names (upper case), or None when unknown."""
        if self.kind in (CTE, DERIVED):
            if self.derived is None or self.derived.star_sources:
                return None
            return set(self.derived.columns)
        return self.known_columns

    def __repr__(self) -> str:  # pragma: no cover
        return f"Source({self.kind}, {self.label!r}, alias={self.alias!r})"


class Scope:
    def __init__(self, parent: Optional["Scope"] = None, label: str = ""):
        self.parent = parent
        self.label = label
        self.sources: List[Source] = []
        # ids of sources in enclosing scopes referenced from this scope or below
        self.outer_refs: Set[int] = set()

    def add(self, source: Source) -> None:
        self.sources.append(source)

    def has_sources_upward(self) -> bool:
        scope: Optional[Scope] = self
        while scope is not None:
            if scope.sources:
                return True
            scope = scope.parent
        return False


def _note_outer(scope: Optional[Scope], depth: int, source_id: int) -> None:
    """Record on every scope between ``scope`` and the owning scope that it
    references ``source_id`` from outside (used to detect correlation)."""
    for _ in range(depth):
        if scope is None:
            return
        scope.outer_refs.add(source_id)
        scope = scope.parent


def find_source(scope: Optional[Scope], qualifier: List[str]) -> Tuple[Optional[Source], int]:
    depth = 0
    while scope is not None:
        for src in scope.sources:
            if src.matches(qualifier):
                return src, depth
        scope = scope.parent
        depth += 1
    return None, 0


def resolve_column(scope: Optional[Scope], parts: List[str], original: str = "") -> List[ColumnRef]:
    """Resolve a (possibly qualified) column reference within ``scope``."""
    column = parts[-1]
    qualifier = parts[:-1]
    if qualifier:
        src, depth = find_source(scope, qualifier)
        if src is None:
            return [ColumnRef(column, None, Confidence.LOW, original=original,
                              note=f"qualifier '{'.'.join(qualifier)}' does not match any table "
                                   f"or alias in scope")]
        refs = resolve_in_source(src, column, original)
        if depth:
            _note_outer(scope, depth, src.id)
            refs = [replace(r, outer=True) for r in refs]
        return refs
    return resolve_unqualified(scope, column, original)


def resolve_in_source(src: Source, column: str, original: str = "", depth: int = 0) -> List[ColumnRef]:
    if depth > _MAX_LINEAGE_DEPTH:
        return [ColumnRef(column, None, Confidence.LOW, original=original, owner_label=src.label,
                          note="lineage too deep to trace", source_id=src.id)]
    if src.kind in (OBJECT, FUNCTION):
        return [ColumnRef(column, src.obj, src.confidence, original=original, source_id=src.id)]
    if src.kind == VALUES:
        return [ColumnRef(column, None, Confidence.HIGH, original=original, owner_label=src.label,
                          note="column of a VALUES row constructor", source_id=src.id)]
    if src.kind == PIVOT:
        return [ColumnRef(column, None, Confidence.LOW, original=original, owner_label=src.label,
                          note="PIVOT/UNPIVOT output column; lineage not traced", source_id=src.id)]

    info = src.derived
    if info is None:
        return [ColumnRef(column, None, Confidence.LOW, original=original, owner_label=src.label,
                          note="recursive CTE self-reference; lineage not traced", source_id=src.id)]
    ceiling = Confidence.LOW if info.recursive else Confidence.MEDIUM
    via = f"via {src.label}" + (" (recursive)" if info.recursive else "")
    lineage = info.columns.get(column.upper())
    if lineage is not None:
        if lineage.direct and lineage.refs:
            return [replace(r, confidence=Confidence.cap(r.confidence, ceiling), original=original,
                            note=_join_notes(via, r.note), source_id=src.id, outer=False)
                    for r in lineage.refs]
        return [ColumnRef(column, None, Confidence.LOW, original=original, owner_label=src.label,
                          note=f"computed column in {src.label}: {lineage.expression}",
                          source_id=src.id)]
    if info.star_sources:
        candidates: List[Source] = []
        for star_scope, star_src in info.star_sources:
            if star_src is not None:
                candidates.append(star_src)
            else:
                candidates.extend(star_scope.sources)
        possible = [s for s in candidates if s.may_have(column)]
        if len(possible) == 1:
            refs = resolve_in_source(possible[0], column, original, depth + 1)
            return [replace(r, confidence=Confidence.cap(r.confidence, ceiling),
                            note=_join_notes(f"{via} (SELECT *)", r.note), source_id=src.id,
                            outer=False)
                    for r in refs]
        if len(possible) > 1:
            return [ColumnRef(column, None, Confidence.LOW, original=original, owner_label=src.label,
                              note=f"{src.label} uses SELECT * over several tables; owner ambiguous",
                              candidates=tuple(s.label for s in possible), source_id=src.id)]
    return [ColumnRef(column, None, Confidence.LOW, original=original, owner_label=src.label,
                      note=f"column not exposed by {src.label}", source_id=src.id)]


def resolve_unqualified(scope: Optional[Scope], column: str, original: str = "") -> List[ColumnRef]:
    depth = 0
    current = scope
    while current is not None:
        candidates = [s for s in current.sources if s.may_have(column)]
        if len(candidates) == 1:
            src = candidates[0]
            refs = resolve_in_source(src, column, original)
            if depth:
                _note_outer(scope, depth, src.id)
            outer_exists = current.parent is not None and current.parent.has_sources_upward()
            if depth == 0 and (src.definitely_has(column)
                               or (len(current.sources) == 1 and not outer_exists)):
                ceiling, note = Confidence.HIGH, ""
            elif depth == 0 and len(current.sources) == 1:
                ceiling = Confidence.MEDIUM
                note = "unqualified column in a subquery; bound to the inner table per SQL scoping"
            elif depth == 0:
                ceiling = Confidence.MEDIUM
                note = "unqualified column; other tables in scope ruled out by their known columns"
            else:
                ceiling = Confidence.MEDIUM
                note = "unqualified column bound to an outer query (correlated)"
            return [replace(r, confidence=Confidence.cap(r.confidence, ceiling),
                            note=_join_notes(note, r.note), outer=depth > 0)
                    for r in refs]
        if len(candidates) > 1:
            return [ColumnRef(column, None, Confidence.LOW, original=original,
                              note="ambiguous unqualified column; several tables in scope could own it",
                              candidates=tuple(s.label for s in candidates))]
        current = current.parent
        depth += 1
    return [ColumnRef(column, None, Confidence.LOW, original=original,
                      note="no table in scope for this column")]
