"""Statement-level performance review rules and table-access collection.

Runs inside StatementAnalyzer's scope walk, so every rule sees the same
alias / CTE / derived-table / APPLY / correlated-subquery resolution as the
dependency report. Rules are deterministic, carry stable IDs (see
analyzer.perf_rules) and only describe *possible* risks:

* a pattern is never called wrong in itself (scans, functions, cursors,
  DISTINCT, UNION, CROSS JOIN can all be intended);
* join columns or business relationships are never invented;
* rewrites are offered only where they keep NULL, duplicate and outer-join
  behaviour, and always state the assumption they depend on.

The collector records, per query block and per table source, which columns
are filtered (equality / range / ...), joined, grouped, ordered, projected
and updated. reports.performance_builder turns those records into index
candidates and partitioning assessments.
"""
from __future__ import annotations

from itertools import combinations
from typing import Dict, FrozenSet, Iterable, List, Optional, Set, Tuple

from models import Confidence
from models.common import quote_ident
from models.performance import (
    EQ, EQ_JOIN, IN_LIST, NONSARGABLE, OR_BRANCH, PREFIX, RANGE, RESIDUAL,
    AccessRecord, ColumnAccess, PerfFinding, PerfSeverity as Sev, SqlOrigin,
)

from . import ast_nodes as A
from .scope_manager import CTE, DERIVED, FUNCTION, OBJECT, VALUES, Scope, Source, resolve_column
from .sql_types import (
    SAFE_YEARS_ANY_TYPE, YEAR_RANGES, coalesce_result, compare_literals, isnull_result,
    render_literal,
)
from .tokenizer import VARIABLE

_FLIP = {"<": ">", ">": "<", "<=": ">=", ">=": "<=", "!<": "!>", "!>": "!<"}
_RANGE_OPS = frozenset({"<", ">", "<=", ">=", "!<", "!>"})
_EQ_OPS = frozenset({"=", "IS NOT DISTINCT FROM"})
_OUTER_JOINS = frozenset({"LEFT JOIN", "RIGHT JOIN", "FULL JOIN"})
_APPLY = frozenset({"CROSS APPLY", "OUTER APPLY"})
_DATEADD_EXACT_UNITS = frozenset({"DAY", "DD", "D", "HOUR", "HH", "MINUTE", "MI", "N", "SECOND",
                                  "SS", "S", "WEEK", "WK", "WW", "MILLISECOND", "MS"})
_CONVERSIONS = frozenset({"CAST", "CONVERT", "TRY_CAST", "TRY_CONVERT"})

Pair = FrozenSet[int]


# ---------------------------------------------------------------- AST helpers

def _walk(expr) -> Iterable:
    """Every expression node under ``expr`` (subqueries are not entered)."""
    stack = [expr]
    while stack:
        node = stack.pop()
        if node is None or isinstance(node, A.Query):
            continue
        yield node
        stack.extend(A.expr_children(node))


def _nested_queries(expr) -> List[A.Query]:
    out, stack = [], [expr]
    while stack:
        node = stack.pop()
        if node is None:
            continue
        if isinstance(node, A.Query):
            out.append(node)
            continue
        stack.extend(A.expr_children(node))
    return out


def _has_columns(expr) -> bool:
    return any(isinstance(n, A.ColumnExpr) for n in _walk(expr))


def _variables(expr) -> Set[str]:
    return {n.name.upper() for n in _walk(expr)
            if isinstance(n, A.VariableExpr) and not n.name.startswith("@@")}


def _conjuncts(expr) -> List:
    if expr is None:
        return []
    if isinstance(expr, A.BoolExpr) and expr.op == "AND":
        out = []
        for item in expr.items:
            out.extend(_conjuncts(item))
        return out
    return [expr]


def _literal(expr) -> Optional[Tuple[str, str]]:
    """(kind, value) of a plain literal, including a negative number."""
    if isinstance(expr, A.LiteralExpr) and expr.kind in ("number", "string"):
        return expr.kind, expr.value
    if (isinstance(expr, A.UnaryExpr) and expr.op == "-" and isinstance(expr.operand, A.LiteralExpr)
            and expr.operand.kind == "number"):
        return "number", "-" + expr.operand.value
    return None


def _const_compare(expr) -> Optional[bool]:
    """Truth value of a comparison between two literals; None if not constant."""
    if not isinstance(expr, A.ComparisonExpr) or expr.quantifier:
        return None
    left, right = _literal(expr.left), _literal(expr.right)
    if left is None or right is None:
        return None
    return compare_literals(expr.op, left, right)     # exact: never via float


def _constant_true(expr) -> bool:
    if isinstance(expr, A.BoolExpr):
        results = [_constant_true(i) for i in expr.items]
        return all(results) if expr.op == "AND" else any(results)
    if isinstance(expr, A.NotExpr):
        return _const_compare(expr.operand) is False
    return _const_compare(expr) is True


def _catch_all_pair(col, fn) -> bool:
    """col = ISNULL(@p, col) / COALESCE(@p, col): the optional-parameter idiom."""
    if not (isinstance(col, A.ColumnExpr) and isinstance(fn, A.FuncExpr)
            and fn.name[-1].upper() in ("ISNULL", "COALESCE")):
        return False
    target = [p.upper() for p in col.parts]
    return (any(isinstance(a, A.VariableExpr) for a in fn.args)
            and any(isinstance(a, A.ColumnExpr) and [p.upper() for p in a.parts] == target
                    for a in fn.args))


def _like_leading_wildcard(pattern) -> Optional[str]:
    """The literal prefix text if the LIKE pattern starts with % or _."""
    node = pattern
    while isinstance(node, A.BinaryExpr) and node.op == "+":
        node = node.left
    lit = _literal(node)
    if lit and lit[0] == "string" and lit[1][:1] in ("%", "_"):
        return lit[1]
    return None


def _like_prefix(pattern) -> bool:
    lit = _literal(pattern)
    return bool(lit and lit[0] == "string" and lit[1] and lit[1][0] not in "%_[")


def _closure(pairs: Set[Pair]) -> Set[Pair]:
    uf = _UnionFind()
    for pair in pairs:
        a, b = tuple(pair)
        uf.union(a, b)
    groups: Dict[int, List[int]] = {}
    for node in list(uf.parent):
        groups.setdefault(uf.find(node), []).append(node)
    out: Set[Pair] = set()
    for members in groups.values():
        out.update(frozenset(p) for p in combinations(sorted(members), 2))
    return out


def _pairs(ids: Set[int]) -> Set[Pair]:
    return {frozenset(p) for p in combinations(sorted(ids), 2)}


def _crosses(pairs: Iterable[Pair], left: Set[int], right: Set[int]) -> bool:
    for pair in pairs:
        a, b = tuple(pair)
        if (a in left and b in right) or (a in right and b in left):
            return True
    return False


class _UnionFind:
    def __init__(self):
        self.parent: Dict[int, int] = {}

    def find(self, x: int) -> int:
        self.parent.setdefault(x, x)
        while self.parent[x] != x:
            self.parent[x] = self.parent[self.parent[x]]
            x = self.parent[x]
        return x

    def union(self, a: int, b: int) -> None:
        ra, rb = self.find(a), self.find(b)
        if ra != rb:
            self.parent[max(ra, rb)] = min(ra, rb)

    def add_pairs(self, pairs: Iterable[Pair]) -> None:
        for pair in pairs:
            a, b = tuple(pair)
            self.union(a, b)


def _join_nodes(items) -> List[A.Join]:
    out = []

    def walk(item):
        if isinstance(item, A.Join):
            walk(item.left)
            walk(item.right)
            out.append(item)
        elif isinstance(item, A.PivotSource):
            walk(item.source)

    for item in items:
        walk(item)
    return out


def _query_reads_tables(node) -> bool:
    stack = [node]
    while stack:
        cur = stack.pop()
        if cur is None:
            continue
        if isinstance(cur, A.SetOpQuery):
            stack.extend([cur.left, cur.right])
        elif isinstance(cur, A.SelectQuery):
            if cur.from_items:
                return True
            for item in cur.items:
                stack.append(item.expr)
            stack.append(cur.where)
        elif isinstance(cur, A.Query):
            continue
        else:
            stack.extend(A.expr_children(cur))
    return False


_VALIDATE_PLAN = ("Compare actual execution plans (and STATISTICS IO/TIME or Query Store "
                  "runtime stats) before and after the change with production-like data volumes.")


class PerfInspector:
    """Applies the statement rules for one StatementAnalyzer."""

    def __init__(self, analyzer):
        self.an = analyzer
        self.ctx = analyzer.ctx
        self.opts = analyzer.ctx.options.performance

    # ------------------------------------------------------------ plumbing
    @property
    def active(self) -> bool:
        return self.opts.enabled

    def emit(self, rule_id: str, severity: str, confidence: str, line: int, tables: str,
             finding: str, evidence: str, action: str, assumptions: str, validation: str) -> None:
        if not self.opts.rule_enabled(rule_id):
            return
        origin = SqlOrigin.STATIC
        if self.an.dynamic:
            origin = SqlOrigin.DYNAMIC
            confidence = Confidence.cap(confidence, Confidence.MEDIUM)
        sid = self.an.stmt_id
        self.ctx.result.perf_findings.append(PerfFinding(
            rule_id=rule_id, severity=severity, confidence=confidence, statement_id=sid,
            line=line, tables=tables, finding=finding, evidence=evidence, action=action,
            assumptions=assumptions, validation=validation, origin=origin,
            context=self.an.context, statement_ids=[sid]))

    def orig(self, node) -> str:
        return self.an.orig(node) if node is not None else ""

    def refs(self, expr, scope):
        return self.an.collect_columns(expr, scope) if expr is not None else []

    @staticmethod
    def label(src: Source) -> str:
        if src.kind in (DERIVED, VALUES) or (src.kind != OBJECT and src.label.endswith(
                f" {src.alias or ''}")):
            return src.label                    # label already names the alias
        base = src.obj.display_name if (src.kind == OBJECT and src.obj is not None) else src.label
        if src.alias and src.alias.upper() != base.split(".")[-1].upper():
            return f"{base} AS {quote_ident(src.alias)}"
        return base

    def labels(self, sources: List[Source]) -> str:
        return ", ".join(self.label(s) for s in sources)

    def on_scope(self, join: A.Join, scope: Scope) -> Scope:
        """The scope an ON clause was resolved in (sources to its left only)."""
        n = self.an.join_scope_len.get(id(join))
        if n is None or n >= len(scope.sources):
            return scope
        snap = Scope(parent=scope.parent, label=scope.label)
        snap.sources = scope.sources[:n]
        return snap

    def leaves(self, item) -> List[Source]:
        if isinstance(item, A.Join):
            return self.leaves(item.left) + self.leaves(item.right)
        src = self.an.item_sources.get(id(item))
        return [src] if src is not None else []

    def expr_sources(self, expr, scope) -> Tuple[Set[int], bool, int]:
        """(source ids the expression relates, unresolved column present, column count).

        Subqueries contribute the outer sources they are correlated with."""
        ids: Set[int] = set()
        unknown = False
        refs = self.refs(expr, scope)
        for ref, _, _ in refs:
            if ref.source_id:
                ids.add(ref.source_id)
            else:
                unknown = True
        for query in _nested_queries(expr):
            info = self.an.query_info.get(id(query))
            if info is not None:
                ids |= info.outer_refs
        return ids, unknown, len(refs)

    def guaranteed_pairs(self, expr, scope, negate: bool = False) -> Set[Pair]:
        """Source pairs the condition relates on every path (AND / OR / NOT aware)."""
        if expr is None:
            return set()
        if isinstance(expr, A.NotExpr):
            return self.guaranteed_pairs(expr.operand, scope, not negate)
        if isinstance(expr, A.BoolExpr):
            conjunctive = (expr.op == "AND") != negate
            parts = [self.guaranteed_pairs(i, scope, negate) for i in expr.items]
            if conjunctive:
                return set().union(*parts)
            closed = [_closure(p) for p in parts]
            out = closed[0]
            for other in closed[1:]:
                out = out & other
            return out
        if _const_compare(expr) is not None:
            return set()
        ids, _, _ = self.expr_sources(expr, scope)
        return _pairs(ids)

    def any_pairs(self, expr, scope) -> Set[Pair]:
        out: Set[Pair] = set()
        for pred, _, _ in self.an.iter_predicates(expr, False, ()):
            if _const_compare(pred) is None:
                out |= _pairs(self.expr_sources(pred, scope)[0])
        return out

    def maybe_unresolved_link(self, expr, scope) -> bool:
        for pred, _, _ in self.an.iter_predicates(expr, False, ()):
            _, unknown, count = self.expr_sources(pred, scope)
            if unknown and count >= 2:
                return True
        return False

    # ------------------------------------------------------------ single-row sources
    @staticmethod
    def query_single_row(query) -> str:
        if not isinstance(query, A.SelectQuery):
            return ""
        top = (query.top or "").strip()
        if top == "1":
            return "TOP (1)"
        if not query.from_items:
            return "SELECT without FROM returns one row"
        if query.group_by or not query.items:
            return ""

        def agg_only(expr) -> Optional[bool]:
            """True: aggregate; None: constant; False: reads a row column."""
            if isinstance(expr, A.FuncExpr) and expr.aggregate and not expr.window:
                return True
            if isinstance(expr, (A.LiteralExpr, A.VariableExpr, A.SubqueryExpr)):
                return None
            if isinstance(expr, (A.ColumnExpr, A.StarExpr)) or expr is None:
                return False
            if isinstance(expr, A.FuncExpr) and expr.window:
                return False
            seen_agg = False
            for child in A.expr_children(expr):
                if isinstance(child, A.Query):
                    continue
                res = agg_only(child)
                if res is False:
                    return False
                seen_agg = seen_agg or bool(res)
            return True if seen_agg else None

        results = [agg_only(item.expr) for item in query.items if not item.assign_var]
        if results and all(r is not False for r in results) and any(results):
            return "aggregate without GROUP BY returns one row"
        return ""

    def single_row(self, src: Source, conjuncts: List, scope: Scope) -> str:
        if src.single_row:
            return src.single_row
        if src.kind in (DERIVED, CTE) and src.derived is not None and src.derived.single_row:
            return src.derived.single_row
        catalog = self.ctx.options.catalog
        if src.kind != OBJECT or catalog is None or src.obj is None:
            return ""
        table = catalog.lookup(src.obj)
        if table is None:
            return ""
        bound: Set[str] = set()
        local_ids = {s.id for s in scope.sources}
        for conj in conjuncts:
            if not isinstance(conj, A.ComparisonExpr) or conj.op != "=":
                continue
            for col_side, val_side in ((conj.left, conj.right), (conj.right, conj.left)):
                col = self.bare_column(col_side, scope, src.id)
                if col and not (self.expr_sources(val_side, scope)[0] & local_ids):
                    bound.add(col.upper())
        for index in table.unique_indexes:
            if index.keys and {k.upper() for k in index.keys} <= bound:
                return f"equality on every key column of unique index {index.name}"
        return ""

    def bare_column(self, expr, scope, source_id: int) -> Optional[str]:
        if not isinstance(expr, A.ColumnExpr):
            return None
        refs = resolve_column(scope, expr.parts, "")
        if len(refs) == 1 and refs[0].source_id == source_id and refs[0].table is not None:
            return refs[0].column
        return None

    # ------------------------------------------------------------ query blocks
    def query_block(self, query: A.SelectQuery, scope: Scope, label: str) -> None:
        if not self.active:
            return
        self.check_from(query.from_items, query.where, scope)
        self.check_conditions(query.from_items, query.where, scope)
        self.collect_access("SELECT", scope, query.where, query.from_items, query.items,
                            query.group_by, query.order_by, query.having, label, top=query.top)

    def dml_block(self, stmt, op: str, scope: Scope, target: Source) -> None:
        if not self.active:
            return
        self.check_from(stmt.from_items, stmt.where, scope, extra=[target]
                        if target not in self.flat_leaves(stmt.from_items) else None)
        self.check_conditions(stmt.from_items, stmt.where, scope)
        self.collect_access(op, scope, stmt.where, stmt.from_items,
                            set_items=getattr(stmt, "set_items", []), target=target,
                            top=stmt.top)

    def merge_block(self, stmt: A.MergeStmt, scope: Scope, target: Source) -> None:
        if not self.active:
            return
        if stmt.condition is not None:
            src_leaves = self.leaves(stmt.source)
            conj = _conjuncts(stmt.condition)
            multi_source = [s for s in src_leaves if not self.single_row(s, conj, scope)]
            pairs = _closure(self.guaranteed_pairs(stmt.condition, scope))
            if multi_source and not self.single_row(target, conj, scope)                     and not _crosses(pairs, {target.id}, {s.id for s in src_leaves}):
                self.unlinked_join("MERGE ON", stmt.condition, [target], src_leaves, scope,
                                   connected_elsewhere=False, line=self.an.line_of(stmt.condition),
                                   evidence=f"MERGE ... USING ... ON {self.orig(stmt.condition)}")
            self.check_predicates(stmt.condition, scope, "MERGE ON")
        set_items = [item for when in stmt.whens for item in when.set_items]
        self.collect_access("MERGE", scope, None, [], set_items=set_items, target=target,
                            merge_on=stmt.condition)

    def flat_leaves(self, items) -> List[Source]:
        out: List[Source] = []
        for item in items:
            out.extend(self.leaves(item))
        return out

    # ------------------------------------------------------------ join connectivity
    def check_from(self, from_items, where, scope: Scope, extra: Optional[List[Source]] = None) -> None:
        items = list(from_items)
        if not items and not extra:
            return
        all_leaves = self.flat_leaves(items)
        if len(all_leaves) + len(extra or []) < 2:
            return
        joins = _join_nodes(items)
        conjuncts = _conjuncts(where)
        for j in joins:
            if j.join_type == "INNER JOIN":
                conjuncts += _conjuncts(j.condition)
        single = {s.id: self.single_row(s, conjuncts, scope)
                  for s in all_leaves + (extra or [])}

        uf = _UnionFind()
        uf.add_pairs(self.guaranteed_pairs(where, scope))
        on_closure: Dict[int, Set[Pair]] = {}
        for j in joins:
            if j.condition is not None:
                pairs = self.guaranteed_pairs(j.condition, self.on_scope(j, scope))
                on_closure[id(j)] = _closure(pairs)
                uf.add_pairs(pairs)
            if j.join_type in _APPLY:
                left_ids = {s.id for s in self.leaves(j.left)}
                for src in self.leaves(j.right):
                    for other in self.apply_correlation(src, j.right, scope) & left_ids:
                        uf.union(src.id, other)

        def connected(left: List[Source], right: List[Source]) -> bool:
            return any(uf.find(l.id) == uf.find(r.id) for l in left for r in right)

        def multi(sources: List[Source]) -> bool:
            return any(not single.get(s.id) for s in sources)

        for j in joins:
            left, right = self.leaves(j.left), self.leaves(j.right)
            if not left or not right or not multi(left) or not multi(right):
                continue
            joined = connected(left, right)
            line = self.an.line_of(j)
            if j.join_type in _APPLY:
                if not joined:
                    self.cross_product("PERF-J006", j.join_type, left, right, where, scope, line,
                                       f"{self.orig(j)}", apply=True)
                continue
            if j.join_type == "CROSS JOIN":
                if not joined:
                    self.cross_product("PERF-J006", "CROSS JOIN", left, right, where, scope, line,
                                       self.orig(j))
                continue
            if j.condition is None:
                continue
            lids, rids = {s.id for s in left}, {s.id for s in right}
            if _crosses(on_closure.get(id(j), set()), lids, rids):
                continue
            self.unlinked_join(j.join_type, j.condition, left, right, self.on_scope(j, scope),
                               connected_elsewhere=joined, line=line, evidence=self.orig(j),
                               where=where, scope_full=scope)

        if extra:            # UPDATE / DELETE target not listed in FROM
            if all_leaves and multi(extra) and multi(all_leaves) and not connected(extra, all_leaves):
                self.comma_product(extra, all_leaves, where, scope, self.an.line_of(items[0]),
                                   f"FROM {', '.join(self.orig(i) for i in items)}")
        for idx in range(1, len(items)):
            left = self.flat_leaves(items[:idx])
            right = self.leaves(items[idx])
            if not left or not right or not multi(left) or not multi(right):
                continue
            if not connected(left, right):
                text = "FROM " + ", ".join(self.orig(i) for i in items[:idx + 1])
                self.comma_product(left, right, where, scope, self.an.line_of(items[idx]), text)

    def apply_correlation(self, src: Source, item, scope: Scope) -> Set[int]:
        if src.kind in (DERIVED, CTE) and src.derived is not None:
            return set(src.derived.outer_refs)
        if src.kind == FUNCTION and isinstance(item, A.FunctionSource):
            ids: Set[int] = set()
            for arg in item.args:
                ids |= self.expr_sources(arg, scope)[0]
            return ids
        return set()

    def _where_text(self, where) -> str:
        return f"\nWHERE {self.orig(where)}" if where is not None else ""

    def comma_product(self, left, right, where, scope, line, from_text) -> None:
        lids, rids = {s.id for s in left}, {s.id for s in right}
        confidence = Confidence.LOW if self.maybe_unresolved_link(where, scope) else Confidence.HIGH
        evidence = from_text + self._where_text(where)
        tables = f"{self.labels(left)} | {self.labels(right)}"
        if where is not None and _crosses(self.any_pairs(where, scope), lids, rids):
            self.or_bypass(left, right, where, scope, line, evidence, tables, confidence)
            return
        hedge = (" An unresolved column in WHERE might relate them; manual review."
                 if confidence == Confidence.LOW else "")
        self.emit(
            "PERF-J001", Sev.HIGH, confidence, line, tables,
            f"Potential Cartesian product: {self.labels(right)} is listed in a comma-separated "
            f"FROM clause and no WHERE predicate relates it to {self.labels(left)}.{hedge} "
            f"Possible impact: every qualifying row of one side is combined with every "
            f"qualifying row of the other, so row counts multiply; CPU, memory grants, tempdb "
            f"and result size grow with the product.",
            evidence,
            "Confirm whether the product is intended. If the sources are related, express the "
            "relationship as an explicit INNER JOIN ... ON with the correct key columns (the "
            "analyzer cannot know which columns those are). If the product is intended, write "
            "it as an explicit CROSS JOIN so the intent is visible.",
            "Row counts and the intended relationship are unknown. Sources are treated as "
            "multi-row unless provably single-row.",
            "Check the row counts of both sides and the actual plan (a join operator with "
            "'No Join Predicate' warning). Confirm the result set is identical after any change. "
            + _VALIDATE_PLAN)

    def cross_product(self, rule_id, kind, left, right, where, scope, line, evidence,
                      apply: bool = False) -> None:
        lids, rids = {s.id for s in left}, {s.id for s in right}
        tables = f"{self.labels(left)} | {self.labels(right)}"
        evidence = evidence + self._where_text(where)
        if where is not None and _crosses(self.any_pairs(where, scope), lids, rids):
            self.or_bypass(left, right, where, scope, line, evidence, tables, Confidence.HIGH)
            return
        if apply:
            pattern = (f"{kind} {self.labels(right)} does not reference any column of "
                       f"{self.labels(left)}, so it behaves like a CROSS JOIN.")
        else:
            pattern = (f"Explicit CROSS JOIN of {self.labels(left)} with {self.labels(right)} "
                       f"and no WHERE predicate relating them.")
        self.emit(
            rule_id, Sev.LOW, Confidence.HIGH, line, tables,
            f"{pattern} This is often intentional (for example expanding rows against a "
            f"small calendar, parameter or lookup set). Possible impact: the result has "
            f"rows(left) x rows(right) rows before later filters.",
            evidence,
            "Manual review: no change if the product is intended and both sides stay small. "
            "If a relationship was intended, it must be added explicitly; the analyzer does "
            "not infer join columns.",
            "Neither side is provably single-row; actual row counts are unknown.",
            "Confirm the expected row counts on both sides at production volume.")

    def or_bypass(self, left, right, cond, scope, line, evidence, tables, confidence,
                  severity: str = Sev.HIGH, note: str = "") -> None:
        self.emit(
            "PERF-J005", severity, confidence, line, tables,
            f"The predicate relating {self.labels(left)} and {self.labels(right)} sits inside "
            f"an OR, and at least one other OR branch does not relate them. Possible impact: "
            f"rows that satisfy that other branch are combined with every row of the other "
            f"source (a partial Cartesian product), and OR-ed join logic usually prevents "
            f"efficient join strategies.{note}",
            evidence,
            "Confirm the intended logic first. If the relationship must hold for every row, "
            "it can be factored out of the OR as (relationship) AND (other conditions) - this "
            "changes the result set, so only do it when the business rule confirms it. If the "
            "OR is intended, consider splitting into UNION ALL branches (check duplicates: "
            "a row matching both branches would be returned twice).",
            "AND / OR / NOT grouping is evaluated exactly as written; parentheses are respected.",
            "Verify results on rows that satisfy each OR branch separately. " + _VALIDATE_PLAN)

    def unlinked_join(self, join_type, condition, left, right, scope, connected_elsewhere,
                      line, evidence, where=None, scope_full=None) -> None:
        lids, rids = {s.id for s in left}, {s.id for s in right}
        tables = f"{self.labels(left)} | {self.labels(right)}"
        outer = join_type in _OUTER_JOINS
        confidence = (Confidence.LOW if self.maybe_unresolved_link(condition, scope)
                      else Confidence.HIGH)
        if _crosses(self.any_pairs(condition, scope), lids, rids):
            if connected_elsewhere and not outer:
                self.or_bypass(left, right, condition, scope, line, evidence, tables, confidence,
                               Sev.LOW, " A WHERE or later join predicate also relates the "
                                        "sources, which limits the product for this INNER JOIN.")
            else:
                self.or_bypass(left, right, condition, scope, line, evidence, tables, confidence)
            return
        constant = _constant_true(condition)
        rule = "PERF-J003" if constant else "PERF-J002"
        if constant:
            pattern = (f"The ON condition of {join_type} {self.labels(right)} is always true "
                       f"({self.orig(condition)}), so the join has no join predicate.")
        else:
            pattern = (f"The ON condition of {join_type} {self.labels(right)} does not relate "
                       f"it to {self.labels(left)}: no predicate compares columns of both sides.")
        if outer:
            impact = ("Possible impact: each preserved row is paired with every row of the other "
                      "side that satisfies the ON filter, multiplying rows.")
            severity = Sev.HIGH
            if connected_elsewhere:
                severity = Sev.MEDIUM
                impact += (" A WHERE (or other) predicate relates the sources afterwards; for "
                           "an outer join that also discards the unmatched rows the outer join "
                           "was meant to keep.")
            action = ("Confirm the intended relationship and add it to the ON clause. Do NOT "
                      "simply move WHERE predicates into ON (or the reverse): for outer joins "
                      "that changes which unmatched rows are returned.")
        else:
            if connected_elsewhere:
                severity = Sev.LOW
                impact = ("A WHERE or later join predicate relates the sources, so for this "
                          "INNER JOIN the result (and usually the plan) is the same as with the "
                          "predicate in ON; this is mainly a readability / maintenance item.")
                action = ("Optionally move the relating predicate into this ON clause (for an "
                          "INNER JOIN this does not change results).")
            else:
                severity = Sev.HIGH
                impact = ("Possible impact: every qualifying row of the left side is combined "
                          "with every qualifying row of the right side (row counts multiply).")
                action = ("Confirm the intended relationship and add it to the ON clause; the "
                          "analyzer does not infer join columns. If a product is intended, "
                          "write CROSS JOIN instead.")
        if confidence == Confidence.LOW:
            pattern += " An unresolved column might relate the sources; manual review."
        self.emit(rule, severity, confidence, line, tables, f"{pattern} {impact}", evidence, action,
                  "Join semantics evaluated as written, including outer-join preservation.",
                  "Check row counts and the actual plan for a 'No Join Predicate' warning. "
                  "Confirm results (including unmatched rows for outer joins) after any change.")

    # ------------------------------------------------------------ predicate rules
    def check_conditions(self, from_items, where, scope: Scope) -> None:
        for j in _join_nodes(from_items):
            if j.condition is not None:
                self.check_predicates(j.condition, self.on_scope(j, scope), f"ON ({j.join_type})")
        if where is not None:
            self.check_predicates(where, scope, "WHERE")

    def check_predicates(self, cond, scope: Scope, clause: str) -> None:
        for pred, negated, path in self.an.iter_predicates(cond, False, ()):
            self.check_self_comparison(pred, scope, clause)
            self.check_wrapped_column(pred, scope, clause)
            self.check_like(pred, scope, clause)
        self.check_optional_parameters(cond, scope, clause)

    def tables_of(self, expr, scope) -> str:
        names = []
        for ref, _, _ in self.refs(expr, scope):
            name = ref.table_display
            if name not in names:
                names.append(name)
        return ", ".join(names)

    def check_self_comparison(self, pred, scope, clause) -> None:
        if not (isinstance(pred, A.ComparisonExpr) and isinstance(pred.left, A.ColumnExpr)
                and isinstance(pred.right, A.ColumnExpr)):
            return
        same_text = [p.upper() for p in pred.left.parts] == [p.upper() for p in pred.right.parts]
        lrefs = resolve_column(scope, pred.left.parts, "")
        rrefs = resolve_column(scope, pred.right.parts, "")
        same_ref = (len(lrefs) == 1 and len(rrefs) == 1 and lrefs[0].source_id
                    and lrefs[0].source_id == rrefs[0].source_id
                    and lrefs[0].column.upper() == rrefs[0].column.upper())
        if not (same_text or same_ref):
            return
        col = self.orig(pred.left)
        if pred.op in ("=", "<=", ">=", "!<", "!>"):
            meaning = f"it is true for every non-NULL value (equivalent to {col} IS NOT NULL)"
        elif pred.op in ("<>", "!=", "<", ">"):
            meaning = "it is never true"
        else:
            meaning = "its result does not depend on any other source"
        self.emit(
            "PERF-J004", Sev.MEDIUM, Confidence.HIGH, self.an.line_of(pred),
            self.tables_of(pred, scope),
            f"{self.orig(pred)} in {clause} compares a column with itself on the same source: "
            f"{meaning}, and it relates no other table. Possible impact: if a relationship to "
            f"another source was intended it is missing, which can multiply rows.",
            self.orig(pred),
            "Check which column (and which alias) was intended on each side. The analyzer "
            "cannot determine the intended column and does not suggest one.",
            "Aliases resolved by query scope; a self-join (two aliases of one table) is NOT "
            "flagged by this rule.",
            "Confirm the intended predicate with the code owner and compare results.")

    def check_wrapped_column(self, pred, scope, clause) -> None:
        sides: List[Tuple[object, object, bool]] = []
        if isinstance(pred, A.ComparisonExpr) and not pred.quantifier:
            sides = [(pred.left, pred.right, True), (pred.right, pred.left, False)]
        elif isinstance(pred, A.InExpr):
            sides = [(pred.operand, None, True)]
        elif isinstance(pred, (A.BetweenExpr, A.LikeExpr, A.IsNullExpr)):
            sides = [(pred.operand, None, True)]
        for side, other, is_left in sides:
            if side is None or isinstance(side, (A.ColumnExpr, A.LiteralExpr, A.VariableExpr,
                                                 A.SubqueryExpr)):
                continue
            if _catch_all_pair(other, side):
                continue                        # reported by PERF-P003
            local = [(r, w, agg) for r, w, agg in self.refs(side, scope) if not r.outer and not agg]
            if not local:
                continue
            self.emit_wrapped(pred, side, other, is_left, local, scope, clause)
            return

    def emit_wrapped(self, pred, side, other, is_left, local, scope, clause) -> None:
        col_ref = local[0][0]
        col_text = col_ref.original or col_ref.column
        if isinstance(side, A.FuncExpr):
            wrapper = ".".join(side.name).upper() + "()"
        elif isinstance(side, A.CaseExpr):
            wrapper = "CASE expression"
        elif isinstance(side, A.BinaryExpr):
            wrapper = f"calculation ('{side.op}')"
        else:
            wrapper = "expression"
        fname = side.name[-1].upper() if isinstance(side, A.FuncExpr) else ""
        severity = Sev.LOW if fname in _CONVERSIONS else Sev.MEDIUM
        confidence = Confidence.HIGH if col_ref.table is not None else Confidence.MEDIUM
        rewrite, assumption = self.sargable_rewrite(pred, side, other, is_left, scope)
        impact = ("Possible impact: an index on that column generally cannot be used for a seek "
                  "on this predicate (the expression is evaluated row by row), and row "
                  "estimates may be less accurate.")
        if fname in _CONVERSIONS:
            impact += (" Some conversions (for example CAST(datetime AS date)) can still be "
                       "seekable; check the plan before changing anything.")
        null_note = ""
        if fname in ("ISNULL", "COALESCE") and other is not None and _has_columns(other):
            null_note = (f" Note: {wrapper} on a join column makes NULL values match each other; "
                         f"a plain column comparison would not match NULLs, so removing it "
                         f"changes results unless the columns are NOT NULL.")
        self.emit(
            "PERF-P001", severity, confidence, self.an.line_of(pred), self.tables_of(side, scope),
            f"Column {col_text} is wrapped in {wrapper} in a {clause} predicate. {impact}{null_note}",
            self.orig(pred), rewrite, assumption,
            "Check that an index whose leading key is the column exists (otherwise a rewrite "
            "alone does not change the access path), check data types for implicit "
            "conversions, and confirm identical results including NULL handling. "
            + _VALIDATE_PLAN)

    def sargable_rewrite(self, pred, side, other, is_left, scope) -> Tuple[str, str]:
        generic = ("Rewrite so the column stands alone on one side (move the calculation to "
                   "the parameter / constant side), or, if the expression itself is what is "
                   "searched, consider an indexed persisted computed column for it. Any rewrite "
                   "must return identical rows, including NULL handling.")
        generic_assumption = "Column data types are not known to the analyzer."
        if not isinstance(pred, A.ComparisonExpr) or other is None or _has_columns(other):
            return generic, generic_assumption
        op = pred.op if is_left else _FLIP.get(pred.op, pred.op)
        other_text = self.orig(other)
        if isinstance(side, A.FuncExpr):
            fname = side.name[-1].upper()
            args = side.args
            col = args[0] if args else None
            if fname == "YEAR" and len(args) == 1 and isinstance(col, A.ColumnExpr) and op == "=":
                return self.year_rewrite(col, other, scope) or (generic, generic_assumption)
            if fname in ("ISNULL", "COALESCE") and len(args) == 2 and isinstance(col, A.ColumnExpr):
                return self.null_replacement_rewrite(fname, col, args[1], op, other, scope) \
                    or (generic, generic_assumption)
            if fname in _CONVERSIONS and op == "=":
                flat = self.orig(side).upper().replace(" ", "")
                if (flat.startswith(("CAST(", "TRY_CAST(")) and flat.endswith("ASDATE)")) or \
                        flat.startswith(("CONVERT(DATE,", "TRY_CONVERT(DATE,")):
                    c = self.orig(side.args[0])
                    return (f"Conditional rewrite: {c} >= {other_text} AND "
                            f"{c} < DATEADD(day, 1, {other_text})",
                            f"Valid if {c} is datetime/datetime2 and {other_text} is a date "
                            f"(midnight). DATEADD raises an error when {other_text} is "
                            f"9999-12-31. SQL Server can often seek on CAST(... AS date) already, "
                            f"so the rewrite may not be needed.")
            if fname == "DATEADD" and len(args) == 3 and isinstance(args[2], A.ColumnExpr) \
                    and op in _RANGE_OPS | {"="}:
                unit = self.orig(args[0]).upper()
                amount = _literal(args[1])
                if unit in _DATEADD_EXACT_UNITS and amount and amount[0] == "number":
                    neg = amount[1][1:] if amount[1].startswith("-") else "-" + amount[1]
                    c = self.orig(args[2])
                    return (f"Conditional rewrite: {c} {op} DATEADD({self.orig(args[0])}, {neg}, "
                            f"{other_text})",
                            f"Exact only for fixed-length units (day, hour, minute, second, "
                            f"week); {c} must be a date/time type. DATEADD raises an overflow "
                            f"error near the type's date limits, where the original may not.")
            if fname == "RTRIM" and len(args) == 1 and isinstance(col, A.ColumnExpr) and op == "=":
                c = self.orig(col)
                return (f"Conditional rewrite: {c} = {other_text}",
                        "SQL Server ignores trailing spaces in '=' comparisons (ANSI padding), "
                        "so RTRIM is redundant for '='. Not valid for LIKE or for LTRIM "
                        "(leading spaces are significant).")
            if fname in ("UPPER", "LOWER") and len(args) == 1 and isinstance(col, A.ColumnExpr) \
                    and op == "=":
                c = self.orig(col)
                return (f"Conditional rewrite: {c} = {other_text}",
                        f"Valid only if {c} uses a case-insensitive collation; under a "
                        f"case-sensitive collation the results differ.")
        if isinstance(side, A.BinaryExpr) and side.op in ("+", "-") \
                and isinstance(side.left, A.ColumnExpr) and op in _RANGE_OPS | {"="}:
            amount = _literal(side.right)
            if amount and amount[0] == "number":
                inverse = "-" if side.op == "+" else "+"
                c = self.orig(side.left)
                return (f"Conditional rewrite: {c} {op} {other_text} {inverse} {amount[1]}",
                        f"Valid only if {c} is numeric (not a string, where + concatenates) and "
                        f"the arithmetic cannot overflow or lose precision.")
        return generic, generic_assumption

    def column_def(self, expr, scope):
        """Declared column definition from the schema folder, or None."""
        catalog = self.ctx.options.catalog
        if catalog is None or not isinstance(expr, A.ColumnExpr):
            return None
        refs = resolve_column(scope, expr.parts, "")
        if len(refs) != 1 or refs[0].table is None:
            return None
        table = catalog.lookup(refs[0].table)
        if table is None or not table.defined:
            return None
        return table.column(refs[0].column)

    def null_replacement_rewrite(self, fname, col, repl_expr, op, other, scope):
        """ISNULL / COALESCE(col, X) op Y -> a rewrite that keeps NULL rows exactly.

        The replacement is first converted the way SQL Server does it (ISNULL:
        to the column's type, e.g. 'LONG' -> 'LO' for varchar(2); COALESCE:
        data-type precedence). Without the column's declared type no concrete
        rewrite is offered."""
        c, other_text = self.orig(col), self.orig(other)
        repl, val = _literal(repl_expr), _literal(other)
        if repl is None or val is None:
            return None
        manual = (f"Manual review: to remove {fname}() the NULL rows must be handled "
                  f"explicitly - either '{c} {op} {other_text}' (if the replacement value "
                  f"fails the comparison) or '({c} {op} {other_text} OR {c} IS NULL)' (if it "
                  f"passes). Which one is equivalent cannot be decided here: ")
        conversion = ("ISNULL converts the replacement to the column's type (for example "
                      "'LONG' becomes 'LO' for varchar(2))" if fname == "ISNULL"
                      else "COALESCE returns the higher-precedence type of its arguments")
        coldef = self.column_def(col, scope)
        if coldef is None:
            return (manual + f"the declared type of {c} is not known (add its CREATE TABLE "
                             f"to the schema folder).",
                    f"{conversion}, so the replacement value actually compared depends on the "
                    f"column type.")
        args = getattr(coldef, "type_args", [])
        result, reason = (isnull_result if fname == "ISNULL" else coalesce_result)(
            repl, coldef.type_name, args)
        if result is None:
            return (manual + f"{reason}.", f"{c} is declared {coldef.type_text}; {conversion}.")
        verdict = compare_literals(op, result, val)
        if verdict is None:
            return (manual + f"comparing {render_literal(result)} with {other_text} depends on "
                             f"the collation.",
                    f"{c} is declared {coldef.type_text}.")
        converted = ""
        if result != repl:
            converted = (f" {fname} turns {self.orig(repl_expr)} into {render_literal(result)} "
                         f"for {coldef.type_text}.")
        if verdict:
            return (f"Conditional rewrite: ({c} {op} {other_text} OR {c} IS NULL)",
                    f"{c} is declared {coldef.type_text}.{converted} The replacement "
                    f"{render_literal(result)} satisfies '{op} {other_text}', so NULL rows are "
                    f"returned today and the rewrite keeps them. Re-check if the column "
                    f"definition changes.")
        return (f"Conditional rewrite: {c} {op} {other_text}",
                f"{c} is declared {coldef.type_text}.{converted} The replacement "
                f"{render_literal(result)} fails '{op} {other_text}', so NULL rows are excluded "
                f"with or without {fname}. Re-check if the column definition changes.")

    def year_rewrite(self, col, other, scope):
        """YEAR(col) = N -> half-open range, only where both bounds are valid dates."""
        c, other_text = self.orig(col), self.orig(other)
        coldef = self.column_def(col, scope)
        if coldef is not None and not coldef.is_date:
            return (f"Manual review: {c} is declared {coldef.type_text}, not a date/time type; "
                    f"YEAR() converts it implicitly, so no range rewrite is offered.",
                    "Type taken from the schema folder.")
        if coldef is not None:
            low, high = YEAR_RANGES[coldef.type_name]
            type_note = f"{c} is declared {coldef.type_text} (years {low}-{high})."
        else:
            low, high = SAFE_YEARS_ANY_TYPE
            type_note = (f"The type of {c} is unknown: only years {low}-{high} are converted, "
                         f"because both bounds are then valid for every date/time type "
                         f"(smalldatetime ends in 2079, datetime starts in 1753).")
        lit = _literal(other)
        if lit and lit[0] == "number" and lit[1].isdigit():
            y = int(lit[1])
            if not low <= y <= high:
                reason = (f"{y} is outside the years {coldef.type_text} can hold, so YEAR() = {y} "
                          f"is never true and a literal bound would fail to convert."
                          if coldef is not None else
                          f"{y} is outside {low}-{high}; the bounds may not convert for this "
                          f"column's type - add the column definition to the schema folder.")
                return f"Manual review: {reason}", type_note
            if coldef is not None and y == high:
                new = f"{c} >= '{y:04d}0101'"            # no next year to bound by
            else:
                new = f"{c} >= '{y:04d}0101' AND {c} < '{y + 1:04d}0101'"
            assumption = type_note if coldef is not None else (
                f"Valid only if {c} is a date/time type (not a character column holding "
                f"dates). {type_note}")
            return f"Conditional rewrite: {new}", assumption
        if isinstance(other, A.VariableExpr):
            return (f"Manual review (template, not a drop-in rewrite): {c} >= "
                    f"DATEFROMPARTS({other_text}, 1, 1) AND {c} < DATEFROMPARTS({other_text} + 1, "
                    f"1, 1)",
                    f"Equivalent only while {other_text} is between {low} and {high - 1}: "
                    f"DATEFROMPARTS raises an error outside years 1-9999 (so {other_text} = 9999 "
                    f"fails) and years outside the column type's range fail to convert, where "
                    f"YEAR() = {other_text} simply matches no rows. {type_note}")
        return None

    def check_like(self, pred, scope, clause) -> None:
        if not isinstance(pred, A.LikeExpr):
            return
        prefix = _like_leading_wildcard(pred.pattern)
        if prefix is None:
            return
        local = [r for r, _, _ in self.refs(pred.operand, scope) if not r.outer]
        if not local:
            return
        col = local[0].original or local[0].column
        self.emit(
            "PERF-P002", Sev.MEDIUM, Confidence.HIGH, self.an.line_of(pred),
            self.tables_of(pred.operand, scope),
            f"LIKE pattern {self.orig(pred.pattern)} on {col} starts with a wildcard "
            f"('{prefix[0]}'). Possible impact: an index on {col} cannot be used for a seek; "
            f"every row in the scanned range is tested.",
            self.orig(pred),
            "Only if the business rule allows it: search by prefix (LIKE 'abc%'). Otherwise "
            "consider full-text search, or a persisted reversed-string computed column for "
            "suffix searches. Both change behaviour and need business confirmation.",
            "The pattern is a literal (or starts with one); patterns supplied at runtime are "
            "not judged.",
            "Measure the row count scanned and the duration; confirm which searches users "
            "actually perform before changing semantics.")

    def check_optional_parameters(self, cond, scope, clause) -> None:
        hits: List[str] = []
        null_trap: List[str] = []
        for node in _walk(cond):
            if isinstance(node, A.BoolExpr) and node.op == "OR":
                param_vars: Set[str] = set()
                column_branches = []
                for branch in node.items:
                    has_cols = _has_columns(branch)
                    vars_ = _variables(branch)
                    if vars_ and not has_cols:
                        param_vars |= vars_
                    elif has_cols and vars_:
                        column_branches.append(vars_)
                if param_vars and any(v & param_vars for v in column_branches):
                    hits.append(self.orig(node))
            elif isinstance(node, (A.ComparisonExpr, A.LikeExpr)):
                left = node.left if isinstance(node, A.ComparisonExpr) else node.operand
                right = node.right if isinstance(node, A.ComparisonExpr) else node.pattern
                for col, fn in ((left, right), (right, left)):
                    if _catch_all_pair(col, fn):
                        hits.append(self.orig(node))
                        null_trap.append(self.orig(col))
                        break
        if not hits:
            return
        note = ""
        if null_trap:
            note = (f" With the {', '.join(dict.fromkeys(null_trap))} = ISNULL(@p, column) form, "
                    f"rows where the column is NULL are excluded even when the parameter is "
                    f"NULL; rewriting it as (@p IS NULL OR column = @p) would include them and "
                    f"change results.")
        self.emit(
            "PERF-P003", Sev.MEDIUM, Confidence.HIGH, self.an.line_of(cond),
            self.tables_of(cond, scope),
            f"Optional-parameter (catch-all) predicate(s) in {clause}: {'; '.join(hits)}. "
            f"Possible impact: one cached plan must serve both the 'parameter supplied' and "
            f"'parameter not supplied' cases; it is compiled for the first values seen "
            f"(parameter sniffing), which can mean scans when a filter is supplied or poor "
            f"estimates otherwise.{note}",
            "\n".join(hits),
            "Options to evaluate: (1) add OPTION (RECOMPILE) to this statement so each "
            "execution is optimised for its actual values (costs compile CPU per execution); "
            "(2) build the statement with sp_executesql including only the supplied filters, "
            "keeping values as parameters (never concatenate values into the SQL text); "
            "(3) split into IF branches for the common parameter combinations.",
            "Treats a branch that tests only parameters/variables as the 'not supplied' case.",
            "Compare plans and durations for representative combinations (all NULL, each "
            "parameter supplied). If using RECOMPILE, measure compile CPU at the real call "
            "rate. Confirm identical results, including rows where the column is NULL.")

    # ------------------------------------------------------------ statement-level rules
    def check_select_star(self, query, kind: str, line: int) -> None:
        if not self.active or query is None:
            return
        blocks: List[A.SelectQuery] = []
        stack = [query]
        while stack:
            q = stack.pop()
            if isinstance(q, A.SetOpQuery):
                stack.extend([q.right, q.left])
            elif isinstance(q, A.SelectQuery):
                blocks.append(q)
        for block in blocks:
            stars = [i.expr for i in block.items if isinstance(i.expr, A.StarExpr)]
            scope = self.an.query_scopes.get(id(block))
            if not stars or scope is None:
                continue
            covered: List[Source] = []
            for star in stars:
                if star.qualifier:
                    covered += [s for s in scope.sources if s.matches(star.qualifier)]
                else:
                    covered += list(scope.sources)
            wide = [s for s in covered
                    if s.kind == OBJECT or (s.kind in (DERIVED, CTE) and s.derived is not None
                                            and s.derived.star_sources)]
            if not wide:
                continue
            where = "SELECT INTO" if block.into is not None else kind
            extra = (" INSERT ... SELECT * also depends on the column order of the source."
                     if kind == "INSERT ... SELECT" else "")
            self.emit(
                "PERF-S001", Sev.LOW, Confidence.HIGH, self.an.line_of(block) or line,
                self.labels(wide),
                f"SELECT * ({where}) returns every column of {self.labels(wide)}. Possible "
                f"impact: wider rows mean more I/O, network transfer and memory grant, and a "
                f"narrow covering index cannot serve the query.{extra}",
                ", ".join(self.orig(s) for s in stars) + f" FROM {self.labels(scope.sources)}",
                "Projection-width review item: list only the columns the consumer needs.",
                "The consumers of the result set are not visible to static analysis.",
                "Identify every consumer (application code, INSERT targets, reports) before "
                "narrowing the column list.")

    def check_loop(self, stmt: A.WhileStmt, line: int) -> None:
        if not self.active or stmt.body is None:
            return
        ops: List[str] = []
        state = {"fetch": False, "top_dml": 0, "dml": 0}

        def note(text: str, s) -> None:
            ops.append(f"{text} (line {self.an.line_override or s.line})")

        def visit(s) -> None:
            if s is None:
                return
            if isinstance(s, A.BlockStmt):
                for b in s.body:
                    visit(b)
            elif isinstance(s, A.IfStmt):
                if _nested_queries(s.condition):
                    note("IF condition query", s)
                visit(s.then)
                visit(s.else_)
            elif isinstance(s, A.WhileStmt):
                visit(s.body)
            elif isinstance(s, A.SelectStmt):
                if _query_reads_tables(s.query):
                    note("SELECT", s)
            elif isinstance(s, (A.InsertStmt, A.UpdateStmt, A.DeleteStmt, A.MergeStmt)):
                kind = type(s).__name__.replace("Stmt", "").upper()
                target = ".".join(p for p in s.target.name if p) if s.target else "?"
                note(f"{kind} {target}", s)
                state["dml"] += 1
                if getattr(s, "top", None):
                    state["top_dml"] += 1
            elif isinstance(s, A.TruncateStmt):
                note("TRUNCATE", s)
            elif isinstance(s, A.ExecStmt):
                if s.dynamic_form:
                    note(f"dynamic SQL ({s.dynamic_form})", s)
                elif s.proc_variable:
                    note(f"EXEC {s.proc_variable}", s)
                else:
                    note(f"EXEC {'.'.join(p for p in s.proc_name if p)}", s)
            elif isinstance(s, A.SkippedStmt) and s.keyword == "FETCH":
                state["fetch"] = True
            elif isinstance(s, (A.SetVarStmt, A.DeclareVarStmt)) and s.value is not None:
                if any(_query_reads_tables(q) for q in _nested_queries(s.value)):
                    note(f"SET {s.name} = (query)", s)
            elif isinstance(s, A.ExprStmt):
                if any(_query_reads_tables(q) for e in s.exprs for q in _nested_queries(e)):
                    note(f"{s.keyword} (query)", s)

        visit(stmt.body)
        if not ops:
            return
        globals_used = {t.value.upper() for t in self.an.tokens[stmt.span[0]:stmt.span[1]]
                        if t.kind == VARIABLE and t.value.startswith("@@")}
        cursor = state["fetch"] or "@@FETCH_STATUS" in globals_used
        cond_text = self.orig(stmt.condition)
        evidence = f"WHILE {cond_text}\n  per iteration: " + "; ".join(ops)
        if (not cursor and "@@ROWCOUNT" in globals_used and state["top_dml"]
                and state["top_dml"] == state["dml"]):
            self.emit(
                "PERF-L002", Sev.INFO, Confidence.HIGH, line, "",
                "WHILE loop repeating DELETE / UPDATE / INSERT TOP (n) until @@ROWCOUNT is "
                "exhausted: a batching pattern usually chosen deliberately to limit lock "
                "escalation, blocking and transaction-log growth.",
                evidence,
                "No change suggested. Review the batch size and whether each batch is "
                "supported by an index on the filter columns (see Index Candidates).",
                "Batching intent inferred from TOP + @@ROWCOUNT.",
                "Check the duration per batch and log usage at production volume.")
            return
        kind = "Cursor loop (FETCH)" if cursor else "WHILE loop"
        self.emit(
            "PERF-L001", Sev.MEDIUM, Confidence.HIGH, line, "",
            f"{kind} runs {len(ops)} database operation(s) per iteration: "
            f"{'; '.join(ops)}. Possible impact: each statement (plan execution, locking, "
            f"logging) is repeated once per iteration, so total cost grows with the number of "
            f"iterations. Row-by-row processing is not wrong in itself.",
            evidence,
            "Set-based candidate - manual review: check whether the per-iteration statements "
            "can be expressed as one set-based statement over the loop's row source (for "
            "example UPDATE ... FROM, INSERT ... SELECT or MERGE). Keep the loop where it needs "
            "per-row procedure calls, per-row error handling or ordered side effects.",
            "Iteration count is unknown statically.",
            "Measure iteration count and total duration with production-like data; confirm "
            "transaction scope, error handling and ordering stay the same in any set-based "
            "version.")

    # ------------------------------------------------------------ table access records
    def note_outer_uses(self, exprs: Iterable, scope: Scope) -> None:
        for expr in exprs:
            for ref, _, _ in self.refs(expr, scope):
                if ref.outer and ref.source_id and ref.table is not None:
                    self.an.outer_uses.setdefault(ref.source_id, {}).setdefault(
                        ref.column.upper(), ref.column)

    def classify(self, conj, scope: Scope, src: Source) -> Tuple[List[ColumnAccess], List[str]]:
        sid = src.id
        text = self.orig(conj)
        out: List[ColumnAccess] = []
        confidences: List[str] = []

        def own(expr) -> List:
            return [(r, w) for r, w, _ in self.refs(expr, scope) if r.source_id == sid]

        def bare(expr) -> Optional[str]:
            if not isinstance(expr, A.ColumnExpr):
                return None
            refs = resolve_column(scope, expr.parts, "")
            if len(refs) == 1 and refs[0].source_id == sid and refs[0].table is not None:
                confidences.append(refs[0].confidence)
                return refs[0].column
            return None

        def other_columns(expr) -> bool:
            return any(r.source_id != sid for r, _, _ in self.refs(expr, scope)) or bool(
                _nested_queries(expr))

        def residual(kind: str = RESIDUAL) -> None:
            for ref, wrappers in own(conj):
                out.append(ColumnAccess(ref.column, NONSARGABLE if wrappers and kind == RESIDUAL
                                        else kind, text, wrappers=", ".join(wrappers)))

        if isinstance(conj, A.BoolExpr):
            residual(OR_BRANCH)
        elif isinstance(conj, A.NotExpr):
            residual()
        elif isinstance(conj, A.ComparisonExpr) and not conj.quantifier:
            for col_side, val_side, flip in ((conj.left, conj.right, False),
                                             (conj.right, conj.left, True)):
                col = bare(col_side)
                if col is None or own(val_side):
                    continue
                op = _FLIP.get(conj.op, conj.op) if flip else conj.op
                if op in _EQ_OPS:
                    kind = EQ_JOIN if other_columns(val_side) else EQ
                elif op in _RANGE_OPS:
                    kind = RANGE
                else:
                    kind = RESIDUAL
                out.append(ColumnAccess(col, kind, text, self.orig(val_side),
                                        constant=kind == EQ and _literal(val_side) is not None,
                                        op=op))
                return out, confidences
            residual()
        elif isinstance(conj, A.IsNullExpr):
            col = bare(conj.operand)
            if col is not None:
                op = "IS NOT NULL" if conj.negated else "IS NULL"
                out.append(ColumnAccess(col, RESIDUAL if conj.negated else EQ, text, op,
                                        constant=True, op=op))
            else:
                residual()
        elif isinstance(conj, A.InExpr) and not conj.negated:
            col = bare(conj.operand)
            if col is not None and conj.query is not None:
                out.append(ColumnAccess(col, EQ_JOIN, text, "(subquery)", op="IN"))
            elif col is not None and not any(own(v) for v in conj.values):
                literal = all(_literal(v) is not None for v in conj.values)
                out.append(ColumnAccess(col, IN_LIST, text,
                                        "(" + ", ".join(self.orig(v) for v in conj.values) + ")",
                                        constant=literal and len(conj.values) == 1, op="IN"))
            else:
                residual()
        elif isinstance(conj, A.BetweenExpr) and not conj.negated:
            col = bare(conj.operand)
            if col is not None and not own(conj.low) and not own(conj.high):
                out.append(ColumnAccess(col, RANGE, text,
                                        f"{self.orig(conj.low)} AND {self.orig(conj.high)}",
                                        op="BETWEEN"))
            else:
                residual()
        elif isinstance(conj, A.LikeExpr) and not conj.negated:
            col = bare(conj.operand)
            if col is not None and _like_prefix(conj.pattern):
                out.append(ColumnAccess(col, PREFIX, text, self.orig(conj.pattern), op="LIKE"))
            else:
                residual()
        else:
            residual()
        return out, confidences

    def collect_access(self, operation: str, scope: Scope, where, from_items=(), items=(),
                       group_by=(), order_by=(), having=None, label: str = "",
                       set_items=(), target: Optional[Source] = None, merge_on=None,
                       top: Optional[str] = None) -> None:
        sources = [s for s in scope.sources if s.kind == OBJECT and s.obj is not None]
        on_conditions = [(j, self.on_scope(j, scope)) for j in _join_nodes(from_items)
                         if j.condition is not None]
        exprs = [where, having, merge_on] + [j.condition for j, _ in on_conditions]
        exprs += [i.expr for i in items] + list(group_by) + list(order_by)
        exprs += [i.value for i in set_items]
        self.note_outer_uses([e for e in exprs if e is not None], scope)
        if not sources:
            return

        applicable: Dict[int, List[Tuple[object, Scope]]] = {s.id: [] for s in sources}
        for conj in _conjuncts(where) + _conjuncts(merge_on):
            for s in sources:
                applicable[s.id].append((conj, scope))
        for j, sc in on_conditions:
            if j.join_type == "INNER JOIN":
                targets = self.leaves(j)
            elif j.join_type == "LEFT JOIN":
                targets = self.leaves(j.right)       # ON filters the inner (right) side
            elif j.join_type == "RIGHT JOIN":
                targets = self.leaves(j.left)
            else:
                targets = []                          # FULL JOIN: neither side is filtered
            ids = {t.id for t in targets}
            for conj in _conjuncts(j.condition):
                for s in sources:
                    if s.id in ids:
                        applicable[s.id].append((conj, sc))

        unresolved: List[Tuple[str, Tuple[str, ...]]] = []
        for expr in exprs:
            if expr is None:
                continue
            for ref, _, _ in self.refs(expr, scope):
                if ref.table is None and not ref.source_id:
                    unresolved.append((ref.original or ref.column, ref.candidates))
        order_targets = [self.an.order_by_target(e, list(items)) for e in order_by]

        for src in sources:
            write = target is src
            record = AccessRecord(
                table=src.obj, alias=src.alias or "", statement_id=self.an.stmt_id,
                line=src.line or self.an.stmt_line_current, operation=operation if write else "SELECT",
                role="write" if write else "read", context=self.an.context,
                dynamic=self.an.dynamic, in_loop=self.an.in_loop, top=top or "")
            texts: List[str] = []
            confidences: List[str] = [src.confidence]
            for conj, sc in applicable[src.id]:
                accesses, confs = self.classify(conj, sc, src)
                if accesses:
                    record.predicates.extend(accesses)
                    confidences += confs
                    text = self.orig(conj)
                    if text not in texts:
                        texts.append(text)
            record.condition_text = " AND ".join(texts)
            record.group_by = self.bare_list(group_by, scope, src)
            record.order_by = self.bare_list(order_targets, scope, src)
            for item in items:
                if isinstance(item.expr, A.StarExpr):
                    if "EXISTS" in label:
                        continue
                    if not item.expr.qualifier or src.matches(item.expr.qualifier):
                        record.star = True
                elif item.expr is not None:
                    self.add_cols(record.projected, item.expr, scope, src)
            for expr in [having] + [i.value for i in set_items]:
                self.add_cols(record.other_columns, expr, scope, src)
            if write:
                for item in set_items:
                    if not item.is_variable and item.target:
                        name = item.target[-1]
                        if name.upper() not in (c.upper() for c in record.updated):
                            record.updated.append(name)
            for name in self.an.outer_uses.get(src.id, {}).values():
                if name.upper() not in (c.upper() for c in record.other_columns):
                    record.other_columns.append(name)
            record.unresolved = [name for name, cands in unresolved
                                 if not cands or src.label in cands]
            confidence = Confidence.worst(*confidences)
            if record.unresolved:
                confidence = Confidence.LOW
            if self.an.dynamic:
                confidence = Confidence.cap(confidence, Confidence.MEDIUM)
            record.confidence = confidence
            self.ctx.result.access_records.append(record)

    def record_write(self, src: Source, operation: str, line: int) -> None:
        if not self.active or src.kind != OBJECT or src.obj is None:
            return
        self.ctx.result.access_records.append(AccessRecord(
            table=src.obj, alias="", statement_id=self.an.stmt_id, line=line,
            operation=operation, role="write", context=self.an.context,
            dynamic=self.an.dynamic, in_loop=self.an.in_loop,
            confidence=Confidence.MEDIUM if self.an.dynamic else src.confidence))

    def bare_list(self, exprs, scope, src) -> List[str]:
        out: List[str] = []
        for expr in exprs:
            col = self.bare_column(expr, scope, src.id) if expr is not None else None
            if col and col.upper() not in (c.upper() for c in out):
                out.append(col)
        return out

    def add_cols(self, target: List[str], expr, scope, src) -> None:
        if expr is None:
            return
        for ref, _, _ in self.refs(expr, scope):
            if ref.source_id == src.id and ref.table is not None \
                    and ref.column.upper() not in (c.upper() for c in target):
                target.append(ref.column)

