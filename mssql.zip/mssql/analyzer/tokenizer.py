"""T-SQL tokenizer.

Turns raw T-SQL text into a flat list of tokens. Comments are discarded,
string literals are decoded, bracketed / double-quoted identifiers are
unquoted, and batch separators (GO on its own line) become GO tokens.

Everything downstream works on tokens, never on raw text, which is what
keeps commented-out SQL and SQL inside string literals from being
mistaken for real dependencies.
"""
from __future__ import annotations

import re
from typing import List

WORD = "WORD"          # unquoted identifier or keyword (incl. #temp names)
QIDENT = "QIDENT"      # [bracketed] or "quoted" identifier; never a keyword
STRING = "STRING"      # 'literal' or N'literal' (value is decoded content)
NUMBER = "NUMBER"
VARIABLE = "VARIABLE"  # @local, @@global
OP = "OP"              # operators and punctuation
GO = "GO"              # batch separator
EOF = "EOF"

_TWO_CHAR_OPS = {
    "<>", "!=", ">=", "<=", "!<", "!>", "+=", "-=", "*=", "/=", "%=",
    "&=", "|=", "^=", "::",
}
_WORD_CONT = set("_@#$")

# What may follow GO on its line: an optional repeat count and comments.
# ``open`` marks a block comment that continues onto later lines.
_GO_TAIL = re.compile(
    r"(?:\s|/\*.*?\*/)*(?:\d+)?(?:\s|/\*.*?\*/)*(?:--.*|(?P<open>/\*).*)?")


class TokenizeError(Exception):
    def __init__(self, message: str, line: int):
        super().__init__(f"{message} (line {line})")
        self.line = line


class Token:
    __slots__ = ("kind", "value", "upper", "line", "start", "end")

    def __init__(self, kind: str, value: str, line: int, start: int, end: int):
        self.kind = kind
        self.value = value
        # Keyword comparisons only ever apply to WORD tokens.
        self.upper = value.upper() if kind == WORD else None
        self.line = line
        self.start = start
        self.end = end

    def __repr__(self) -> str:  # pragma: no cover - debugging aid
        return f"Token({self.kind}, {self.value!r}, line={self.line})"


def tokenize(text: str) -> List[Token]:
    toks: List[Token] = []
    append = toks.append
    i = 0
    n = len(text)
    line = 1
    line_clean = True  # nothing but whitespace/comments since last newline

    while i < n:
        c = text[i]

        if c == "\n":
            line += 1
            i += 1
            line_clean = True
            continue
        if c.isspace() or c == "﻿":
            i += 1
            continue

        # -- line comment
        if c == "-" and i + 1 < n and text[i + 1] == "-":
            j = text.find("\n", i)
            i = n if j < 0 else j
            continue

        # /* block comment */ - T-SQL block comments nest
        if c == "/" and i + 1 < n and text[i + 1] == "*":
            start_line = line
            depth = 1
            j = i + 2
            while j < n and depth:
                if text.startswith("/*", j):
                    depth += 1
                    j += 2
                elif text.startswith("*/", j):
                    depth -= 1
                    j += 2
                else:
                    if text[j] == "\n":
                        line += 1
                    j += 1
            if depth:
                raise TokenizeError("Unterminated block comment", start_line)
            i = j
            continue

        # 'string' / N'unicode string'
        if c == "'" or (c in "Nn" and i + 1 < n and text[i + 1] == "'"):
            start = i
            start_line = line
            j = i + 1 if c == "'" else i + 2
            buf = []
            while True:
                if j >= n:
                    raise TokenizeError("Unterminated string literal", start_line)
                ch = text[j]
                if ch == "'":
                    if j + 1 < n and text[j + 1] == "'":
                        buf.append("'")
                        j += 2
                        continue
                    j += 1
                    break
                if ch == "\n":
                    line += 1
                buf.append(ch)
                j += 1
            append(Token(STRING, "".join(buf), start_line, start, j))
            i = j
            line_clean = False
            continue

        # [bracketed identifier] and "quoted identifier"
        if c == "[" or c == '"':
            close = "]" if c == "[" else '"'
            start = i
            start_line = line
            j = i + 1
            buf = []
            while True:
                if j >= n:
                    raise TokenizeError("Unterminated quoted identifier", start_line)
                ch = text[j]
                if ch == close:
                    if j + 1 < n and text[j + 1] == close:
                        buf.append(close)
                        j += 2
                        continue
                    j += 1
                    break
                if ch == "\n":
                    line += 1
                buf.append(ch)
                j += 1
            append(Token(QIDENT, "".join(buf), start_line, start, j))
            i = j
            line_clean = False
            continue

        # @variable / @@global
        if c == "@":
            j = i + 1
            while j < n and (text[j].isalnum() or text[j] in _WORD_CONT):
                j += 1
            kind = VARIABLE if j > i + 1 else OP
            append(Token(kind, text[i:j], line, i, j))
            i = j
            line_clean = False
            continue

        # numbers (incl. 0x hex and .5)
        if c.isdigit() or (c == "." and i + 1 < n and text[i + 1].isdigit()):
            j = i
            if c == "0" and i + 1 < n and text[i + 1] in "xX":
                j = i + 2
                while j < n and text[j] in "0123456789abcdefABCDEF":
                    j += 1
            else:
                while j < n and text[j].isdigit():
                    j += 1
                if j < n and text[j] == ".":
                    j += 1
                    while j < n and text[j].isdigit():
                        j += 1
                if j < n and text[j] in "eE":
                    k = j + 1
                    if k < n and text[k] in "+-":
                        k += 1
                    if k < n and text[k].isdigit():
                        j = k
                        while j < n and text[j].isdigit():
                            j += 1
            append(Token(NUMBER, text[i:j], line, i, j))
            i = j
            line_clean = False
            continue

        # words: keywords, identifiers, #temp, ##globaltemp, $action
        if c.isalpha() or c in "_#$":
            j = i + 1
            while j < n and (text[j].isalnum() or text[j] in _WORD_CONT):
                j += 1
            word = text[i:j]
            if line_clean and word.upper() == "GO":
                eol = text.find("\n", j)
                eol = n if eol < 0 else eol
                tail = _GO_TAIL.fullmatch(text, j, eol)
                if tail is not None:
                    append(Token(GO, word, line, i, j))
                    # an unclosed block comment is left for the comment scanner
                    i = tail.start("open") if tail.group("open") else eol
                    continue
            append(Token(WORD, word, line, i, j))
            i = j
            line_clean = False
            continue

        # operators / punctuation
        two = text[i:i + 2]
        if two in _TWO_CHAR_OPS:
            append(Token(OP, two, line, i, i + 2))
            i += 2
        else:
            append(Token(OP, c, line, i, i + 1))
            i += 1
        line_clean = False

    append(Token(EOF, "", line, n, n))
    return toks
