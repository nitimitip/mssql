"""Catalogue of performance review rules.

Rule IDs are stable: they are referenced from config.ini ([Performance]
disabled_rules), the workbook and the tests. Never renumber a rule; retire
it and add a new ID instead.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict

from models.performance import PerfSeverity as S


@dataclass(frozen=True)
class Rule:
    rule_id: str
    name: str
    scope: str            # Statement | Table
    default_severity: str
    description: str


_RULES = [
    Rule("PERF-J001", "Potential Cartesian product (comma join)", "Statement", S.HIGH,
         "A comma-separated FROM source that no WHERE predicate relates to the other "
         "sources; single-row sources are exempt."),
    Rule("PERF-J002", "JOIN predicate does not connect the joined sources", "Statement", S.HIGH,
         "The ON clause references no column pair relating the right-hand source to the "
         "left-hand sources."),
    Rule("PERF-J003", "Constant-true JOIN predicate", "Statement", S.HIGH,
         "ON 1 = 1 (or another always-true comparison) is the whole join condition."),
    Rule("PERF-J004", "Column compared with itself", "Statement", S.MEDIUM,
         "a.Id = a.Id: both sides are the same column of the same source."),
    Rule("PERF-J005", "OR branch bypasses the linking predicate", "Statement", S.HIGH,
         "The only predicate relating two sources sits inside an OR whose other branch "
         "does not relate them."),
    Rule("PERF-J006", "Explicit CROSS JOIN / uncorrelated APPLY", "Statement", S.LOW,
         "Explicit product with no relating predicate. Often intentional: manual review."),
    Rule("PERF-P001", "Function or calculation on a filtered or joined column", "Statement",
         S.MEDIUM, "A column wrapped in a function, CASE or arithmetic in WHERE / ON."),
    Rule("PERF-P002", "Leading-wildcard LIKE", "Statement", S.MEDIUM,
         "LIKE pattern that starts with % or _."),
    Rule("PERF-P003", "Optional-parameter (catch-all) predicate", "Statement", S.MEDIUM,
         "@p IS NULL OR col = @p, col = ISNULL(@p, col) and similar."),
    Rule("PERF-S001", "SELECT * projection width", "Statement", S.LOW,
         "SELECT * / t.* in a result set, INSERT ... SELECT, SELECT INTO or cursor."),
    Rule("PERF-L001", "Loop or cursor with repeated database operations", "Statement",
         S.MEDIUM, "WHILE / cursor loop that runs queries or DML per iteration."),
    Rule("PERF-L002", "Batched modification loop", "Statement", S.INFO,
         "WHILE loop around DELETE / UPDATE TOP (n) with @@ROWCOUNT: usually deliberate."),
    Rule("IDX-001", "Index candidate", "Table", S.MEDIUM,
         "Preliminary index candidates from statement access patterns."),
    Rule("PART-001", "Partitioning review", "Table", S.LOW,
         "Tables whose observed range filtering or date-bounded deletes may justify a "
         "partitioning review."),
]

RULES: Dict[str, Rule] = {r.rule_id: r for r in _RULES}
