"""Exact literal arithmetic and SQL Server implicit-conversion rules used by
rewrite suggestions.

Everything here answers one question conservatively: "what value does SQL
Server actually compare?". When the answer depends on something the
analyzer cannot see (collation, code page, approximate numerics, a
conversion error), the functions return None and the caller falls back to
manual review. Numbers are never handled as Python floats.
"""
from __future__ import annotations

from decimal import ROUND_DOWN, ROUND_HALF_UP, Decimal, InvalidOperation
from typing import Optional, Tuple

Literal = Tuple[str, str]          # (kind, value): kind = "number" | "string"

_INT_RANGES = {
    "TINYINT": (0, 255),
    "SMALLINT": (-2 ** 15, 2 ** 15 - 1),
    "INT": (-2 ** 31, 2 ** 31 - 1),
    "BIGINT": (-2 ** 63, 2 ** 63 - 1),
}
_MONEY = {
    "MONEY": (Decimal("-922337203685477.5808"), Decimal("922337203685477.5807")),
    "SMALLMONEY": (Decimal("-214748.3648"), Decimal("214748.3647")),
}
_BYTE_STRINGS = {"CHAR", "VARCHAR"}
_UNICODE_STRINGS = {"NCHAR", "NVARCHAR"}
_STRING_TYPES = _BYTE_STRINGS | _UNICODE_STRINGS
_EXACT_NUMERIC = set(_INT_RANGES) | set(_MONEY) | {"DECIMAL", "NUMERIC"}

# Years a date/time type can hold. smalldatetime ends on 2079-06-06, so
# '20790101' is still valid but '20800101' is not.
YEAR_RANGES = {
    "DATE": (1, 9999), "DATETIME2": (1, 9999), "DATETIMEOFFSET": (1, 9999),
    "DATETIME": (1753, 9999), "SMALLDATETIME": (1900, 2079),
}
# Years for which both 'YYYY0101' and '(YYYY+1)0101' convert to every date/time type.
SAFE_YEARS_ANY_TYPE = (1900, 2078)


def to_decimal(text: str) -> Optional[Decimal]:
    """Exact value of a numeric literal; None for hex, float (E) notation or junk."""
    if not text or "E" in text.upper() or text.lower().startswith(("0x", "-0x")):
        return None
    try:
        value = Decimal(text)
    except InvalidOperation:
        return None
    return value if value.is_finite() else None


def compare_literals(op: str, left: Literal, right: Literal) -> Optional[bool]:
    """Truth value of ``left op right`` for two literals, or None if it depends
    on something unknown (collation, float notation, mixed types)."""
    if left[0] == right[0] == "number":
        a, b = to_decimal(left[1]), to_decimal(right[1])
        if a is None or b is None:
            return None
    elif left[0] == right[0] == "string":
        if op not in ("=", "<>", "!="):
            return None                       # ordering depends on the collation
        a, b = left[1], right[1]
        if a.rstrip(" ") == b.rstrip(" "):    # trailing spaces never count in '='
            return op == "="
        # 'a' = 'A' (case) and 'e' = 'é' (accent) depend on the collation; only
        # plain-ASCII literals that differ beyond case are decided.
        if a.isascii() and b.isascii() and a.rstrip(" ").lower() != b.rstrip(" ").lower():
            return op != "="
        return None
    else:
        return None
    return {"=": a == b, "<>": a != b, "!=": a != b, "<": a < b, ">": a > b, "<=": a <= b,
            ">=": a >= b, "!<": not a < b, "!>": not a > b}.get(op)


def _length(args) -> Optional[int]:
    """Declared length; 1 when omitted (as in a declaration); None for (max)."""
    if not args:
        return 1
    if args[0] == "MAX":
        return None
    return int(args[0]) if args[0].isdigit() else -1


def convert_to_type(lit: Literal, type_name: str, args) -> Tuple[Optional[Literal], str]:
    """The literal after implicit conversion to a column type, as ISNULL does.

    Returns (value, "") or (None, reason)."""
    t = type_name.upper()
    if t in _STRING_TYPES:
        if lit[0] != "string":
            return None, f"a numeric replacement converted to {t.lower()} has a formatting " \
                         f"that is not modelled"
        length = _length(args)
        if length == -1:
            return None, "the declared length could not be read"
        value = lit[1]
        if t in _BYTE_STRINGS and not value.isascii():
            return None, "the byte length of non-ASCII text depends on the code page"
        if t in _UNICODE_STRINGS and any(ord(ch) > 0xFFFF for ch in value):
            return None, "supplementary characters count as two code units"
        if length is not None:
            value = value[:length]
        return ("string", value), ""
    if lit[0] != "number":
        return None, f"a string replacement converted to {t.lower()} may fail or round"
    number = to_decimal(lit[1])
    if number is None:
        return None, "float / hex literals are approximate"
    if t in _INT_RANGES:
        value = number.to_integral_value(rounding=ROUND_DOWN)     # numeric -> int truncates
        low, high = _INT_RANGES[t]
        if not low <= value <= high:
            return None, f"{lit[1]} is outside the {t.lower()} range (conversion error)"
        return ("number", str(value)), ""
    if t in _MONEY:
        value = number.quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP)
        low, high = _MONEY[t]
        if not low <= value <= high:
            return None, f"{lit[1]} is outside the {t.lower()} range (conversion error)"
        return ("number", str(value)), ""
    if t in ("DECIMAL", "NUMERIC"):
        precision = int(args[0]) if args and args[0].isdigit() else 18
        scale = int(args[1]) if len(args) > 1 and args[1].isdigit() else 0
        value = number.quantize(Decimal(1).scaleb(-scale), rounding=ROUND_HALF_UP)
        if abs(value) >= Decimal(10) ** (precision - scale):
            return None, f"{lit[1]} does not fit {t.lower()}({precision},{scale}) " \
                         f"(arithmetic overflow)"
        return ("number", str(value)), ""
    if t == "BIT":
        return ("number", "0" if number == 0 else "1"), ""
    return None, f"conversion to {t.lower()} is not modelled"


def isnull_result(lit: Literal, type_name: str, args) -> Tuple[Optional[Literal], str]:
    """ISNULL(col, lit) returns the type of col: the replacement is converted."""
    return convert_to_type(lit, type_name, args)


def coalesce_result(lit: Literal, type_name: str, args) -> Tuple[Optional[Literal], str]:
    """COALESCE(col, lit) returns the higher-precedence type of its arguments."""
    t = type_name.upper()
    if t in _STRING_TYPES and lit[0] == "string":
        return lit, ""                         # result length is the longer one: no truncation
    if t in _EXACT_NUMERIC and lit[0] == "number":
        if to_decimal(lit[1]) is None:
            return None, "float / hex literals are approximate"
        if t in _MONEY:                        # money outranks decimal: the literal is rounded
            return convert_to_type(lit, t, args)
        return lit, ""                         # int / decimal widen to hold the literal
    return None, f"the result type of COALESCE({t.lower()}, {lit[0]}) is not modelled"


def render_literal(lit: Literal) -> str:
    if lit[0] == "string":
        return "'" + lit[1].replace("'", "''") + "'"
    return lit[1]
