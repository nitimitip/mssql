"""Configuration loading (config.ini + command-line overrides)."""
from __future__ import annotations

import configparser
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

from analyzer.options import AnalysisOptions, PerformanceOptions
from models.common import ObjectType

DEFAULT_CONFIG_FILE = Path(__file__).resolve().parent / "config.ini"

_UNKNOWN_TYPES = {
    "physical table": ObjectType.PHYSICAL_TABLE,
    "unknown database object": ObjectType.UNKNOWN,
}


class ConfigError(Exception):
    pass


@dataclass
class SummaryOptions:
    include_temp_tables: bool = False
    include_table_variables: bool = False
    include_views: bool = True
    include_unknown_objects: bool = True
    include_unparsed_fallback: bool = False
    default_schema: str = "dbo"
    merge_unqualified_with_default_schema: bool = True


@dataclass
class AppConfig:
    config_file: Optional[Path]
    input_directory: Path
    output_directory: Path
    log_directory: Path
    file_extensions: List[str] = field(default_factory=lambda: [".sql"])
    recursive: bool = True
    max_file_size_mb: int = 50
    analysis: AnalysisOptions = field(default_factory=AnalysisOptions)
    summary: SummaryOptions = field(default_factory=SummaryOptions)
    output_file: str = "MSSQL_SP_Dependency_Report.xlsx"
    freeze_panes: bool = True
    enable_filters: bool = True
    log_level: str = "INFO"
    log_file: str = "analyzer.log"
    console_log_level: str = "WARNING"
    # optional folder with CREATE TABLE / CREATE INDEX scripts + table_metadata.csv
    schema_directory: Optional[Path] = None
    schema_extensions: List[str] = field(default_factory=lambda: [".sql"])

    @property
    def performance(self) -> PerformanceOptions:
        return self.analysis.performance

    @property
    def report_path(self) -> Path:
        return self.output_directory / self.output_file

    @property
    def log_path(self) -> Path:
        return self.log_directory / self.log_file

    def describe(self) -> List[str]:
        a, s = self.analysis, self.summary
        return [
            f"config_file={self.config_file}",
            f"input_directory={self.input_directory}",
            f"output_directory={self.output_directory}",
            f"log_directory={self.log_directory}",
            f"file_extensions={','.join(self.file_extensions)} recursive={self.recursive}",
            f"analyze_dynamic_sql={a.analyze_dynamic_sql} max_variants={a.max_dynamic_sql_variants}",
            f"unknown_object_type={a.unknown_object_type} view_prefixes={','.join(a.view_name_prefixes)}",
            f"summary: temp={s.include_temp_tables} table_vars={s.include_table_variables} "
            f"views={s.include_views} unparsed_fallback={s.include_unparsed_fallback} "
            f"default_schema={s.default_schema} merge_unqualified={s.merge_unqualified_with_default_schema}",
            f"excel: file={self.output_file} freeze_panes={self.freeze_panes} filters={self.enable_filters}",
            f"performance: enabled={a.performance.enabled} "
            f"disabled_rules={','.join(sorted(a.performance.disabled_rules)) or 'none'} "
            f"max_key={a.performance.max_key_columns} max_include={a.performance.max_include_columns}",
            f"schema_directory={self.schema_directory or 'not configured'}",
        ]


def _split(value: str) -> List[str]:
    return [v.strip() for v in value.replace(";", ",").split(",") if v.strip()]


def _resolve(base: Path, value: str) -> Path:
    path = Path(value).expanduser()
    return path if path.is_absolute() else (base / path).resolve()


def load_config(config_file: Optional[Path] = None, input_dir: Optional[str] = None,
                output_dir: Optional[str] = None, log_dir: Optional[str] = None,
                log_level: Optional[str] = None, schema_dir: Optional[str] = None) -> AppConfig:
    """Load config.ini; relative paths resolve against the config file's folder."""
    parser = configparser.ConfigParser(interpolation=None)
    path = Path(config_file) if config_file else DEFAULT_CONFIG_FILE
    if config_file and not path.is_file():
        raise ConfigError(f"Configuration file not found: {path}")
    if path.is_file():
        parser.read(path, encoding="utf-8-sig")
        base = path.resolve().parent
    else:
        path = None
        base = Path.cwd()

    def get(section: str, key: str, default: str) -> str:
        return parser.get(section, key, fallback=default).strip()

    def get_bool(section: str, key: str, default: bool) -> bool:
        try:
            return parser.getboolean(section, key, fallback=default)
        except ValueError as exc:
            raise ConfigError(f"[{section}] {key}: expected true/false") from exc

    def get_int(section: str, key: str, default: int) -> int:
        try:
            return parser.getint(section, key, fallback=default)
        except ValueError as exc:
            raise ConfigError(f"[{section}] {key}: expected an integer") from exc

    def get_float(section: str, key: str, default: float) -> float:
        try:
            return parser.getfloat(section, key, fallback=default)
        except ValueError as exc:
            raise ConfigError(f"[{section}] {key}: expected a number") from exc

    unknown_type_raw = get("Analysis", "unknown_object_type", ObjectType.PHYSICAL_TABLE)
    unknown_type = _UNKNOWN_TYPES.get(unknown_type_raw.lower())
    if unknown_type is None:
        raise ConfigError("[Analysis] unknown_object_type must be 'Physical Table' or "
                          "'Unknown Database Object'")

    from analyzer.perf_rules import RULES
    disabled = frozenset(r.upper() for r in _split(get("Performance", "disabled_rules", "")))
    unknown_rules = sorted(disabled - set(RULES))
    if unknown_rules:
        raise ConfigError(f"[Performance] disabled_rules: unknown rule ID(s) "
                          f"{', '.join(unknown_rules)}; valid IDs: {', '.join(RULES)}")
    performance = PerformanceOptions(
        enabled=get_bool("Performance", "enabled", True),
        disabled_rules=disabled,
        max_key_columns=max(1, get_int("Performance", "max_key_columns", 4)),
        max_include_columns=max(0, get_int("Performance", "max_include_columns", 6)),
        partition_min_range_statements=max(1, get_int("Performance",
                                                      "partition_min_range_statements", 2)),
        partition_min_share=get_float("Performance", "partition_min_share", 0.5),
    )
    schema_dir_raw = get("Schema", "schema_directory", "")

    analysis = AnalysisOptions(
        analyze_dynamic_sql=get_bool("Analysis", "analyze_dynamic_sql", True),
        max_dynamic_sql_variants=get_int("Analysis", "max_dynamic_sql_variants", 32),
        max_dynamic_sql_depth=get_int("Analysis", "max_dynamic_sql_depth", 3),
        view_name_prefixes=tuple(_split(get("Analysis", "view_name_prefixes", "vw_"))),
        unknown_object_type=unknown_type,
        fallback_scan_unparsed=get_bool("Analysis", "fallback_scan_unparsed", True),
        performance=performance,
    )
    summary = SummaryOptions(
        include_temp_tables=get_bool("Analysis", "include_temp_tables_in_summary", False),
        include_table_variables=get_bool("Analysis", "include_table_variables_in_summary", False),
        include_views=get_bool("Analysis", "include_views_in_summary", True),
        include_unknown_objects=get_bool("Analysis", "include_unknown_objects_in_summary", True),
        include_unparsed_fallback=get_bool("Analysis", "include_unparsed_fallback_in_summary", False),
        default_schema=get("Analysis", "default_schema", "dbo"),
        merge_unqualified_with_default_schema=get_bool(
            "Analysis", "merge_unqualified_with_default_schema", True),
    )
    extensions = [e if e.startswith(".") else "." + e
                  for e in _split(get("Input", "file_extensions", ".sql"))] or [".sql"]

    return AppConfig(
        config_file=path,
        input_directory=_resolve(Path.cwd(), input_dir) if input_dir
        else _resolve(base, get("Paths", "input_directory", "input/stored_procedures")),
        output_directory=_resolve(Path.cwd(), output_dir) if output_dir
        else _resolve(base, get("Paths", "output_directory", "output")),
        log_directory=_resolve(Path.cwd(), log_dir) if log_dir
        else _resolve(base, get("Paths", "log_directory", "logs")),
        file_extensions=extensions,
        recursive=get_bool("Input", "recursive", True),
        max_file_size_mb=get_int("Input", "max_file_size_mb", 50),
        analysis=analysis,
        summary=summary,
        output_file=get("Excel", "output_file", "MSSQL_SP_Dependency_Report.xlsx"),
        freeze_panes=get_bool("Excel", "freeze_panes", True),
        enable_filters=get_bool("Excel", "enable_filters", True),
        log_level=(log_level or get("Logging", "level", "INFO")).upper(),
        log_file=get("Logging", "log_file", "analyzer.log"),
        console_log_level=get("Logging", "console_level", "WARNING").upper(),
        schema_directory=(_resolve(Path.cwd(), schema_dir) if schema_dir
                          else _resolve(base, schema_dir_raw) if schema_dir_raw else None),
        schema_extensions=[e if e.startswith(".") else "." + e
                           for e in _split(get("Schema", "file_extensions", ".sql"))] or [".sql"],
    )
