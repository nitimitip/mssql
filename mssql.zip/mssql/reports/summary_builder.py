"""Cross-procedure aggregation for the Summary and analysis sheets.

Pure data: nothing here knows about Excel.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from config import SummaryOptions
from models import (
    AnalysisIssue, IssueType, ObjectRef, ObjectType, ProcedureAnalysis, Severity, Status,
    TableUsage,
)

# Summary operation columns -> operations that count towards them.
OPERATION_COLUMNS: List[Tuple[str, Tuple[str, ...]]] = [
    ("SELECT", ("SELECT",)),
    ("INSERT", ("INSERT", "SELECT INTO")),
    ("UPDATE", ("UPDATE",)),
    ("DELETE", ("DELETE", "TRUNCATE")),
    ("MERGE", ("MERGE",)),
    ("JOIN", ("JOIN",)),
]


def include_in_summary(usage: TableUsage, opts: SummaryOptions) -> bool:
    t = usage.obj.object_type
    if usage.fallback_only:
        return opts.include_unparsed_fallback and t in ObjectType.DATABASE_OBJECTS
    if t == ObjectType.PHYSICAL_TABLE:
        return True
    if t == ObjectType.UNKNOWN:
        return opts.include_unknown_objects
    if t == ObjectType.VIEW:
        return opts.include_views
    if t in ObjectType.TEMP_OBJECTS:
        return opts.include_temp_tables
    if t == ObjectType.TABLE_VARIABLE:
        return opts.include_table_variables
    return False


def summary_key(obj: ObjectRef, opts: SummaryOptions) -> Tuple[str, str, str, str]:
    schema = obj.schema or ""
    if (not schema and opts.merge_unqualified_with_default_schema
            and obj.is_database_object):
        schema = opts.default_schema
    return ((obj.server or "").upper(), (obj.database or "").upper(), schema.upper(),
            obj.name.upper())


@dataclass
class TableSummaryRow:
    database: str
    schema: str
    name: str
    object_type: str
    schema_explicit: bool = False
    procedures: List[ProcedureAnalysis] = field(default_factory=list)
    _proc_ids: set = field(default_factory=set, repr=False)
    operation_procs: Dict[str, set] = field(default_factory=dict)
    join_columns: Dict[str, str] = field(default_factory=dict)
    where_columns: Dict[str, str] = field(default_factory=dict)
    dynamic_only_procs: set = field(default_factory=set)
    rank: int = 0

    @property
    def sp_count(self) -> int:
        return len(self.procedures)

    def operation_count(self, column: str) -> int:
        return len(self.operation_procs.get(column, ()))


# Column Usage buckets: (label, TableUsage clause). WHERE includes MERGE WHEN.
COLUMN_CLAUSES: List[Tuple[str, str]] = [
    ("SELECT", "SELECT"), ("JOIN", "JOIN"), ("WHERE", "WHERE"), ("GROUP BY", "GROUP BY"),
    ("HAVING", "HAVING"), ("ORDER BY", "ORDER BY"), ("SET", "SET"),
]


@dataclass
class ColumnUsageRow:
    database: str
    schema: str
    table: str
    column: str
    clause_procs: Dict[str, set] = field(default_factory=dict)   # clause label -> proc keys
    procedures: List[ProcedureAnalysis] = field(default_factory=list)
    _proc_ids: set = field(default_factory=set, repr=False)

    def clause_count(self, label: str) -> int:
        return len(self.clause_procs.get(label, ()))


@dataclass
class JoinRelationshipRow:
    left_table: str
    left_column: str
    operator: str
    right_table: str
    right_column: str
    join_types: List[str] = field(default_factory=list)
    procedures: List[ProcedureAnalysis] = field(default_factory=list)
    _proc_ids: set = field(default_factory=set, repr=False)


def proc_key(analysis: ProcedureAnalysis) -> str:
    """Procedure identity across files.

    All procedures live in one schema in production, so the name alone
    identifies a procedure: dbo.usp_X and usp_X in two files are the same
    procedure and count once.
    """
    return analysis.name.upper()


_STATUS_RANK = {Status.SUCCESS: 0, Status.PARTIAL: 1, Status.MANUAL_REVIEW: 2, Status.FAILED: 3}


def mark_duplicate_procedures(analyses: List[ProcedureAnalysis]) -> None:
    """Flag procedures defined more than once (in one file or across files).

    Identical copies get an INFO issue. Copies whose definitions differ get a
    WARNING, because the summary merges what every version uses and only one
    version can be deployed.
    """
    groups: Dict[str, List[ProcedureAnalysis]] = {}
    for analysis in analyses:
        groups.setdefault(proc_key(analysis), []).append(analysis)
    for copies in groups.values():
        if len(copies) < 2:
            continue
        hashes = {c.definition_hash for c in copies}
        identical = len(hashes) == 1 and "" not in hashes
        for analysis in copies:
            others = [f"{o.source_file} (line {o.line})" if o.line else o.source_file
                      for o in copies if o is not analysis]
            analysis.also_defined_in = others
            if identical:
                analysis.issues.append(AnalysisIssue(
                    Severity.INFO, IssueType.DUPLICATE_PROCEDURE,
                    f"Also defined in {', '.join(others)} with an identical definition; "
                    f"counted once in the Summary", analysis.line))
            else:
                analysis.issues.append(AnalysisIssue(
                    Severity.WARNING, IssueType.DUPLICATE_PROCEDURE,
                    f"Also defined in {', '.join(others)} with a DIFFERENT definition; the "
                    f"Summary counts the procedure once and combines the tables used by every "
                    f"version - confirm which version is deployed", analysis.line))
                if analysis.status == Status.SUCCESS:
                    analysis.status = Status.PARTIAL


def _add_proc(row, analysis: ProcedureAnalysis) -> None:
    key = proc_key(analysis)
    if key not in row._proc_ids:
        row._proc_ids.add(key)
        row.procedures.append(analysis)


def _schema_display(obj: ObjectRef) -> str:
    if obj.schema:
        return obj.schema
    return "Not Specified" if obj.is_database_object else ""


class SummaryBuilder:
    def __init__(self, analyses: List[ProcedureAnalysis], opts: SummaryOptions):
        self.analyses = analyses
        self.opts = opts
        self._table_rows: Optional[List[TableSummaryRow]] = None
        self._display: Dict[Tuple, TableSummaryRow] = {}

    # ------------------------------------------------------------ tables
    def table_rows(self) -> List[TableSummaryRow]:
        if self._table_rows is not None:
            return self._table_rows
        rows: Dict[Tuple, TableSummaryRow] = {}
        for analysis in self.analyses:
            for usage in analysis.tables.values():
                if not include_in_summary(usage, self.opts):
                    continue
                obj = usage.obj
                key = summary_key(obj, self.opts)
                row = rows.get(key)
                if row is None:
                    row = TableSummaryRow(database=obj.database or "", schema=_schema_display(obj),
                                          name=obj.name, object_type=obj.object_type,
                                          schema_explicit=bool(obj.schema))
                    rows[key] = row
                elif obj.schema and not row.schema_explicit:
                    row.schema = obj.schema
                    row.schema_explicit = True
                _add_proc(row, analysis)
                for column, ops in OPERATION_COLUMNS:
                    if any(op in usage.operations for op in ops):
                        row.operation_procs.setdefault(column, set()).add(proc_key(analysis))
                for col in usage.join_columns.values():
                    row.join_columns.setdefault(col.upper(), col)
                for col in list(usage.where_columns.values()) + list(usage.having_columns.values()):
                    row.where_columns.setdefault(col.upper(), col)
                if usage.dynamic and not usage.static:
                    row.dynamic_only_procs.add(proc_key(analysis))
        ordered = sorted(rows.values(), key=lambda r: (-r.sp_count, r.name.upper(), r.schema.upper()))
        previous_count, rank = None, 0
        for idx, row in enumerate(ordered, start=1):
            if row.sp_count != previous_count:
                rank = idx
                previous_count = row.sp_count
            row.rank = rank
            row.procedures.sort(key=lambda a: a.full_name.upper())
        self._display = rows
        self._table_rows = ordered
        return ordered

    def unique_physical_tables(self) -> int:
        return sum(1 for r in self.table_rows()
                   if r.object_type in ObjectType.DATABASE_OBJECTS)

    def _display_parts(self, obj: ObjectRef) -> Tuple[str, str, str]:
        self.table_rows()
        row = self._display.get(summary_key(obj, self.opts))
        if row is not None:
            return row.database, row.schema, row.name
        return obj.database or "", _schema_display(obj), obj.name

    def _table_label(self, obj: ObjectRef) -> str:
        database, schema, name = self._display_parts(obj)
        parts = [p for p in (database, schema if schema != "Not Specified" else "") if p]
        parts.append(name)
        return ".".join(parts)

    # ------------------------------------------------------------ columns
    def column_rows(self) -> List[ColumnUsageRow]:
        rows: Dict[Tuple, ColumnUsageRow] = {}
        for analysis in self.analyses:
            for usage in analysis.tables.values():
                if not include_in_summary(usage, self.opts):
                    continue
                key = summary_key(usage.obj, self.opts)
                database, schema, name = self._display_parts(usage.obj)
                for label, clause in COLUMN_CLAUSES:
                    for col in usage.columns_for(clause).values():
                        ckey = key + (col.upper(),)
                        row = rows.get(ckey)
                        if row is None:
                            row = ColumnUsageRow(database, schema, name, col)
                            rows[ckey] = row
                        row.clause_procs.setdefault(label, set()).add(proc_key(analysis))
                        _add_proc(row, analysis)
        ordered = sorted(rows.values(), key=lambda r: (-len(r.procedures), r.table.upper(),
                                                      r.column.upper()))
        for row in ordered:
            row.procedures.sort(key=lambda a: a.full_name.upper())
        return ordered

    # ------------------------------------------------------------ joins
    def join_rows(self) -> List[JoinRelationshipRow]:
        rows: Dict[Tuple, JoinRelationshipRow] = {}
        symmetric = {"=", "<>", "!="}
        for analysis in self.analyses:
            for join in analysis.joins:
                if len(join.left) != 1 or len(join.right) != 1:
                    continue
                left, right = join.left[0], join.right[0]
                if left.table is None or right.table is None:
                    continue
                if not (left.table.is_database_object and right.table.is_database_object):
                    continue
                lkey = summary_key(left.table, self.opts) + (left.column.upper(),)
                rkey = summary_key(right.table, self.opts) + (right.column.upper(),)
                lpart = (self._table_label(left.table), left.column)
                rpart = (self._table_label(right.table), right.column)
                op = join.operator
                if op in symmetric and rkey < lkey:
                    lkey, rkey = rkey, lkey
                    lpart, rpart = rpart, lpart
                key = (lkey, op, rkey)
                row = rows.get(key)
                if row is None:
                    row = JoinRelationshipRow(lpart[0], lpart[1], op, rpart[0], rpart[1])
                    rows[key] = row
                if join.join_type not in row.join_types:
                    row.join_types.append(join.join_type)
                _add_proc(row, analysis)
        ordered = sorted(rows.values(), key=lambda r: (-len(r.procedures), r.left_table.upper(),
                                                      r.right_table.upper()))
        for row in ordered:
            row.procedures.sort(key=lambda a: a.full_name.upper())
        return ordered

    # ------------------------------------------------------------ status counts
    def procedure_statuses(self) -> Dict[str, str]:
        """Distinct procedure -> worst status over all of its copies."""
        statuses: Dict[str, str] = {}
        for analysis in self.analyses:
            key = proc_key(analysis)
            current = statuses.get(key)
            if current is None or _STATUS_RANK.get(analysis.status, 0) > _STATUS_RANK.get(current, 0):
                statuses[key] = analysis.status
        return statuses

    def procedure_count(self) -> int:
        return len(self.procedure_statuses())

    def duplicate_definitions(self) -> int:
        """Extra copies beyond the first definition of each procedure."""
        return len(self.analyses) - self.procedure_count()

    def status_counts(self) -> Dict[str, int]:
        """Status per distinct procedure (a duplicated procedure counts once)."""
        counts = {Status.SUCCESS: 0, Status.PARTIAL: 0, Status.MANUAL_REVIEW: 0, Status.FAILED: 0}
        for status in self.procedure_statuses().values():
            counts[status] = counts.get(status, 0) + 1
        return counts
