"""Excel report writer (xlsxwriter).

Sheet order: Summary (always first), SP Index, Column Usage, Join
Relationships, Analysis Issues, SP Performance Findings, Index Candidates,
Partitioning Review, Performance Coverage, then one sheet per stored procedure.
Every procedure name is an internal hyperlink to its sheet, and every
procedure sheet links back to Summary.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Dict, List, Optional, Sequence

import xlsxwriter

from config import AppConfig
from models import (
    Confidence, ObjectType, ProcedureAnalysis, Severity, SqlOrigin, Status, TableUsage,
)
from utils.excel_helpers import SheetNameRegistry, clip, internal_link

from analyzer.perf_rules import RULES

from .performance_builder import (
    ASSESS_COVERED, ASSESS_INSUFFICIENT, ASSESS_OVERLAP, INSUFFICIENT_PARTITION, PerformanceBuilder,
)
from .summary_builder import COLUMN_CLAUSES, OPERATION_COLUMNS, SummaryBuilder

log = logging.getLogger(__name__)

SUMMARY = "Summary"
INDEX = "SP Index"
COLUMNS = "Column Usage"
JOINS = "Join Relationships"
ISSUES = "Analysis Issues"
PERF_FINDINGS = "SP Performance Findings"
INDEX_CANDIDATES = "Index Candidates"
PARTITIONING = "Partitioning Review"
PERF_COVERAGE = "Performance Coverage"
PERF_SHEETS = (PERF_FINDINGS, INDEX_CANDIDATES, PARTITIONING, PERF_COVERAGE)
BACK_TO_SUMMARY = "← Back to Summary"

_OBJECT_ORDER = {
    ObjectType.PHYSICAL_TABLE: 0, ObjectType.VIEW: 1, ObjectType.UNKNOWN: 2,
    ObjectType.TEMP_TABLE: 3, ObjectType.GLOBAL_TEMP_TABLE: 4, ObjectType.TABLE_VARIABLE: 5,
    ObjectType.CTE: 6, ObjectType.DERIVED: 7, ObjectType.TABLE_FUNCTION: 8,
    ObjectType.BUILTIN_FUNCTION: 9,
}
_STATUS_FORMAT = {
    Status.SUCCESS: "ok", Status.PARTIAL: "warn", Status.MANUAL_REVIEW: "manual",
    Status.FAILED: "error",
}
_CONFIDENCE_FORMAT = {
    Confidence.HIGH: "ok", Confidence.MEDIUM: "medium", Confidence.LOW: "warn",
    Confidence.MANUAL: "manual",
}
_SEVERITY_FORMAT = {
    Severity.INFO: "plain", Severity.WARNING: "warn", Severity.MANUAL: "manual",
    Severity.ERROR: "error",
}
_PERF_SEVERITY_FORMAT = {"HIGH": "error", "MEDIUM": "warn", "LOW": "medium", "INFO": "plain"}
_ASSESSMENT_FORMAT = {ASSESS_COVERED: "ok", ASSESS_OVERLAP: "warn", ASSESS_INSUFFICIENT: "manual"}
_TAB_COLOR = {
    Status.SUCCESS: "#70AD47", Status.PARTIAL: "#FFC000", Status.MANUAL_REVIEW: "#ED7D31",
    Status.FAILED: "#C00000",
}


class Link:
    __slots__ = ("text", "sheet")

    def __init__(self, text: str, sheet: str):
        self.text = text
        self.sheet = sheet


class Styled:
    __slots__ = ("text", "fmt")

    def __init__(self, text: str, fmt: str):
        self.text = text
        self.fmt = fmt


def _status(value: str) -> Styled:
    return Styled(value, _STATUS_FORMAT.get(value, "plain"))


def _confidence(value: str) -> Styled:
    return Styled(value, _CONFIDENCE_FORMAT.get(value, "plain"))


def _perf_severity(value: str) -> Styled:
    return Styled(value, _PERF_SEVERITY_FORMAT.get(value, "plain"))


def _yes_no(flag: bool) -> str:
    return "Yes" if flag else "No"


class _Sheet:
    """Worksheet wrapper that writes typed cells and tracks column widths."""

    def __init__(self, ws, report: "ExcelReportWriter"):
        self.ws = ws
        self.report = report
        self.widths: Dict[int, int] = {}

    def _note(self, col: int, text: str) -> None:
        longest = max((len(line) for line in text.split("\n")), default=0)
        self.widths[col] = max(self.widths.get(col, 0), longest)

    def cell(self, row: int, col: int, value, fmt: Optional[str] = None) -> None:
        f = self.report.fmt
        cell_fmt = f[fmt] if fmt else None
        if value is None or value == "":
            return
        if isinstance(value, Link):
            self.ws.write_url(row, col, internal_link(value.sheet), f["link"], string=clip(value.text))
            self._note(col, value.text)
        elif isinstance(value, Styled):
            self.ws.write_string(row, col, clip(value.text), f[value.fmt])
            self._note(col, value.text)
        elif isinstance(value, bool):
            self.ws.write_string(row, col, _yes_no(value), cell_fmt)
            self._note(col, "Yes")
        elif isinstance(value, (int, float)):
            self.ws.write_number(row, col, value, cell_fmt)
            self._note(col, str(value))
        else:
            text = clip(str(value))
            self.ws.write_string(row, col, text, cell_fmt)
            self._note(col, text)

    def section(self, row: int, title: str) -> int:
        self.ws.write_string(row, 0, title, self.report.fmt["section"])
        return row + 1

    def table(self, row: int, col: int, headers: Sequence[str], rows: List[Sequence],
              empty_text: str = "None found.") -> int:
        """Write an Excel table; returns the next free row (leaving a gap)."""
        for idx, header in enumerate(headers):
            self._note(col + idx, header + "   ")
        if not rows:
            for idx, header in enumerate(headers):
                self.ws.write_string(row, col + idx, header, self.report.fmt["header"])
            self.ws.write_string(row + 1, col, empty_text, self.report.fmt["italic"])
            return row + 3
        last = row + len(rows)
        self.ws.add_table(row, col, last, col + len(headers) - 1, {
            "columns": [{"header": h} for h in headers],
            "style": "Table Style Medium 2",
            "autofilter": self.report.cfg.enable_filters,
        })
        for r_idx, values in enumerate(rows, start=row + 1):
            for c_idx, value in enumerate(values):
                self.cell(r_idx, col + c_idx, value)
        return last + 2

    def finish(self, max_width: int = 60) -> None:
        for col, width in self.widths.items():
            width = max(6, width + 2)
            if width > max_width:
                self.ws.set_column(col, col, max_width, self.report.fmt["wrap"])
            else:
                self.ws.set_column(col, col, width)


class ExcelReportWriter:
    def __init__(self, cfg: AppConfig):
        self.cfg = cfg
        self.fmt: Dict[str, object] = {}

    def _formats(self, wb) -> None:
        base = {"font_name": "Calibri", "font_size": 10, "valign": "top"}

        def add(name: str, **props) -> None:
            self.fmt[name] = wb.add_format({**base, **props})

        add("title", bold=True, font_size=15, font_color="#1F3864")
        add("subtitle", italic=True, font_color="#595959")
        add("note", italic=True, font_color="#595959", text_wrap=False)
        add("section", bold=True, font_size=12, font_color="#1F3864", bottom=2,
            bottom_color="#1F3864")
        add("header", bold=True, bg_color="#1F3864", font_color="#FFFFFF", border=1)
        add("label", bold=True, bg_color="#D9E1F2", border=1)
        add("value", border=1, text_wrap=True)
        add("link", font_color="#0563C1", underline=1)
        add("link_bold", font_color="#0563C1", underline=1, bold=True, font_size=11)
        add("italic", italic=True, font_color="#7F7F7F")
        add("wrap", text_wrap=True)
        add("plain")
        add("ok", bg_color="#C6EFCE", font_color="#006100", border=1)
        add("medium", bg_color="#FFF2CC", font_color="#7F6000", border=1)
        add("warn", bg_color="#FFEB9C", font_color="#9C5700", bold=True, border=1)
        add("manual", bg_color="#F8CBAD", font_color="#833C0B", bold=True, border=1)
        add("error", bg_color="#FFC7CE", font_color="#9C0006", bold=True, border=1)

    # ------------------------------------------------------------ entry point
    def write(self, analyses: List[ProcedureAnalysis], path: Path, run_info: Dict[str, str],
              catalog=None) -> Path:
        path.parent.mkdir(parents=True, exist_ok=True)
        builder = SummaryBuilder(analyses, self.cfg.summary)
        perf = PerformanceBuilder(analyses, self.cfg.summary, self.cfg.performance, catalog)
        registry = SheetNameRegistry(reserved=[SUMMARY, INDEX, COLUMNS, JOINS, ISSUES,
                                               *PERF_SHEETS])
        ordered = sorted(analyses, key=lambda a: (a.full_name.upper(), a.source_file.upper()))
        for analysis in ordered:
            analysis.sheet_name = registry.assign(id(analysis), analysis.name)

        wb = xlsxwriter.Workbook(str(path), {
            "strings_to_numbers": False,
            "strings_to_formulas": False,
            "strings_to_urls": False,
            # package in memory: avoids one temp file per sheet/table, which
            # dominates run time on Windows for workbooks with many sheets
            "in_memory": True,
        })
        try:
            self._formats(wb)
            self._write_summary(wb.add_worksheet(SUMMARY), builder, run_info, perf)
            self._write_index(wb.add_worksheet(INDEX), ordered)
            self._write_columns(wb.add_worksheet(COLUMNS), builder)
            self._write_joins(wb.add_worksheet(JOINS), builder)
            self._write_issues(wb.add_worksheet(ISSUES), ordered)
            self._write_perf_findings(wb.add_worksheet(PERF_FINDINGS), perf)
            self._write_index_candidates(wb.add_worksheet(INDEX_CANDIDATES), perf, catalog)
            self._write_partitioning(wb.add_worksheet(PARTITIONING), perf)
            self._write_coverage(wb.add_worksheet(PERF_COVERAGE), perf, catalog)
            for analysis in ordered:
                self._write_procedure(wb.add_worksheet(analysis.sheet_name), analysis)
            wb.worksheets()[0].activate()
        finally:
            wb.close()
        log.info("Excel report written: %s (%d procedure sheets)", path, len(ordered))
        return path

    # ------------------------------------------------------------ shared sheets
    def _top_links(self, ws, row: int = 0) -> None:
        ws.write_url(row, 0, internal_link(SUMMARY), self.fmt["link_bold"], string=BACK_TO_SUMMARY)

    def _write_summary(self, ws, builder: SummaryBuilder, run_info: Dict[str, str],
                       perf: Optional[PerformanceBuilder] = None) -> None:
        s = _Sheet(ws, self)
        counts = builder.status_counts()
        rows_data = builder.table_rows()
        ws.write_string(0, 0, "MSSQL Stored Procedure Dependency Report", self.fmt["title"])
        ws.write_string(1, 0, (
            f"Generated {run_info.get('generated', '')}   |   Input: {run_info.get('input', '')}   |   "
            f"Procedures: {builder.procedure_count()}"
            + (f" ({builder.duplicate_definitions()} duplicate definitions merged)"
               if builder.duplicate_definitions() else "")
            + f"   |   SUCCESS {counts[Status.SUCCESS]}   |   "
            f"PARTIAL {counts[Status.PARTIAL]}   |   MANUAL REVIEW REQUIRED "
            f"{counts[Status.MANUAL_REVIEW]}   |   FAILED {counts[Status.FAILED]}   |   "
            f"Unique physical tables: {builder.unique_physical_tables()}"), self.fmt["subtitle"])
        excluded = []
        if not self.cfg.summary.include_temp_tables:
            excluded.append("temporary tables")
        if not self.cfg.summary.include_table_variables:
            excluded.append("table variables")
        ws.write_string(2, 0, (
            "SP Count = number of distinct stored procedures referencing the table (a procedure "
            "counts once however often it uses the table). "
            + (f"Excluded: {', '.join(excluded)}, CTEs, derived tables. " if excluded else "")
            + "Operation columns count procedures (INSERT includes SELECT INTO; DELETE includes "
              "TRUNCATE). Click a procedure name to open its sheet."), self.fmt["note"])
        if perf is not None:
            counts = perf.finding_counts()
            ws.write_url(3, 0, internal_link(PERF_FINDINGS), self.fmt["link_bold"], string=(
                f"Performance review (static review items, not measurements): "
                f"{sum(counts.values())} SP findings (HIGH {counts['HIGH']}, MEDIUM "
                f"{counts['MEDIUM']}, LOW {counts['LOW']}, INFO {counts['INFO']})  |  "
                f"{len(perf.index_candidates())} index candidates  |  "
                f"{len(perf.partition_assessments())} partitioning reviews  |  open SP "
                f"Performance Findings"))
        max_sps = max((r.sp_count for r in rows_data), default=0)
        headers = (["Rank", "Database", "Schema", "Table Name", "Object Type", "SP Count"]
                   + [c for c, _ in OPERATION_COLUMNS]
                   + [f"SP {i}" for i in range(1, max_sps + 1)])
        rows = []
        for r in rows_data:
            values = [r.rank, r.database, r.schema, r.name, r.object_type, r.sp_count]
            values += [r.operation_count(c) for c, _ in OPERATION_COLUMNS]
            values += [Link(a.full_name, a.sheet_name) for a in r.procedures]
            rows.append(values)
        s.table(4, 0, headers, rows, "No physical tables were found.")
        s.finish(max_width=45)
        if self.cfg.freeze_panes:
            ws.freeze_panes(5, 4)

    def _write_index(self, ws, analyses: List[ProcedureAnalysis]) -> None:
        s = _Sheet(ws, self)
        self._top_links(ws)
        ws.write_string(1, 0, "Stored Procedure Index", self.fmt["title"])
        headers = ["#", "Stored Procedure", "Schema", "Source File", "Status", "Confidence",
                   "Dynamic SQL", "Manual Review Required", "Physical Tables", "Temp Tables",
                   "Table Variables", "JOIN Predicates", "Filter Predicates", "Warnings",
                   "Statements Analysed", "Statements Failed", "Seconds", "Also Defined In",
                   "Performance Findings"]
        rows = []
        for idx, a in enumerate(analyses, start=1):
            rows.append([idx, Link(a.full_name, a.sheet_name), a.schema or "Not Specified",
                         a.source_file, _status(a.status), _confidence(a.confidence),
                         _yes_no(a.dynamic_sql_detected), _yes_no(a.manual_review_required),
                         len(a.physical_tables), len(a.temp_tables), len(a.table_variables),
                         len(a.joins), len(a.filters), a.warning_count, a.statements_total,
                         a.statements_failed, round(a.elapsed_seconds, 3),
                         ", ".join(a.also_defined_in), len(a.perf_findings)])
        s.table(3, 0, headers, rows, "No stored procedures were analysed.")
        s.finish()
        if self.cfg.freeze_panes:
            ws.freeze_panes(4, 2)

    def _write_columns(self, ws, builder: SummaryBuilder) -> None:
        s = _Sheet(ws, self)
        self._top_links(ws)
        ws.write_string(1, 0, "Column Usage by Clause", self.fmt["title"])
        ws.write_string(2, 0, "Counts are distinct stored procedures. SELECT includes window "
                              "PARTITION BY / ORDER BY; SET covers the assigned column and the "
                              "columns its value reads (UPDATE and MERGE); WHERE includes MERGE "
                              "WHEN. Column * = SELECT * / t.* (every column).",
                        self.fmt["note"])
        headers = (["Database", "Schema", "Table Name", "Column"]
                   + [f"{label} SP Count" for label, _ in COLUMN_CLAUSES]
                   + ["Total SP Count", "Stored Procedures"])
        rows = [[r.database, r.schema, r.table, r.column]
                + [r.clause_count(label) for label, _ in COLUMN_CLAUSES]
                + [len(r.procedures), ", ".join(a.full_name for a in r.procedures)]
                for r in builder.column_rows()]
        s.table(4, 0, headers, rows)
        s.finish(max_width=80)
        if self.cfg.freeze_panes:
            ws.freeze_panes(5, 4)

    def _write_joins(self, ws, builder: SummaryBuilder) -> None:
        s = _Sheet(ws, self)
        self._top_links(ws)
        ws.write_string(1, 0, "Join Relationships Between Tables", self.fmt["title"])
        ws.write_string(2, 0, "Single-column table-to-table predicates from ON clauses, MERGE ON, "
                              "IN-subqueries, correlated subqueries and WHERE join predicates.",
                        self.fmt["note"])
        headers = ["Left Table", "Left Column", "Operator", "Right Table", "Right Column",
                   "Join Types", "SP Count", "Stored Procedures"]
        rows = [[r.left_table, r.left_column, r.operator, r.right_table, r.right_column,
                 ", ".join(r.join_types), len(r.procedures),
                 ", ".join(a.full_name for a in r.procedures)]
                for r in builder.join_rows()]
        s.table(4, 0, headers, rows)
        s.finish(max_width=80)
        if self.cfg.freeze_panes:
            ws.freeze_panes(5, 0)

    def _write_issues(self, ws, analyses: List[ProcedureAnalysis]) -> None:
        s = _Sheet(ws, self)
        self._top_links(ws)
        ws.write_string(1, 0, "Analysis Issues", self.fmt["title"])
        ws.write_string(2, 0, "INFO items do not change a procedure's status; WARNING -> PARTIAL; "
                              "MANUAL -> MANUAL REVIEW REQUIRED; ERROR -> FAILED.", self.fmt["note"])
        headers = ["Source File", "Stored Procedure", "Status", "Severity", "Issue Type", "Line",
                   "Description"]
        rows = []
        for a in analyses:
            for issue in a.issues:
                rows.append([a.source_file, Link(a.full_name, a.sheet_name), _status(a.status),
                             Styled(issue.severity, _SEVERITY_FORMAT.get(issue.severity, "plain")),
                             issue.issue_type, issue.line or "", issue.description])
        s.table(4, 0, headers, rows, "No issues were recorded.")
        s.finish(max_width=110)
        if self.cfg.freeze_panes:
            ws.freeze_panes(5, 0)

    # ------------------------------------------------------------ procedure sheet
    def _write_procedure(self, ws, a: ProcedureAnalysis) -> None:
        s = _Sheet(ws, self)
        ws.set_tab_color(_TAB_COLOR.get(a.status, "#808080"))
        self._top_links(ws)
        ws.write_url(0, 1, internal_link(INDEX), self.fmt["link"], string="SP Index")
        ws.write_url(0, 2, internal_link(PERF_FINDINGS), self.fmt["link"],
                     string=PERF_FINDINGS)
        ws.write_string(1, 0, f"Stored Procedure: {a.full_name}", self.fmt["title"])

        header = [
            ("Stored Procedure Name", a.full_name),
            ("Schema", a.schema or "Not Specified"),
            ("Source File", a.source_file),
            ("Also Defined In", ", ".join(a.also_defined_in) or "None"),
            ("Analysis Status", _status(a.status)),
            ("Confidence", _confidence(a.confidence)),
            ("Dynamic SQL Detected", _yes_no(a.dynamic_sql_detected)),
            ("Manual Review Required", _yes_no(a.manual_review_required)),
            ("Total Physical Tables", len(a.physical_tables)),
            ("Total Temporary Tables", len(a.temp_tables)),
            ("Total Table Variables", len(a.table_variables)),
            ("Parsing Warnings", a.warning_count),
            ("Statements Analysed / Failed", f"{a.statements_total} / {a.statements_failed}"),
            ("Parameters", ", ".join(a.parameters) or "None"),
            ("Procedures Called", ", ".join(a.procedures_called) or "None"),
            ("Functions Referenced (FROM)", ", ".join(a.functions_called) or "None"),
        ]
        row = 3
        for label, value in header:
            s.cell(row, 0, label, "label")
            if isinstance(value, Styled):
                s.cell(row, 1, value)
            else:
                s.cell(row, 1, value, "value")
            row += 1
        row += 1

        row = s.section(row, "1. Table Usage")
        usages = sorted(a.tables.values(),
                        key=lambda u: (_OBJECT_ORDER.get(u.obj.object_type, 99), u.fallback_only,
                                       u.first_line, u.obj.name.upper()))
        row = s.table(row, 0, [
            "Database", "Schema", "Table Name", "Object Type", "Alias(es)", "Operations",
            "JOIN Column Count", "JOIN Columns", "WHERE Column Count", "WHERE Columns",
            "HAVING Columns", "SELECT Columns", "SET Columns", "GROUP BY Columns",
            "ORDER BY Columns", "Via Dynamic SQL", "Confidence", "First Line", "Notes",
        ], [self._usage_row(u) for u in usages], "No tables were identified.")

        row = s.section(row, "2. JOIN / ON Details")
        ws.write_string(row, 0, "Logic and Full Condition work as in section 3: an ON clause "
                                "joined with OR keeps its OR.", self.fmt["note"])
        row = s.table(row + 1, 0, [
            "#", "Join Type", "Left Table", "Left Column", "Operator", "Right Table",
            "Right Column / Value", "Logic", "Confidence", "Original Condition",
            "Normalized Condition", "Full Condition", "Context", "Line", "Occurrences", "Notes",
        ], [self._join_row(i, j) for i, j in enumerate(a.joins, start=1)])

        row = s.section(row, "3. WHERE / HAVING Filter Details")
        ws.write_string(row, 0, "Logic = AND / OR / NOT groups from the outermost condition down "
                                "to this predicate (blank = the predicate is the whole "
                                "condition). Full Condition keeps the original business rule.",
                        self.fmt["note"])
        row = s.table(row + 1, 0, [
            "#", "Clause", "Table", "Column", "Operator", "Compared With", "Logic",
            "Confidence", "Original Condition", "Full Condition", "Locations", "Line",
            "Occurrences", "Notes",
        ], [[i, f.clause, f.column.table_display, f.column.column, f.operator, f.compared_with,
             f.logic, _confidence(f.confidence), f.original, f.full_condition,
             "; ".join(f.locations or [f.context]), f.line, f.occurrences,
             f.notes + ("; dynamic SQL" if f.dynamic else "")]
            for i, f in enumerate(a.filters, start=1)])

        row = s.section(row, "4. Unresolved / Ambiguous Column References")
        row = s.table(row, 0, [
            "#", "Clause", "Reference", "Owner / Candidate Tables", "Confidence", "Reason",
            "Context", "Line",
        ], [[i, u.clause, u.ref.original or u.ref.column,
             ", ".join(u.ref.candidates) if u.ref.candidates else u.ref.table_display,
             _confidence(u.ref.confidence), u.ref.note, u.context, u.line]
            for i, u in enumerate(a.unresolved, start=1)])

        row = s.section(row, "5. Dynamic SQL")
        row = s.table(row, 0, [
            "#", "Line", "Form", "Statement Expression", "Resolution", "Variants", "Notes",
        ], [[i, d.line, d.form, d.expression,
             Styled(d.resolution, "manual" if d.resolution.startswith("Manual") else
                    ("warn" if d.resolution.startswith("Partially") else "ok")),
             d.variants or "", d.notes]
            for i, d in enumerate(a.dynamic_sql, start=1)])

        row = s.section(row, "6. Analysis Issues")
        row = s.table(row, 0, ["#", "Severity", "Issue Type", "Line", "Description"],
                      [[i, Styled(x.severity, _SEVERITY_FORMAT.get(x.severity, "plain")),
                        x.issue_type, x.line or "", x.description]
                       for i, x in enumerate(a.issues, start=1)])

        row = s.section(row, "7. Performance Findings")
        ws.write_string(row, 0, "Static review items (the SP Performance Findings sheet has the "
                                "actions, assumptions and validation). Severity = possible impact; "
                                "Confidence = certainty the pattern is present.", self.fmt["note"])
        s.table(row + 1, 0, ["#", "Rule ID", "Severity", "Confidence", "Statement ID", "Line",
                             "SQL Origin", "Finding", "SQL Evidence"],
                [[i, f.rule_id, _perf_severity(f.severity), _confidence(f.confidence),
                  ", ".join(f.statement_ids or [f.statement_id]), f.line or "", f.origin,
                  f.finding, f.evidence]
                 for i, f in enumerate(a.perf_findings, start=1)],
                "No performance findings. This is not proof of absence of risk - see "
                "Performance Coverage.")

        s.finish()
        if self.cfg.freeze_panes:
            ws.freeze_panes(2, 0)

    # ------------------------------------------------------------ performance sheets
    def _perf_nav(self, s: "_Sheet", current: str) -> None:
        s.cell(0, 0, Link(BACK_TO_SUMMARY, SUMMARY))
        col = 1
        for name in PERF_SHEETS:
            if name != current:
                s.cell(0, col, Link(name, name))
                col += 1

    def _write_perf_findings(self, ws, perf: PerformanceBuilder) -> None:
        s = _Sheet(ws, self)
        self._perf_nav(s, PERF_FINDINGS)
        ws.write_string(1, 0, "Stored Procedure Performance Findings", self.fmt["title"])
        ws.write_string(2, 0, (
            "Static, rule-based review items - not measured results, never applied. Severity = "
            "possible impact if the pattern matters at runtime; Confidence = how certain the "
            "analyzer is that the pattern is present as described. Statement ID = statement "
            "order in the procedure (S7.D1 = statement 1 of the dynamic SQL run by S7). No "
            "finding does not mean no risk: see Performance Coverage."), self.fmt["note"])
        headers = ["Rule ID", "Severity", "Confidence", "Procedure", "Source File", "Statement ID",
                   "Line", "Tables/Aliases", "Finding", "SQL Evidence", "Suggested Action",
                   "Assumptions", "Required Validation", "Rule Name", "SQL Origin", "Context",
                   "Occurrences"]
        rows = []
        for a, f in perf.findings():
            rule = RULES.get(f.rule_id)
            rows.append([f.rule_id, _perf_severity(f.severity), _confidence(f.confidence),
                         Link(a.full_name, a.sheet_name), a.source_file,
                         ", ".join(f.statement_ids or [f.statement_id]), f.line or "", f.tables,
                         f.finding, f.evidence, f.action, f.assumptions, f.validation,
                         rule.name if rule else "", f.origin, f.context, f.occurrences])
        empty = ("No performance findings. See Performance Coverage for what was not analysed."
                 if self.cfg.performance.enabled
                 else "Performance review disabled in configuration ([Performance] enabled).")
        s.table(4, 0, headers, rows, empty)
        s.finish(max_width=70)
        if self.cfg.freeze_panes:
            ws.freeze_panes(5, 1)

    def _write_index_candidates(self, ws, perf: PerformanceBuilder, catalog) -> None:
        s = _Sheet(ws, self)
        self._perf_nav(s, INDEX_CANDIDATES)
        ws.write_string(1, 0, "Index Candidates (preliminary, review-only)", self.fmt["title"])
        existing = ("Existing indexes were compared from the schema folder." if catalog is not None
                    else "Existing index definitions were NOT provided, so no candidate is "
                         "claimed to be missing.")
        ws.write_string(2, 0, (
            "Built per statement from equality, range, join, grouping and ordering predicates, "
            "then consolidated only when identical. Key order is a reasoned candidate, not a "
            "proven optimum. Supporting SP Count = distinct procedures, NOT execution "
            f"frequency. The DDL is commented out and must never be run unreviewed. {existing}"),
            self.fmt["note"])
        headers = ["Candidate ID", "Table", "Key Columns", "INCLUDE Columns", "Filter",
                   "Existing Index Assessment", "Supporting SP Count", "Supporting Procedures",
                   "Statement Evidence", "Reasoning", "Trade-offs", "Confidence",
                   "Required Validation", "Candidate Type", "Overlap / Consolidation",
                   "Supporting Statement Count", "Review-only DDL"]
        rows = []
        for c in perf.index_candidates():
            evidence = list(dict.fromkeys(sup.label for sup in c.supports))
            if len(evidence) > 20:
                evidence = evidence[:20] + [f"... and {len(evidence) - 20} more"]
            rows.append([c.candidate_id, c.table_display, ", ".join(c.keys),
                         ", ".join(c.includes), c.filter,
                         Styled(f"{c.assessment}: {c.assessment_detail}",
                                _ASSESSMENT_FORMAT.get(c.assessment, "medium")),
                         len(c.procedures), ", ".join(a.full_name for a in c.procedures),
                         "\n".join(evidence), c.reasoning, c.tradeoffs, _confidence(c.confidence),
                         c.validation, c.candidate_type, c.overlap, c.statement_count, c.ddl])
        empty = ("No index candidates: no statement filtered or joined a physical table on "
                 "resolved columns." if self.cfg.performance.rule_enabled("IDX-001")
                 else "Index candidates disabled (IDX-001).")
        s.table(4, 0, headers, rows, empty)
        s.finish(max_width=70)
        if self.cfg.freeze_panes:
            ws.freeze_panes(5, 2)

    def _write_partitioning(self, ws, perf: PerformanceBuilder) -> None:
        s = _Sheet(ws, self)
        self._perf_nav(s, PARTITIONING)
        ws.write_string(1, 0, "Partitioning Review", self.fmt["title"])
        ws.write_string(2, 0, (
            "Listed only for repeated range filtering on one column or range-bounded deletes - "
            "never just because a date column exists or many procedures use the table. No "
            "partition boundaries are proposed and no speed-up is promised. Size, distribution, "
            "growth and retention come from table_metadata.csv in the schema folder."),
            self.fmt["note"])
        headers = ["Table", "Candidate Column", "Observed Pattern", "Supporting Procedures",
                   "Available Evidence", "Missing Evidence", "Potential Benefit", "Assessment",
                   "Considerations", "Statement Evidence"]
        rows = [[p.table_display, p.column, p.pattern,
                 ", ".join(a.full_name for a in p.procedures), p.available, p.missing, p.benefit,
                 Styled(p.assessment,
                        "manual" if p.assessment == INSUFFICIENT_PARTITION else "medium"),
                 p.considerations, p.evidence]
                for p in perf.partition_assessments()]
        empty = ("No table showed repeated range filtering on a consistent column or "
                 "range-bounded deletes in the analysed code."
                 if self.cfg.performance.rule_enabled("PART-001")
                 else "Partitioning review disabled (PART-001).")
        s.table(4, 0, headers, rows, empty)
        s.finish(max_width=70)
        if self.cfg.freeze_panes:
            ws.freeze_panes(5, 1)

    def _write_coverage(self, ws, perf: PerformanceBuilder, catalog) -> None:
        s = _Sheet(ws, self)
        self._perf_nav(s, PERF_COVERAGE)
        ws.write_string(1, 0, "Performance Review Coverage", self.fmt["title"])
        ws.write_string(2, 0, (
            "What the performance review could NOT see. Kept separate from findings and from "
            "analysis status: a procedure with no findings may still carry risk in the parts "
            "listed here."), self.fmt["note"])
        row = s.section(4, "1. Coverage by procedure")
        rows = []
        for c in perf.coverage():
            a = c.analysis
            static = (sum(1 for f in a.perf_findings if f.origin == SqlOrigin.STATIC)
                      if a else "")
            dynamic = (sum(1 for f in a.perf_findings if f.origin != SqlOrigin.STATIC)
                       if a else "")
            rows.append([Link(a.full_name, a.sheet_name) if a else "(schema folder)",
                         a.source_file if a else "", _status(a.status) if a else "",
                         Styled(c.gap_type, "ok" if c.gap_type == "No coverage gaps" else "warn"),
                         c.line or "", c.detail, c.effect, static, dynamic])
        row = s.table(row, 0, ["Procedure", "Source File", "Analysis Status", "Gap Type", "Line",
                               "Detail", "Effect on Performance Review", "Static SQL Findings",
                               "Dynamic SQL Findings"], rows, "No procedures were analysed.")
        row = s.section(row, "2. Rules")
        row = s.table(row, 0, ["Rule ID", "Name", "Scope", "Default Severity", "Enabled",
                               "Description"], perf.rule_rows())
        row = s.section(row, "3. Schema definitions")
        if catalog is None:
            info = [["Not configured", "Set [Schema] schema_directory (or --schema) to compare "
                                       "candidates with existing indexes and to supply "
                                       "partitioning facts."]]
        else:
            info = [["Files read", ", ".join(catalog.files_read) or "None"],
                    ["Tables defined", catalog.table_count],
                    ["Indexes / key constraints", catalog.index_count],
                    ["Metadata file", catalog.metadata_file or "None (table_metadata.csv)"],
                    ["Warnings", len(catalog.warnings)]]
        s.table(row, 0, ["Item", "Value"], info)
        s.finish(max_width=80)

    @staticmethod
    def _usage_row(u: TableUsage) -> list:
        obj = u.obj
        schema = obj.schema or ("Not Specified" if obj.is_database_object else "")
        notes = []
        if u.fallback_only:
            notes.append("Found only by token scan of an unparsed statement (unverified)")
        if u.dynamic and not u.static:
            notes.append("Referenced only inside dynamic SQL")
        return [obj.database or "", schema, obj.name, obj.object_type, ", ".join(u.aliases),
                ", ".join(u.operations), len(u.join_columns), ", ".join(u.join_columns.values()),
                len(u.where_columns), ", ".join(u.where_columns.values()),
                ", ".join(u.having_columns.values()), ", ".join(u.select_columns.values()),
                ", ".join(u.set_columns.values()), ", ".join(u.group_by_columns.values()),
                ", ".join(u.order_by_columns.values()), _yes_no(u.dynamic),
                _confidence(u.confidence), u.first_line or "", "; ".join(notes)]

    @staticmethod
    def _join_row(i: int, j) -> list:
        def tables(refs):
            return "; ".join(dict.fromkeys(r.table_display for r in refs))

        def columns(refs):
            return "; ".join(dict.fromkeys(r.column for r in refs))

        right_table = tables(j.right) if j.right else ""
        right_value = columns(j.right) if j.right else j.right_value
        notes = j.notes + ("; dynamic SQL" if j.dynamic else "")
        return [i, j.join_type, tables(j.left), columns(j.left), j.operator, right_table,
                right_value, j.logic, _confidence(j.confidence), j.original, j.normalized,
                j.full_condition, j.context, j.line, j.occurrences, notes.strip("; ")]
