"""Cross-procedure performance aggregation: findings, coverage, index candidates,
partitioning review. Pure data: nothing here knows about Excel.

Index candidates are built per statement (each statement's own column
combination) and only then consolidated when the proposed structure is
identical. Columns from unrelated statements are never merged into one wide
key. Procedure counts are distinct procedures, never execution frequency.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Set, Tuple

from analyzer.options import PerformanceOptions
from analyzer.perf_rules import RULES
from config import SummaryOptions
from models import Confidence, IssueType, ObjectType, ProcedureAnalysis, Status
from models.common import ObjectRef, condition_key, quote_ident
from models.performance import (
    EQ, EQ_JOIN, IN_LIST, NONSARGABLE, OR_BRANCH, PREFIX, RANGE, RESIDUAL, AccessRecord,
    PerfFinding, PerfSeverity,
)

from analyzer.tokenizer import EOF, GO, OP, QIDENT, STRING, WORD, TokenizeError, tokenize

from .summary_builder import proc_key, summary_key

INSUFFICIENT_PARTITION = "Insufficient evidence for a partitioning recommendation."

ASSESS_CANDIDATE = "Candidate to evaluate"
ASSESS_COVERED = "Already covered by an existing index"
ASSESS_OVERLAP = "Possible extension or overlap requiring review"
ASSESS_INSUFFICIENT = "Insufficient information"

_INDEXABLE = frozenset({ObjectType.PHYSICAL_TABLE, ObjectType.UNKNOWN})
_PARTITION_EVIDENCE = ("table size", "row distribution", "growth", "retention policy",
                       "existing partitioning", "key constraints")


def _base_statement(statement_id: str) -> str:
    return statement_id.split(".")[0]


def _add(target: List[str], values) -> None:
    for value in values:
        if value and value.upper() not in (v.upper() for v in target):
            target.append(value)


def _q(name: str) -> str:
    return "[" + name.replace("]", "]]") + "]"


def filter_key(text: str) -> Tuple:
    """Comparison key for an index filter predicate.

    [Status] = 'OPEN', Status='OPEN' and SSMS-scripted ([Status]='OPEN') compare
    equal; string literals compare exactly (case and inner whitespace kept).
    Parentheses are ignored, which is safe for the AND-only filters compared here.
    """
    if not text:
        return ()
    try:
        tokens = tokenize(text)
    except TokenizeError:
        return (condition_key(text),)
    key = []
    for tok in tokens:
        if tok.kind in (EOF, GO) or (tok.kind == OP and tok.value in ("(", ")")):
            continue
        if tok.kind in (WORD, QIDENT):
            key.append(("ID", tok.value.upper()))
        elif tok.kind == STRING:
            key.append(("STR", tok.value))
        else:
            key.append((tok.kind, tok.value.upper()))
    return tuple(key)


@dataclass(eq=False)
class Support:
    analysis: ProcedureAnalysis
    record: AccessRecord

    @property
    def label(self) -> str:
        r = self.record
        cond = r.condition_text or "(no filter on this table)"
        extra = [f"confidence {r.confidence}"]
        if r.unresolved:
            extra.append("unresolved: " + ", ".join(r.unresolved))
        if r.dynamic:
            extra.append("dynamic SQL")
        if r.in_loop:
            extra.append("inside a loop")
        where = self.analysis.full_name
        if self.analysis.also_defined_in:          # name which copy of the procedure
            where += f" ({self.analysis.source_file})"
        return f"{where} {r.statement_id} (line {r.line}) {r.operation}: {cond} [{'; '.join(extra)}]"


def _record_signature(r: AccessRecord) -> Tuple:
    """Everything a record asks of the table. Two records are duplicates only when
    all of it matches (identical procedure copies, repeated dynamic-SQL variants);
    differing versions of a procedure are kept apart."""
    return (r.operation, r.role, r.alias.upper(), condition_key(r.condition_text),
            tuple(sorted((p.kind, p.column.upper(), p.op, p.value) for p in r.predicates)),
            tuple(c.upper() for c in r.projected), r.star,
            tuple(c.upper() for c in r.order_by), tuple(c.upper() for c in r.group_by),
            tuple(sorted(c.upper() for c in r.other_columns)),
            tuple(sorted(c.upper() for c in r.updated)), r.top, r.confidence,
            tuple(sorted(r.unresolved)))


@dataclass
class IndexCandidate:
    table_key: Tuple
    table: ObjectRef
    table_display: str
    keys: List[str]
    eq_count: int
    includes: List[str]
    filter: str
    supports: List[Support] = field(default_factory=list)
    reasons: List[str] = field(default_factory=list)
    include_note: str = ""
    candidate_id: str = ""
    assessment: str = ""
    assessment_detail: str = ""
    overlap: str = ""
    confidence: str = Confidence.HIGH
    reasoning: str = ""
    tradeoffs: str = ""
    validation: str = ""
    ddl: str = ""
    # every INCLUDE column requested before the width cap was applied
    wanted_includes: List[str] = field(default_factory=list)
    filter_columns: List[str] = field(default_factory=list)

    @property
    def candidate_type(self) -> str:
        return "Nonclustered (filtered)" if self.filter else "Nonclustered"

    @property
    def procedures(self) -> List[ProcedureAnalysis]:
        seen, out = set(), []
        for s in self.supports:
            key = proc_key(s.analysis)
            if key not in seen:
                seen.add(key)
                out.append(s.analysis)
        return sorted(out, key=lambda a: a.full_name.upper())

    @property
    def statement_count(self) -> int:
        return len({(proc_key(s.analysis), s.analysis.source_file,
                     _base_statement(s.record.statement_id)) for s in self.supports})

    @property
    def confidence_breakdown(self) -> Dict[str, int]:
        counts: Dict[str, int] = {}
        for s in self.supports:
            counts[s.record.confidence] = counts.get(s.record.confidence, 0) + 1
        return counts

    @property
    def uncertain_supports(self) -> List["Support"]:
        return [s for s in self.supports
                if s.record.confidence == Confidence.LOW or s.record.unresolved]


@dataclass
class PartitionAssessment:
    table_display: str
    column: str
    pattern: str
    procedures: List[ProcedureAnalysis]
    available: str
    missing: str
    benefit: str
    assessment: str
    considerations: str
    evidence: str


@dataclass
class CoverageRow:
    analysis: Optional[ProcedureAnalysis]
    gap_type: str
    line: int
    detail: str
    effect: str


class PerformanceBuilder:
    def __init__(self, analyses: List[ProcedureAnalysis], summary_opts: SummaryOptions,
                 perf_opts: Optional[PerformanceOptions] = None, catalog=None):
        self.analyses = analyses
        self.sopts = summary_opts
        self.popts = perf_opts or PerformanceOptions()
        self.catalog = catalog
        self._candidates: Optional[List[IndexCandidate]] = None
        self._partitions: Optional[List[PartitionAssessment]] = None
        self._by_table: Optional[Dict[Tuple, List[Support]]] = None

    # ------------------------------------------------------------ findings
    def findings(self) -> List[Tuple[ProcedureAnalysis, PerfFinding]]:
        rows = [(a, f) for a in self.analyses for f in a.perf_findings]
        rows.sort(key=lambda r: (PerfSeverity.rank(r[1].severity), r[0].full_name.upper(),
                                 r[1].line, r[1].rule_id))
        return rows

    def finding_counts(self) -> Dict[str, int]:
        counts = {s: 0 for s in (PerfSeverity.HIGH, PerfSeverity.MEDIUM, PerfSeverity.LOW,
                                 PerfSeverity.INFO)}
        for _, f in self.findings():
            counts[f.severity] = counts.get(f.severity, 0) + 1
        return counts

    # ------------------------------------------------------------ coverage
    def coverage(self) -> List[CoverageRow]:
        rows: List[CoverageRow] = []
        for a in sorted(self.analyses, key=lambda x: (x.full_name.upper(), x.source_file.upper())):
            before = len(rows)
            if not self.popts.enabled:
                rows.append(CoverageRow(a, "Performance review disabled", 0,
                                        "[Performance] enabled = false in the configuration.",
                                        "No statement rules, index candidates or partitioning "
                                        "assessments were produced."))
                continue
            if a.status == Status.FAILED:
                rows.append(CoverageRow(a, "Analysis failed", 0,
                                        "; ".join(i.description for i in a.issues
                                                  if i.severity == "ERROR")[:500],
                                        "No performance rules ran for this procedure."))
                continue
            if a.statements_failed:
                lines = sorted({i.line for i in a.issues
                                if i.description.startswith("Statement not analysed")})
                rows.append(CoverageRow(
                    a, "Unparsed statements", lines[0] if lines else 0,
                    f"{a.statements_failed} of {a.statements_total} statement(s) could not be "
                    f"parsed (lines {', '.join(map(str, lines)) or 'n/a'}).",
                    "Performance rules did not run on these statements; their tables do not "
                    "contribute to index candidates or partitioning review."))
            for d in a.dynamic_sql:
                if d.resolution.startswith("Manual"):
                    rows.append(CoverageRow(
                        a, "Runtime-generated SQL not analysed", d.line,
                        f"{d.form} {d.expression}: {d.resolution}"
                        + (f" ({d.notes})" if d.notes else ""),
                        "The SQL text is built at runtime; its joins, predicates and table "
                        "access cannot be reviewed statically. Review the generated statements "
                        "(for example from Query Store) manually."))
                elif d.resolution.startswith("Partially"):
                    rows.append(CoverageRow(
                        a, "Dynamic SQL partially analysed", d.line,
                        f"{d.form} {d.expression}: {d.resolution}",
                        "Variants that could not be parsed were not reviewed."))
                else:
                    rows.append(CoverageRow(
                        a, "Dynamic SQL analysed (static text)", d.line,
                        f"{d.form} {d.expression}"
                        + (f" - {d.variants} variants" if d.variants > 1 else ""),
                        "Findings from this text are labelled 'Dynamic SQL' and capped at "
                        "MEDIUM confidence."))
            if a.unresolved:
                rows.append(CoverageRow(
                    a, "Unresolved column references", a.unresolved[0].line,
                    f"{len(a.unresolved)} column reference(s) could not be tied to one table: "
                    + ", ".join(dict.fromkeys(u.ref.original or u.ref.column
                                              for u in a.unresolved[:10])),
                    "These columns are not used as index-candidate columns, and join checks "
                    "that depend on them are LOW confidence (manual review)."))
            for issue in a.issues:
                if issue.issue_type in (IssueType.MISSING_SP_DEFINITION, IssueType.INTERNAL_ERROR) \
                        and issue.severity != "INFO":
                    rows.append(CoverageRow(
                        a, issue.issue_type, issue.line, issue.description,
                        "Code not analysed here was not reviewed for performance."))
            if any(i.issue_type == "Duplicate Procedure" and i.severity == "WARNING"
                   for i in a.issues):
                rows.append(CoverageRow(
                    a, "Differing duplicate definitions", a.line,
                    f"Also defined in {', '.join(a.also_defined_in)} with different text.",
                    "Findings and candidates combine every version; confirm which one is "
                    "deployed."))
            if len(rows) == before:
                rows.append(CoverageRow(
                    a, "No coverage gaps", 0,
                    f"All {a.statements_total} statement(s) parsed; no runtime dynamic SQL; "
                    f"all columns resolved.",
                    "Static review complete. No finding does not mean no risk: data volumes, "
                    "parameter values and actual plans are not visible to static analysis."))
        if self.catalog is not None:
            for warning in self.catalog.warnings:
                rows.append(CoverageRow(None, "Schema definition warning", 0, warning,
                                        "That definition was not used for index comparison."))
        return rows

    # ------------------------------------------------------------ table records
    def table_supports(self) -> Dict[Tuple, List[Support]]:
        if self._by_table is not None:
            return self._by_table
        by_table: Dict[Tuple, List[Support]] = {}
        seen: Set[Tuple] = set()
        for a in self.analyses:
            for r in a.access_records:
                if r.table.object_type not in _INDEXABLE:
                    continue
                tkey = summary_key(r.table, self.sopts)
                # identical copies of a procedure and dynamic-SQL variants repeat records
                dedupe = (tkey, proc_key(a), _base_statement(r.statement_id),
                          _record_signature(r))
                if dedupe in seen:
                    continue
                seen.add(dedupe)
                by_table.setdefault(tkey, []).append(Support(a, r))
        self._by_table = by_table
        return by_table

    def table_display(self, obj: ObjectRef) -> str:
        schema = obj.schema or (self.sopts.default_schema
                                if self.sopts.merge_unqualified_with_default_schema else "")
        return ".".join(quote_ident(p) for p in (obj.database, schema, obj.name) if p)

    def table_def(self, obj: ObjectRef):
        if self.catalog is None:
            return None
        if not obj.schema and self.sopts.merge_unqualified_with_default_schema:
            obj = ObjectRef(obj.name, obj.object_type, self.sopts.default_schema, obj.database,
                            obj.server)
        return self.catalog.lookup(obj)

    # ------------------------------------------------------------ index candidates
    def index_candidates(self) -> List[IndexCandidate]:
        if self._candidates is not None:
            return self._candidates
        if not self.popts.rule_enabled("IDX-001"):
            self._candidates = []
            return self._candidates
        merged: Dict[Tuple, IndexCandidate] = {}
        for tkey, supports in self.table_supports().items():
            frequency: Dict[str, Set[Tuple]] = {}
            for s in supports:
                for col in s.record.columns_of(EQ, EQ_JOIN, IN_LIST):
                    frequency.setdefault(col.upper(), set()).add(
                        (proc_key(s.analysis), _base_statement(s.record.statement_id)))
            for s in supports:
                cand = self._candidate_from(tkey, s, frequency)
                if cand is None:
                    continue
                sig = (tkey, tuple(k.upper() for k in cand.keys), filter_key(cand.filter))
                existing = merged.get(sig)
                if existing is None:
                    merged[sig] = cand
                else:
                    existing.supports.extend(cand.supports)
                    _add(existing.wanted_includes, cand.wanted_includes)
                    _add(existing.reasons, cand.reasons)
        candidates = list(merged.values())
        for cand in candidates:
            self._cap_includes(cand)
        candidates.sort(key=lambda c: (c.table_display.upper(), [k.upper() for k in c.keys],
                                       c.filter))
        for idx, cand in enumerate(candidates, start=1):
            cand.candidate_id = f"IXC-{idx:03d}"
        self._overlaps(candidates)
        for cand in candidates:
            self._assess_existing(cand)
            self._describe(cand)
        self._candidates = candidates
        return candidates

    def _candidate_from(self, tkey, s: Support, frequency) -> Optional[IndexCandidate]:
        r = s.record
        if r.operation in ("INSERT", "TRUNCATE"):
            return None
        eq_preds = [p for p in r.predicates if p.kind in (EQ, EQ_JOIN, IN_LIST)]
        range_cols = r.columns_of(RANGE, PREFIX)
        constants = [p for p in r.predicates
                     if p.constant and p.op in ("=", "IS NULL", "IS NOT NULL")]
        eq_cols: List[str] = []
        _add(eq_cols, [p.column for p in eq_preds])
        filter_cols = {p.column.upper() for p in constants}
        filter_text = ""
        reasons: List[str] = []
        remaining_eq = [c for c in eq_cols if c.upper() not in filter_cols]
        remaining_range = [c for c in range_cols if c.upper() not in filter_cols]
        if constants and (remaining_eq or remaining_range):
            parts = []
            for p in sorted(constants, key=lambda p: p.column.upper()):
                text = f"{_q(p.column)} {p.op}" if p.op.startswith("IS ") \
                    else f"{_q(p.column)} = {p.value}"
                if text not in parts:
                    parts.append(text)
            filter_text = " AND ".join(parts)
            eq_cols = remaining_eq
            range_cols = remaining_range
            reasons.append(f"Constant predicate(s) {filter_text} in the supporting statement "
                           f"suggest a filtered index over just those rows (alternative: put "
                           f"the column(s) in the key).")
        eq_cols.sort(key=lambda c: (-len(frequency.get(c.upper(), ())), c.upper()))
        keys = list(eq_cols)
        if range_cols:
            _add(keys, range_cols[:1])
        elif keys and r.role == "read":
            ordering = r.order_by or r.group_by
            if ordering:
                before = len(keys)
                _add(keys, ordering)
                if len(keys) > before:
                    reasons.append(f"{'ORDER BY' if r.order_by else 'GROUP BY'} column(s) "
                                   f"{', '.join(keys[before:])} follow the equality columns so "
                                   f"rows can be read in order without a sort (applies only if "
                                   f"the statement orders/groups by these columns alone).")
        if not keys:
            return None
        if len(keys) > self.popts.max_key_columns:
            dropped = keys[self.popts.max_key_columns:]
            keys = keys[:self.popts.max_key_columns]
            reasons.append(f"Key limited to {self.popts.max_key_columns} columns; "
                           f"{', '.join(dropped)} moved to INCLUDE (residual filter).")
        else:
            dropped = []
        eq_count = sum(1 for k in keys if k.upper() in {c.upper() for c in eq_cols})
        wanted: List[str] = []
        if r.role == "read":
            if r.star:
                reasons.append("SELECT * reads every column, so no INCLUDE list can cover it; "
                               "key lookups (or a scan) remain.")
            else:
                _add(wanted, r.projected)
                _add(wanted, r.other_columns)
                _add(wanted, range_cols[1:])
                _add(wanted, r.columns_of(RESIDUAL, NONSARGABLE, OR_BRANCH))
                _add(wanted, r.order_by + r.group_by)
                _add(wanted, dropped)
        wanted = [c for c in wanted if c.upper() not in {k.upper() for k in keys}]
        if r.columns_of(NONSARGABLE):
            reasons.append(f"Not used as key: {', '.join(r.columns_of(NONSARGABLE))} "
                           f"(wrapped in a function or calculation - see PERF-P001).")
        if r.columns_of(OR_BRANCH):
            reasons.append(f"Not used as key: {', '.join(r.columns_of(OR_BRANCH))} "
                           f"(only inside OR branches, not a guaranteed filter).")
        if len(range_cols) > 1:
            reasons.append(f"Only the first range column is a key column; other range "
                           f"predicates ({', '.join(range_cols[1:])}) are residual filters.")
        if r.role == "read" and keys and not (r.columns_of(EQ, IN_LIST, RANGE, PREFIX)
                                              or filter_text):
            reasons.append("Join-only support: this statement does not filter the table, so "
                           "the index helps only when the table is the inner (probed) side of "
                           "a nested-loops join.")
        cand = IndexCandidate(tkey, r.table, self.table_display(r.table), keys, eq_count,
                              [], filter_text, [s], reasons, wanted_includes=wanted)
        if filter_text:
            _add(cand.filter_columns, [p.column for p in constants])
        return cand

    def _cap_includes(self, cand: IndexCandidate) -> None:
        if any(s.record.star for s in cand.supports if s.record.role == "read"):
            cand.includes = []
            cand.include_note = ("At least one supporting statement uses SELECT *; INCLUDE "
                                 "cannot cover it.")
            return
        if len(cand.wanted_includes) > self.popts.max_include_columns:
            cand.includes = []
            cand.include_note = (f"The supporting statements read {len(cand.wanted_includes)} "
                                 f"other columns ({', '.join(cand.wanted_includes)}), more than "
                                 f"the {self.popts.max_include_columns}-column INCLUDE limit; "
                                 f"proposed as key-only (key lookups expected).")
        else:
            cand.includes = list(cand.wanted_includes)

    def _overlaps(self, candidates: List[IndexCandidate]) -> None:
        by_table: Dict[Tuple, List[IndexCandidate]] = {}
        for cand in candidates:
            by_table.setdefault(cand.table_key, []).append(cand)
        for group in by_table.values():
            for a in group:
                notes = []
                ak = [k.upper() for k in a.keys]
                for b in group:
                    if a is b:
                        continue
                    bk = [k.upper() for k in b.keys]
                    same_filter = filter_key(a.filter) == filter_key(b.filter)
                    if same_filter and len(ak) < len(bk) and bk[:len(ak)] == ak:
                        notes.append(f"Left prefix of {b.candidate_id}: {b.candidate_id} could "
                                     f"serve these seeks if it also carried this candidate's "
                                     f"INCLUDE columns - consider consolidating.")
                    elif same_filter and len(bk) < len(ak) and ak[:len(bk)] == bk:
                        notes.append(f"Extends {b.candidate_id} (same leading keys).")
                    elif ak and bk and ak[0] == bk[0]:
                        notes.append(f"Shares leading key column {a.keys[0]} with "
                                     f"{b.candidate_id}" + ("" if same_filter
                                                            else " (different filter)") + ".")
                a.overlap = " ".join(notes) or "None among candidates."

    def _assess_existing(self, cand: IndexCandidate) -> None:
        table = self.table_def(cand.table)
        # the weakest supporting statement sets the candidate's confidence
        cand.confidence = Confidence.worst(*(s.record.confidence for s in cand.supports)) \
            if cand.supports else Confidence.LOW
        if self.catalog is None:
            cand.assessment = ASSESS_INSUFFICIENT
            cand.assessment_detail = ("Existing index definitions were not provided (no schema "
                                      "folder configured), so it is unknown whether an "
                                      "equivalent index already exists.")
            return
        if table is None or (not table.defined and not table.indexes):
            cand.assessment = ASSESS_INSUFFICIENT
            cand.assessment_detail = ("The schema folder has no definition for this table, so "
                                      "it is unknown whether an equivalent index exists.")
            return
        uncertain = cand.uncertain_supports
        if len(uncertain) == len(cand.supports):
            cand.assessment = ASSESS_INSUFFICIENT
            cand.assessment_detail = ("Column ownership in every supporting statement is "
                                      "uncertain (unresolved columns); confirm the access "
                                      "pattern before evaluating.")
            return
        clustered = table.clustered_index
        if clustered is not None and clustered.kind == "ROWSTORE" and cand.includes:
            carried = [c for c in cand.includes
                       if c.upper() in (k.upper() for k in clustered.keys)]
            if carried:
                cand.includes = [c for c in cand.includes if c not in carried]
                cand.include_note = (cand.include_note + " " if cand.include_note else "") + (
                    f"Clustered key column(s) {', '.join(carried)} are stored in every "
                    f"nonclustered index row already and were left out of INCLUDE.")
        if table.defined:
            missing = [c for c in cand.keys + cand.includes + cand.filter_columns
                       if table.column(c) is None]
            if missing:
                cand.assessment = ASSESS_INSUFFICIENT
                cand.assessment_detail = (f"Column(s) {', '.join(missing)} are not in the "
                                          f"provided definition of {table.display_name}; the "
                                          f"definition may be outdated or a column was "
                                          f"resolved to the wrong table.")
                return
            lob = [c for c in cand.keys if table.column(c).lob]
            if lob:
                cand.assessment = ASSESS_INSUFFICIENT
                cand.assessment_detail = (f"Column(s) {', '.join(lob)} have a LOB / (max) type "
                                          f"and cannot be index key columns.")
                return
        eq = {k.upper() for k in cand.keys[:cand.eq_count]}
        rest = [k.upper() for k in cand.keys[cand.eq_count:]]
        needed = {c.upper() for c in cand.keys + cand.includes}
        covered, overlaps = [], []
        for idx in table.indexes:
            ikeys = [k.upper() for k in idx.keys]
            if idx.kind == "COLUMNSTORE":
                overlaps.append(f"{idx.description}: columnstore index present - rowstore "
                                f"candidates need workload-specific review.")
                continue
            filter_ok = not idx.filter or filter_key(idx.filter) == filter_key(cand.filter)
            seek_ok = (set(ikeys[:len(eq)]) == eq
                       and ikeys[len(eq):len(eq) + len(rest)] == rest)
            if seek_ok and filter_ok:
                # an unfiltered index must also carry the candidate's filter columns
                need = needed | ({c.upper() for c in cand.filter_columns} if not idx.filter
                                 else set())
                available = set(ikeys) | {c.upper() for c in idx.includes}
                if clustered is not None and not idx.clustered:
                    available |= {k.upper() for k in clustered.keys}
                if idx.clustered or need <= available:
                    covered.append(idx.description)
                else:
                    missing = sorted(need - available)
                    overlaps.append(f"{idx.description} supports the same seek but lacks "
                                    f"{', '.join(missing)} (possible INCLUDE extension).")
            elif ikeys and cand.keys and (ikeys[0] in eq or ikeys[0] == cand.keys[0].upper()):
                note = "" if filter_ok else " (filtered differently)"
                overlaps.append(f"{idx.description} shares the leading key column{note}; a "
                                f"key or INCLUDE extension may be preferable to a new index.")
        if covered and uncertain:
            # never a confident coverage claim while some requirements are unknown
            cand.assessment = ASSESS_OVERLAP
            cand.assessment_detail = (
                f"Existing {'; '.join(covered)} covers the resolved columns, but "
                f"{len(uncertain)} of {len(cand.supports)} supporting statement(s) have "
                f"unresolved columns ({', '.join(sorted({u for s in uncertain for u in s.record.unresolved}))})"
                f" that may also need to be in the index - review those statements.")
        elif covered:
            cand.assessment = ASSESS_COVERED
            cand.assessment_detail = "Existing: " + "; ".join(covered)
        elif overlaps:
            cand.assessment = ASSESS_OVERLAP
            cand.assessment_detail = " ".join(overlaps)
        else:
            cand.assessment = ASSESS_CANDIDATE
            cand.assessment_detail = (f"None of the {len(table.indexes)} defined index(es) on "
                                      f"{table.display_name} has a matching leading key.")

    def _describe(self, cand: IndexCandidate) -> None:
        eq_cols = cand.keys[:cand.eq_count]
        rest = cand.keys[cand.eq_count:]
        parts: List[str] = []
        if len(eq_cols) == 1:
            parts.append(f"Equality / IN / join predicate on {eq_cols[0]} leads the key.")
        elif eq_cols:
            counts = []
            for col in eq_cols:
                n = len({(proc_key(s.analysis), _base_statement(s.record.statement_id))
                         for s in self.table_supports().get(cand.table_key, [])
                         if col.upper() in (c.upper() for c in s.record.columns_of(
                             EQ, EQ_JOIN, IN_LIST))})
                counts.append(f"{col}: {n}")
            parts.append(f"Equality / IN / join predicates on {', '.join(eq_cols)} lead the key: "
                         f"a seek can use all of them. Their order is a reasoned guess - the "
                         f"column used by more statements comes first ({'; '.join(counts)} "
                         f"statements); actual selectivity is unknown.")
        if rest:
            if any(r.upper() in (c.upper() for s in cand.supports
                                 for c in s.record.columns_of(RANGE, PREFIX)) for r in rest[:1]):
                parts.append(f"Range predicate on {rest[0]} follows the equality columns "
                             f"because a seek can use only one trailing range column.")
        if cand.includes:
            parts.append(f"INCLUDE ({', '.join(cand.includes)}) covers the other columns the "
                         f"supporting statements read, so key lookups can be avoided.")
        if cand.include_note:
            parts.append(cand.include_note)
        parts.extend(cand.reasons)
        writes = [s for s in cand.supports if s.record.role == "write"]
        if writes:
            parts.append(f"{len(writes)} supporting UPDATE/DELETE/MERGE statement(s) use these "
                         f"columns to locate rows.")
        parts.append(f"Supported by {cand.statement_count} statement(s) in "
                     f"{len(cand.procedures)} procedure(s); this counts code references, not "
                     f"how often the procedures run.")
        breakdown = cand.confidence_breakdown
        if len(breakdown) > 1 or cand.uncertain_supports:
            parts.append("Supporting-statement confidence: " + ", ".join(
                f"{level} {n}" for level, n in sorted(breakdown.items(),
                                                      key=lambda kv: Confidence.rank(kv[0])))
                         + "; the candidate takes the lowest. Unresolved columns are listed per "
                           "statement in Statement Evidence and are never used as key or "
                           "INCLUDE columns.")
        cand.reasoning = " ".join(parts)
        cand.tradeoffs = self._tradeoffs(cand)
        validation = [
            "Compare with existing indexes (sys.indexes / sys.index_columns) for duplicates and "
            "overlaps" + (" - existing definitions were not provided" if self.catalog is None
                          else "") + ".",
            "Check column selectivity and statistics to confirm the key order.",
            "Test with actual execution plans and the real workload (Query Store, "
            "sys.dm_db_index_usage_stats; missing-index DMVs only as corroboration).",
            "Measure the extra cost on INSERT / UPDATE / DELETE paths and the storage and "
            "maintenance impact.",
        ]
        if cand.filter:
            validation.append("A filtered index is used only when the query predicate matches "
                              "the filter as a constant (a parameter such as @Status does not "
                              "match) and requires the standard SET options "
                              "(ANSI_NULLS, QUOTED_IDENTIFIER ON ...).")
        if any(s.record.dynamic for s in cand.supports):
            validation.append("Part of the support comes from dynamic SQL; confirm the "
                              "statements actually executed.")
        cand.validation = " ".join(validation)
        cols = ", ".join(_q(k) for k in cand.keys)
        name = "IXC_" + cand.table.name + "_" + "_".join(cand.keys)
        name = "".join(ch if ch.isalnum() or ch == "_" else "_" for ch in name)[:110]
        table = ".".join(_q(p) for p in (cand.table.database, cand.table.schema
                                         or self.sopts.default_schema, cand.table.name) if p)
        ddl = f"CREATE NONCLUSTERED INDEX {_q(name)} ON {table} ({cols})"
        if cand.includes:
            ddl += f" INCLUDE ({', '.join(_q(c) for c in cand.includes)})"
        if cand.filter:
            ddl += f" WHERE {cand.filter}"
        cand.ddl = (f"-- REVIEW-ONLY CANDIDATE {cand.candidate_id}: generated by static analysis, "
                    f"never executed by this tool.\n-- Validate before any use.\n-- {ddl};")

    def _tradeoffs(self, cand: IndexCandidate) -> str:
        supports = self.table_supports().get(cand.table_key, [])
        writes: Dict[str, Set[Tuple]] = {}
        procs: Set[str] = set()
        updated_hits: List[str] = []
        loop_writes = 0
        cols = {c.upper() for c in cand.keys + cand.includes}
        for s in supports:
            r = s.record
            if r.role != "write":
                continue
            writes.setdefault(r.operation, set()).add(
                (proc_key(s.analysis), _base_statement(r.statement_id)))
            procs.add(proc_key(s.analysis))
            loop_writes += r.in_loop
            hit = [c for c in r.updated if c.upper() in cols]
            if hit:
                updated_hits.append(f"{', '.join(hit)} ({s.analysis.full_name} {r.statement_id})")
        parts = []
        if writes:
            ops = ", ".join(f"{op} {len(v)}" for op, v in sorted(writes.items()))
            parts.append(f"Write overhead: the table is modified by statements in {len(procs)} "
                         f"procedure(s) ({ops}); every INSERT and DELETE must also maintain this "
                         f"index.")
        else:
            parts.append("No modifying statement was found in the analysed procedures (other "
                         "code, jobs or applications may still write to the table).")
        if updated_hits:
            parts.append(f"UPDATEs change indexed column(s): {'; '.join(updated_hits[:6])} - "
                         f"each such update also updates this index.")
        if loop_writes:
            parts.append(f"{loop_writes} modifying statement(s) run inside loops, multiplying "
                         f"the maintenance cost.")
        table = self.table_def(cand.table)
        width = None
        if table is not None and table.defined:
            sizes = [table.column(c).max_bytes if table.column(c) else None
                     for c in cand.keys + cand.includes]
            if sizes and all(v is not None for v in sizes):
                width = sum(sizes)
            key_sizes = [table.column(c).max_bytes if table.column(c) else None
                         for c in cand.keys]
            if key_sizes and all(v is not None for v in key_sizes) and sum(key_sizes) > 1700:
                parts.append(f"Declared key width {sum(key_sizes)} bytes exceeds the 1700-byte "
                             f"nonclustered key limit.")
        if width is not None:
            parts.append(f"Storage: up to about {width} bytes per row for key + INCLUDE columns "
                         f"(declared maximum), plus the row locator and overhead.")
        else:
            parts.append("Storage: one entry per row (filtered: per qualifying row); size "
                         "unknown without column types and row counts.")
        return " ".join(parts)

    # ------------------------------------------------------------ partitioning
    def partition_assessments(self) -> List[PartitionAssessment]:
        if self._partitions is not None:
            return self._partitions
        out: List[PartitionAssessment] = []
        if not self.popts.rule_enabled("PART-001"):
            self._partitions = out
            return out
        for tkey, supports in self.table_supports().items():
            reads = [s for s in supports if s.record.operation not in ("INSERT", "TRUNCATE")]
            if not reads:
                continue
            statements = {(proc_key(s.analysis), _base_statement(s.record.statement_id))
                          for s in reads}
            ranges: Dict[str, Dict] = {}
            for s in reads:
                skey = (proc_key(s.analysis), _base_statement(s.record.statement_id))
                for p in s.record.predicates:
                    if p.kind not in (RANGE, NONSARGABLE):
                        continue
                    entry = ranges.setdefault(p.column.upper(), {
                        "name": p.column, "stmts": set(), "archival": set(), "nonsarg": set(),
                        "supports": []})
                    if p.kind == NONSARGABLE:
                        entry["nonsarg"].add(skey)
                        continue
                    entry["stmts"].add(skey)
                    if s.record.operation == "DELETE":
                        entry["archival"].add(skey)
                    if not any(x is s for x in entry["supports"]):
                        entry["supports"].append(s)
            triggered = [e for e in ranges.values()
                         if e["archival"] or (
                             len(e["stmts"]) >= self.popts.partition_min_range_statements
                             and len(e["stmts"]) / len(statements) >= self.popts.partition_min_share)]
            if not triggered:
                continue
            best = max(triggered, key=lambda e: (len(e["archival"]), len(e["stmts"]),
                                                 e["name"].upper()))
            out.append(self._assess_partition(tkey, best, reads, statements,
                                              [e for e in triggered if e is not best]))
        out.sort(key=lambda p: p.table_display.upper())
        self._partitions = out
        return out

    def _assess_partition(self, tkey, entry, reads: List[Support], statements: Set[Tuple],
                          others) -> PartitionAssessment:
        obj = reads[0].record.table
        display = self.table_display(obj)
        col = entry["name"]
        table = self.table_def(obj)
        meta = table.metadata if table is not None else {}
        n_range, n_arch, total = len(entry["stmts"]), len(entry["archival"]), len(statements)
        pattern = []
        if n_range:
            pattern.append(f"Range predicates on {col} in {n_range} of {total} statement(s) that "
                           f"read, update or delete this table")
        if n_arch:
            pattern.append(f"{n_arch} date/range-bounded DELETE statement(s) on {col} "
                           f"(archival / purge pattern)")
        if entry["nonsarg"]:
            pattern.append(f"{len(entry['nonsarg'])} statement(s) filter {col} through a "
                           f"function")
        if others:
            pattern.append("other range columns: " + ", ".join(e["name"] for e in others))

        available, missing = [], []

        def fact(label: str, value: str) -> None:
            if value:
                available.append(f"{label}: {value}")
            else:
                missing.append(label)

        size = ", ".join(v for v in (f"{meta['row_count']} rows" if meta.get("row_count") else "",
                                     f"{meta['data_size_mb']} MB" if meta.get("data_size_mb") else "")
                         if v)
        fact("table size", size)
        fact("row distribution", meta.get("row_distribution", ""))
        fact("growth", meta.get("growth", ""))
        fact("retention policy", meta.get("retention_policy", ""))
        partitioning = ""
        if table is not None and table.partition_column:
            partitioning = f"partitioned on {table.partition_column} ({table.partition_scheme})"
        elif meta.get("partitioning"):
            partitioning = meta["partitioning"]
        elif table is not None and table.defined:
            partitioning = "not partitioned (per provided CREATE TABLE)"
        fact("existing partitioning", partitioning)
        keys = ""
        if table is not None and table.defined:
            uniques = [i for i in table.indexes if i.unique]
            keys = "; ".join(i.description for i in uniques) or "no PRIMARY KEY / UNIQUE defined"
        fact("key constraints", keys)
        if table is not None and table.column(col) is not None:
            available.append(f"{col} type: {table.column(col).type_text}")

        if missing:
            assessment = INSUFFICIENT_PARTITION
        elif table is not None and table.partition_column:
            if table.partition_column.upper() == col.upper():
                assessment = (f"Already partitioned on {col}: review partition elimination for "
                              f"the listed statements; no new recommendation.")
            else:
                assessment = (f"Partitioned on {table.partition_column}, while observed range "
                              f"filtering uses {col}: review whether the partition column fits "
                              f"the workload.")
        else:
            assessment = ("Partitioning review justified by the observed usage and the supplied "
                          "facts. Boundaries, alignment and benefit must be established by "
                          "testing; no boundaries are proposed.")

        benefit = []
        if n_arch:
            benefit.append(f"Maintenance: the {n_arch} bounded DELETE(s) on {col} could become "
                           f"partition SWITCH OUT / TRUNCATE ... WITH (PARTITIONS ...) operations "
                           f"instead of large logged deletes, and index maintenance / statistics "
                           f"can run per partition.")
        if n_range:
            benefit.append(f"Query: range predicates on {col} may allow partition elimination, "
                           f"so a query reads only the partitions in its range - only when the "
                           f"predicate is SARGable on {col}. A suitable index on {col} often "
                           f"gives similar read benefits; partitioning is mainly a manageability "
                           f"feature and does not guarantee faster queries.")

        considerations = []
        without = [s for s in reads
                   if col.upper() not in (p.column.upper() for p in s.record.predicates
                                          if p.kind in (RANGE, EQ, IN_LIST, EQ_JOIN,
                                                        NONSARGABLE))]
        without_keys = {(proc_key(s.analysis), _base_statement(s.record.statement_id))
                        for s in without}
        if without_keys:
            sample = "; ".join(dict.fromkeys(f"{s.analysis.full_name} {s.record.statement_id}"
                                             for s in without[:5]))
            considerations.append(f"{len(without_keys)} of {total} statement(s) have no "
                                  f"predicate on {col} and would touch every partition "
                                  f"(e.g. {sample}).")
        if entry["nonsarg"]:
            considerations.append(f"{len(entry['nonsarg'])} statement(s) wrap {col} in a "
                                  f"function; they get no partition elimination unless "
                                  f"rewritten (see PERF-P001).")
        if table is not None and table.defined:
            not_aligned = [i.name for i in table.indexes
                           if i.unique and col.upper() not in (k.upper() for k in i.keys)]
            if not_aligned:
                considerations.append(f"Unique index / constraint(s) {', '.join(not_aligned)} do "
                                      f"not include {col}: to be partition-aligned they must "
                                      f"include it (changing what is enforced as unique), or "
                                      f"stay non-aligned, which blocks partition SWITCH.")
        else:
            considerations.append("Key constraints unknown: unique indexes must include the "
                                  "partition column to be aligned.")
        considerations.append("Keep nonclustered indexes aligned with the partition scheme so "
                              "partition switching stays possible; queries that span many "
                              "partitions can be slower than on a non-partitioned table.")
        evidence = "\n".join(s.label for s in entry["supports"][:15])
        if len(entry["supports"]) > 15:
            evidence += f"\n... and {len(entry['supports']) - 15} more"
        procs: Dict[str, ProcedureAnalysis] = {}
        for s in entry["supports"]:
            procs.setdefault(proc_key(s.analysis), s.analysis)
        return PartitionAssessment(
            table_display=display, column=col, pattern="; ".join(pattern) + ".",
            procedures=sorted(procs.values(), key=lambda a: a.full_name.upper()),
            available="; ".join(available) or "None",
            missing=", ".join(missing) or "None",
            benefit=" ".join(benefit), assessment=assessment,
            considerations=" ".join(considerations), evidence=evidence)

    # ------------------------------------------------------------ rule catalogue
    def rule_rows(self) -> List[Sequence]:
        return [(r.rule_id, r.name, r.scope, r.default_severity,
                 "Yes" if self.popts.rule_enabled(r.rule_id) else "No", r.description)
                for r in RULES.values()]
