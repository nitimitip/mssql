/*
================================================================================
 02_table_metadata_csv.sql  -  build input/schema/table_metadata.csv
================================================================================
 READ-ONLY. Produces one column (csv_line) whose rows ARE the CSV file the
 analyzer reads for its Partitioning Review and index sizing.

 HOW TO RUN
   1. Change the USE line, Results to Grid, Execute.
   2. Click the csv_line column header (selects all rows), Ctrl+C.
   3. Paste into Notepad and save as
        <analyzer>\input\schema\table_metadata.csv   (Encoding: UTF-8)
   4. Optional: fill in the blank columns by hand for your biggest tables
        row_distribution  e.g. "about 2M rows per month"
        growth            e.g. "+2M rows per month"
        retention_policy  e.g. "7 years then purge"
      A blank value means "unknown" to the analyzer.
================================================================================
*/

USE [YourAppDatabase];   -- <<< CHANGE THIS
GO

SET NOCOUNT ON;

WITH sizes AS (
    SELECT ps.object_id,
           SUM(CASE WHEN ps.index_id IN (0, 1) THEN ps.row_count ELSE 0 END)          AS row_count,
           SUM(CASE WHEN ps.index_id IN (0, 1) THEN ps.reserved_page_count ELSE 0 END) AS data_pages,
           SUM(ps.reserved_page_count)                                                AS total_pages
    FROM sys.dm_db_partition_stats AS ps
    GROUP BY ps.object_id
), part AS (
    SELECT i.object_id,
           psch.name                                                AS scheme_name,
           c.name                                                   AS column_name,
           (SELECT COUNT(*) FROM sys.partitions AS p
             WHERE p.object_id = i.object_id AND p.index_id = i.index_id) AS partition_count
    FROM sys.indexes AS i
    JOIN sys.partition_schemes AS psch ON psch.data_space_id = i.data_space_id
    JOIN sys.index_columns AS ic
         ON ic.object_id = i.object_id AND ic.index_id = i.index_id AND ic.partition_ordinal = 1
    JOIN sys.columns AS c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
    WHERE i.index_id IN (0, 1)
), rows_out AS (
    SELECT s.name + '.' + t.name                                                    AS tbl,
           sz.row_count,
           CAST(sz.data_pages * 8 / 1024.0 AS decimal(18,1))                        AS data_size_mb,
           CASE WHEN pt.object_id IS NULL THEN 'none'
                ELSE 'partitioned on ' + pt.scheme_name + '(' + pt.column_name + ') '
                     + CAST(pt.partition_count AS varchar(10)) + ' partitions' END   AS partitioning,
           'total incl. indexes ' + CAST(CAST(sz.total_pages * 8 / 1024.0 AS decimal(18,1)) AS varchar(30))
               + ' MB'                                                              AS notes
    FROM sys.tables AS t
    JOIN sys.schemas AS s ON s.schema_id = t.schema_id
    JOIN sizes AS sz ON sz.object_id = t.object_id
    LEFT JOIN part AS pt ON pt.object_id = t.object_id
    WHERE t.is_ms_shipped = 0
)
SELECT csv_line
FROM (
    SELECT 0 AS sort_group, CAST(0 AS bigint) AS sort_rows,
           'table,row_count,data_size_mb,row_distribution,growth,retention_policy,partitioning,notes' AS csv_line
    UNION ALL
    SELECT 1, r.row_count,
           '"' + REPLACE(r.tbl, '"', '""') + '",'
           + CAST(r.row_count AS varchar(20)) + ','
           + CAST(r.data_size_mb AS varchar(30)) + ',,,,'
           + '"' + REPLACE(r.partitioning, '"', '""') + '",'
           + '"' + r.notes + '"'
    FROM rows_out AS r
) AS x
ORDER BY sort_group, sort_rows DESC;
