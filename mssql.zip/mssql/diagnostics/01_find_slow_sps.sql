/*
================================================================================
 01_find_slow_sps.sql  -  find the real culprits (SQL Server 2022)
================================================================================
 READ-ONLY. This script only SELECTs from system views (DMVs, Query Store,
 catalog views). It does not create, change, clear or execute anything.

 HOW TO RUN
   1. Open in SSMS, connected to the SQL instance / AG listener the .NET app
      uses. If the cluster is an Availability Group, run it on the PRIMARY
      replica (that is where the app's writes and most reads run).
   2. Change the USE line below to the application database.
   3. Results to Grid (Ctrl+D), then Execute (F5).
   4. Every result set starts with a "section" column so you can tell them
      apart. Right-click a grid > "Save Results As..." to keep a copy.
   5. Best run WHILE the application is slow (sections 5-6 show live state).

 PERMISSIONS
   VIEW SERVER PERFORMANCE STATE (or VIEW SERVER STATE) and
   VIEW DATABASE PERFORMANCE STATE (or VIEW DATABASE STATE) on the app DB.

 IMPORTANT
   - DMV numbers (sections 1, 2, 4, 7, 8, 11) are cumulative since the SQL
     service last started, or since the plan was cached. Section 0 shows the
     start time. Query Store (section 3) keeps history across restarts.
   - "Missing index" suggestions are hints for review, never create them
     blindly.
================================================================================
*/

USE [YourAppDatabase];   -- <<< CHANGE THIS
GO

SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

DECLARE @TopN         int = 25;   -- rows per result set
DECLARE @Days         int = 7;    -- Query Store look-back window
DECLARE @IncludePlans bit = 1;    -- 1 = return cached plans (click to open in SSMS)
DECLARE @Since datetimeoffset = DATEADD(day, -@Days, SYSDATETIMEOFFSET());

/* ---------------------------------------------------------------------------
 0. Server and database context
--------------------------------------------------------------------------- */
SELECT '0a server' AS section,
       @@SERVERNAME                                AS server_name,
       SERVERPROPERTY('ProductVersion')            AS product_version,
       SERVERPROPERTY('ProductUpdateLevel')        AS cumulative_update,
       SERVERPROPERTY('Edition')                   AS edition,
       SERVERPROPERTY('IsHadrEnabled')             AS is_ag_enabled,
       SERVERPROPERTY('IsClustered')               AS is_failover_cluster,
       si.sqlserver_start_time,
       DATEDIFF(hour, si.sqlserver_start_time, SYSDATETIME()) AS hours_since_start,
       si.cpu_count,
       CAST(si.physical_memory_kb / 1024.0 / 1024 AS decimal(10,1)) AS server_memory_gb
FROM sys.dm_os_sys_info AS si;

SELECT '0b server settings' AS section, c.name, c.value_in_use
FROM sys.configurations AS c
WHERE c.name IN ('max server memory (MB)', 'min server memory (MB)',
                 'max degree of parallelism', 'cost threshold for parallelism',
                 'optimize for ad hoc workloads')
ORDER BY c.name;

SELECT '0c database settings' AS section,
       d.name, d.compatibility_level, d.recovery_model_desc,
       d.is_read_committed_snapshot_on, d.snapshot_isolation_state_desc,
       d.is_auto_create_stats_on, d.is_auto_update_stats_on,
       d.is_auto_update_stats_async_on, d.is_query_store_on,
       d.is_parameterization_forced, d.page_verify_option_desc
FROM sys.databases AS d
WHERE d.database_id = DB_ID();

SELECT '0d database scoped config' AS section, dsc.name, dsc.value
FROM sys.database_scoped_configurations AS dsc
WHERE dsc.name IN ('MAXDOP', 'LEGACY_CARDINALITY_ESTIMATION',
                   'PARAMETER_SNIFFING', 'QUERY_OPTIMIZER_HOTFIXES',
                   'PARAMETER_SENSITIVE_PLAN_OPTIMIZATION',
                   'BATCH_MODE_ON_ROWSTORE', 'DOP_FEEDBACK',
                   'CE_FEEDBACK', 'MEMORY_GRANT_FEEDBACK_PERCENTILE_GRANT')
ORDER BY dsc.name;

SELECT '0e memory counters' AS section,
       RTRIM(pc.object_name) AS object_name, RTRIM(pc.counter_name) AS counter_name,
       pc.cntr_value
FROM sys.dm_os_performance_counters AS pc
WHERE (pc.object_name LIKE '%Buffer Manager%'  AND pc.counter_name = 'Page life expectancy')
   OR (pc.object_name LIKE '%Memory Manager%'  AND pc.counter_name IN
          ('Memory Grants Pending', 'Memory Grants Outstanding',
           'Target Server Memory (KB)', 'Total Server Memory (KB)'))
   OR (pc.object_name LIKE '%General Statistics%' AND pc.counter_name = 'User Connections');

/* ---------------------------------------------------------------------------
 1. Slowest stored procedures (plan cache, since each plan was cached)
    - total_elapsed_ms : overall load the SP puts on the server
    - avg_elapsed_ms   : what one call costs the user
    - avg_wait_ms      : elapsed minus CPU = time spent waiting
                         (blocking, disk I/O, memory, network to the app)
    - max >> avg       : unstable plans, usually parameter sniffing
--------------------------------------------------------------------------- */
SELECT TOP (@TopN)
       '1a top SPs by TOTAL time' AS section,
       OBJECT_SCHEMA_NAME(ps.object_id, ps.database_id) + '.' +
           OBJECT_NAME(ps.object_id, ps.database_id)                          AS procedure_name,
       ps.execution_count,
       CAST(ps.total_elapsed_time / 1000.0 AS decimal(18,1))                  AS total_elapsed_ms,
       CAST(ps.total_elapsed_time / 1000.0 / ps.execution_count AS decimal(18,1)) AS avg_elapsed_ms,
       CAST(ps.total_worker_time  / 1000.0 / ps.execution_count AS decimal(18,1)) AS avg_cpu_ms,
       CAST((ps.total_elapsed_time - ps.total_worker_time) / 1000.0
            / ps.execution_count AS decimal(18,1))                            AS avg_wait_ms,
       CAST(ps.min_elapsed_time / 1000.0 AS decimal(18,1))                    AS min_elapsed_ms,
       CAST(ps.max_elapsed_time / 1000.0 AS decimal(18,1))                    AS max_elapsed_ms,
       ps.total_logical_reads  / ps.execution_count                           AS avg_logical_reads,
       ps.total_physical_reads / ps.execution_count                           AS avg_physical_reads,
       ps.total_logical_writes / ps.execution_count                           AS avg_logical_writes,
       CAST(ps.execution_count * 60.0 /
            NULLIF(DATEDIFF(second, ps.cached_time, ps.last_execution_time), 0)
            AS decimal(18,1))                                                 AS calls_per_minute,
       ps.cached_time,
       ps.last_execution_time
FROM sys.dm_exec_procedure_stats AS ps
WHERE ps.database_id = DB_ID()
ORDER BY ps.total_elapsed_time DESC;

SELECT TOP (@TopN)
       '1b top SPs by AVERAGE time (>= 5 calls)' AS section,
       OBJECT_SCHEMA_NAME(ps.object_id, ps.database_id) + '.' +
           OBJECT_NAME(ps.object_id, ps.database_id)                          AS procedure_name,
       ps.execution_count,
       CAST(ps.total_elapsed_time / 1000.0 / ps.execution_count AS decimal(18,1)) AS avg_elapsed_ms,
       CAST(ps.total_worker_time  / 1000.0 / ps.execution_count AS decimal(18,1)) AS avg_cpu_ms,
       CAST((ps.total_elapsed_time - ps.total_worker_time) / 1000.0
            / ps.execution_count AS decimal(18,1))                            AS avg_wait_ms,
       CAST(ps.max_elapsed_time / 1000.0 AS decimal(18,1))                    AS max_elapsed_ms,
       ps.total_logical_reads / ps.execution_count                            AS avg_logical_reads,
       ps.last_execution_time
FROM sys.dm_exec_procedure_stats AS ps
WHERE ps.database_id = DB_ID()
  AND ps.execution_count >= 5
ORDER BY ps.total_elapsed_time / ps.execution_count DESC;

/* ---------------------------------------------------------------------------
 2. Slowest STATEMENTS inside procedures (which line of the SP is slow)
    Click query_plan to open the graphical plan in SSMS.
--------------------------------------------------------------------------- */
SELECT TOP (@TopN)
       '2 top statements inside SPs' AS section,
       OBJECT_SCHEMA_NAME(st.objectid, st.dbid) + '.' +
           OBJECT_NAME(st.objectid, st.dbid)                                  AS procedure_name,
       qs.execution_count,
       CAST(qs.total_elapsed_time / 1000.0 AS decimal(18,1))                  AS total_elapsed_ms,
       CAST(qs.total_elapsed_time / 1000.0 / qs.execution_count AS decimal(18,1)) AS avg_elapsed_ms,
       CAST(qs.total_worker_time  / 1000.0 / qs.execution_count AS decimal(18,1)) AS avg_cpu_ms,
       qs.total_logical_reads / qs.execution_count                            AS avg_logical_reads,
       qs.total_rows / qs.execution_count                                     AS avg_rows,
       CAST(qs.max_elapsed_time / 1000.0 AS decimal(18,1))                    AS max_elapsed_ms,
       qs.total_spills / qs.execution_count                                   AS avg_tempdb_spill_pages,
       CAST(qs.total_grant_kb / 1024.0 / qs.execution_count AS decimal(18,1))  AS avg_memory_grant_mb,
       SUBSTRING(st.text, (qs.statement_start_offset / 2) + 1,
                 ((CASE qs.statement_end_offset WHEN -1 THEN DATALENGTH(st.text)
                   ELSE qs.statement_end_offset END - qs.statement_start_offset) / 2) + 1)
                                                                              AS statement_text,
       qp.query_plan
FROM sys.dm_exec_query_stats AS qs
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS st
OUTER APPLY (SELECT p.query_plan
             FROM sys.dm_exec_query_plan(qs.plan_handle) AS p
             WHERE @IncludePlans = 1) AS qp
WHERE st.dbid = DB_ID()
  AND st.objectid IS NOT NULL
ORDER BY qs.total_elapsed_time DESC;

/* ---------------------------------------------------------------------------
 3. Query Store (history across restarts, last @Days days)
--------------------------------------------------------------------------- */
SELECT '3a query store state' AS section,
       o.actual_state_desc, o.desired_state_desc, o.readonly_reason,
       o.current_storage_size_mb, o.max_storage_size_mb,
       o.query_capture_mode_desc, o.interval_length_minutes,
       o.stale_query_threshold_days, o.wait_stats_capture_mode_desc
FROM sys.database_query_store_options AS o;
-- If actual_state_desc is OFF, sections 3b-3e return nothing; use 1-2 instead.

SELECT TOP (@TopN)
       '3b QS top SPs by total duration' AS section,
       OBJECT_SCHEMA_NAME(q.object_id) + '.' + OBJECT_NAME(q.object_id)        AS procedure_name,
       SUM(rs.count_executions)                                               AS executions,
       CAST(SUM(rs.avg_duration * rs.count_executions) / 1000.0 AS decimal(18,1)) AS total_duration_ms,
       CAST(SUM(rs.avg_duration * rs.count_executions) / 1000.0
            / NULLIF(SUM(rs.count_executions), 0) AS decimal(18,1))           AS avg_duration_ms,
       CAST(MAX(rs.max_duration) / 1000.0 AS decimal(18,1))                   AS max_duration_ms,
       CAST(SUM(rs.avg_cpu_time * rs.count_executions) / 1000.0
            / NULLIF(SUM(rs.count_executions), 0) AS decimal(18,1))           AS avg_cpu_ms,
       CAST(SUM(rs.avg_logical_io_reads * rs.count_executions)
            / NULLIF(SUM(rs.count_executions), 0) AS decimal(18,0))           AS avg_logical_reads,
       COUNT(DISTINCT q.query_id)                                             AS statements,
       COUNT(DISTINCT p.plan_id)                                              AS plans
FROM sys.query_store_runtime_stats AS rs
JOIN sys.query_store_runtime_stats_interval AS i
     ON i.runtime_stats_interval_id = rs.runtime_stats_interval_id
JOIN sys.query_store_plan  AS p ON p.plan_id  = rs.plan_id
JOIN sys.query_store_query AS q ON q.query_id = p.query_id
WHERE q.object_id > 0
  AND i.start_time >= @Since
GROUP BY q.object_id
ORDER BY total_duration_ms DESC;

-- What each SP waits on. Key categories:
--   Lock         = blocked by other sessions (transactions too long / missing index)
--   Buffer IO    = reading from disk (scans of big tables, too little memory)
--   CPU          = heavy computation (scans, sorts, hash joins, bad plans)
--   Memory       = waiting for a memory grant (large sorts/hashes)
--   Network IO   = SQL waits for the .NET APP to consume the rows
--                  (big result sets, or row-by-row processing in C#)
--   Replication  = Availability Group synchronous commit latency
SELECT TOP (@TopN * 2)
       '3c QS waits per SP' AS section,
       OBJECT_SCHEMA_NAME(q.object_id) + '.' + OBJECT_NAME(q.object_id)        AS procedure_name,
       ws.wait_category_desc,
       CAST(SUM(ws.total_query_wait_time_ms) AS decimal(18,0))                AS total_wait_ms
FROM sys.query_store_wait_stats AS ws
JOIN sys.query_store_runtime_stats_interval AS i
     ON i.runtime_stats_interval_id = ws.runtime_stats_interval_id
JOIN sys.query_store_plan  AS p ON p.plan_id  = ws.plan_id
JOIN sys.query_store_query AS q ON q.query_id = p.query_id
WHERE q.object_id > 0
  AND i.start_time >= @Since
GROUP BY q.object_id, ws.wait_category_desc
ORDER BY total_wait_ms DESC;

-- Statements with unstable performance: several plans, or the worst run far
-- slower than the average. Typical cause: parameter sniffing or stale stats.
WITH per_plan AS (
    SELECT p.query_id, p.plan_id,
           SUM(rs.count_executions)                                         AS executions,
           SUM(rs.avg_duration * rs.count_executions)
               / NULLIF(SUM(rs.count_executions), 0)                        AS avg_us,
           MAX(rs.max_duration)                                             AS max_us
    FROM sys.query_store_runtime_stats AS rs
    JOIN sys.query_store_runtime_stats_interval AS i
         ON i.runtime_stats_interval_id = rs.runtime_stats_interval_id
    JOIN sys.query_store_plan AS p ON p.plan_id = rs.plan_id
    WHERE i.start_time >= @Since
    GROUP BY p.query_id, p.plan_id
), per_query AS (
    SELECT query_id,
           COUNT(*)                                                         AS plan_count,
           SUM(executions)                                                  AS executions,
           SUM(avg_us * executions) / NULLIF(SUM(executions), 0)            AS avg_us,
           MIN(avg_us)                                                      AS best_plan_avg_us,
           MAX(avg_us)                                                      AS worst_plan_avg_us,
           MAX(max_us)                                                      AS max_us
    FROM per_plan
    GROUP BY query_id
    HAVING SUM(executions) >= 10
)
SELECT TOP (@TopN)
       '3d QS unstable statements' AS section,
       OBJECT_SCHEMA_NAME(q.object_id) + '.' + OBJECT_NAME(q.object_id)        AS procedure_name,
       pq.query_id,
       pq.plan_count,
       pq.executions,
       CAST(pq.avg_us            / 1000.0 AS decimal(18,1))                   AS avg_ms,
       CAST(pq.best_plan_avg_us  / 1000.0 AS decimal(18,1))                   AS best_plan_avg_ms,
       CAST(pq.worst_plan_avg_us / 1000.0 AS decimal(18,1))                   AS worst_plan_avg_ms,
       CAST(pq.max_us            / 1000.0 AS decimal(18,1))                   AS max_ms,
       CAST(pq.max_us / NULLIF(pq.avg_us, 0) AS decimal(18,1))                AS max_vs_avg_ratio,
       LEFT(qt.query_sql_text, 4000)                                          AS statement_text
FROM per_query AS pq
JOIN sys.query_store_query      AS q  ON q.query_id = pq.query_id
JOIN sys.query_store_query_text AS qt ON qt.query_text_id = q.query_text_id
WHERE q.object_id > 0
ORDER BY CASE WHEN pq.plan_count > 1 THEN 0 ELSE 1 END,
         pq.max_us / NULLIF(pq.avg_us, 0) * pq.executions DESC;

-- Top statements inside SPs by total duration, with the Query Store plan.
WITH stmt AS (
    SELECT p.query_id,
           SUM(rs.count_executions)                                         AS executions,
           SUM(rs.avg_duration * rs.count_executions)                       AS total_us,
           SUM(rs.avg_logical_io_reads * rs.count_executions)               AS total_reads,
           MAX(p.plan_id)                                                   AS latest_plan_id
    FROM sys.query_store_runtime_stats AS rs
    JOIN sys.query_store_runtime_stats_interval AS i
         ON i.runtime_stats_interval_id = rs.runtime_stats_interval_id
    JOIN sys.query_store_plan AS p ON p.plan_id = rs.plan_id
    WHERE i.start_time >= @Since
    GROUP BY p.query_id
)
SELECT TOP (@TopN)
       '3e QS top statements inside SPs' AS section,
       OBJECT_SCHEMA_NAME(q.object_id) + '.' + OBJECT_NAME(q.object_id)        AS procedure_name,
       s.query_id,
       s.executions,
       CAST(s.total_us / 1000.0 AS decimal(18,1))                             AS total_duration_ms,
       CAST(s.total_us / 1000.0 / NULLIF(s.executions, 0) AS decimal(18,1))    AS avg_duration_ms,
       CAST(s.total_reads / NULLIF(s.executions, 0) AS decimal(18,0))          AS avg_logical_reads,
       LEFT(qt.query_sql_text, 4000)                                          AS statement_text,
       CASE WHEN @IncludePlans = 1
            THEN TRY_CAST(pl.query_plan AS xml) END                           AS query_plan
FROM stmt AS s
JOIN sys.query_store_query      AS q  ON q.query_id = s.query_id
JOIN sys.query_store_query_text AS qt ON qt.query_text_id = q.query_text_id
JOIN sys.query_store_plan       AS pl ON pl.plan_id = s.latest_plan_id
WHERE q.object_id > 0
ORDER BY s.total_us DESC;

/* ---------------------------------------------------------------------------
 4. Server-wide waits (what SQL Server spends its time waiting on)
    Common meanings:
      LCK_M_*              blocking
      PAGEIOLATCH_*        reading data from disk
      WRITELOG             transaction log writes slow
      HADR_SYNC_COMMIT     AG synchronous replica slowing every commit
      CXPACKET / CXCONSUMER parallelism (often big scans)
      SOS_SCHEDULER_YIELD  CPU pressure
      RESOURCE_SEMAPHORE   queries waiting for memory grants
      ASYNC_NETWORK_IO     the .NET app reads results slowly
--------------------------------------------------------------------------- */
WITH w AS (
    SELECT ws.wait_type, ws.wait_time_ms, ws.signal_wait_time_ms, ws.waiting_tasks_count
    FROM sys.dm_os_wait_stats AS ws
    WHERE ws.waiting_tasks_count > 0
      AND ws.wait_type NOT IN (
        'BROKER_EVENTHANDLER','BROKER_RECEIVE_WAITFOR','BROKER_TASK_STOP','BROKER_TO_FLUSH',
        'BROKER_TRANSMITTER','CHECKPOINT_QUEUE','CHKPT','CLR_AUTO_EVENT','CLR_MANUAL_EVENT',
        'CLR_SEMAPHORE','DBMIRROR_DBM_EVENT','DBMIRROR_EVENTS_QUEUE','DBMIRROR_WORKER_QUEUE',
        'DBMIRRORING_CMD','DIRTY_PAGE_POLL','DISPATCHER_QUEUE_SEMAPHORE','EXECSYNC',
        'FSAGENT','FT_IFTS_SCHEDULER_IDLE_WAIT','FT_IFTSHC_MUTEX',
        'HADR_CLUSAPI_CALL','HADR_FILESTREAM_IOMGR_IOCOMPLETION','HADR_LOGCAPTURE_WAIT',
        'HADR_NOTIFICATION_DEQUEUE','HADR_TIMER_TASK','HADR_WORK_QUEUE',
        'KSOURCE_WAKEUP','LAZYWRITER_SLEEP','LOGMGR_QUEUE','MEMORY_ALLOCATION_EXT',
        'ONDEMAND_TASK_QUEUE','PARALLEL_REDO_DRAIN_WORKER','PARALLEL_REDO_LOG_CACHE',
        'PARALLEL_REDO_TRAN_LIST','PARALLEL_REDO_WORKER_SYNC','PARALLEL_REDO_WORKER_WAIT_WORK',
        'PREEMPTIVE_OS_FLUSHFILEBUFFERS','PREEMPTIVE_XE_GETTARGETSTATE',
        'PVS_PREALLOCATE','PWAIT_ALL_COMPONENTS_INITIALIZED','PWAIT_DIRECTLOGCONSUMER_GETNEXT',
        'PWAIT_EXTENSIBILITY_CLEANUP_TASK',
        'QDS_ASYNC_QUEUE','QDS_CLEANUP_STALE_QUERIES_TASK_MAIN_LOOP_SLEEP',
        'QDS_PERSIST_TASK_MAIN_LOOP_SLEEP','QDS_SHUTDOWN_QUEUE',
        'REDO_THREAD_PENDING_WORK','REQUEST_FOR_DEADLOCK_SEARCH','RESOURCE_QUEUE',
        'SERVER_IDLE_CHECK','SLEEP_BPOOL_FLUSH','SLEEP_DBSTARTUP','SLEEP_DCOMSTARTUP',
        'SLEEP_MASTERDBREADY','SLEEP_MASTERMDREADY','SLEEP_MASTERUPGRADED','SLEEP_MSDBSTARTUP',
        'SLEEP_SYSTEMTASK','SLEEP_TASK','SLEEP_TEMPDBSTARTUP','SNI_HTTP_ACCEPT',
        'SOS_WORK_DISPATCHER','SP_SERVER_DIAGNOSTICS_SLEEP','SQLTRACE_BUFFER_FLUSH',
        'SQLTRACE_INCREMENTAL_FLUSH_SLEEP','SQLTRACE_WAIT_ENTRIES',
        'UCS_SESSION_REGISTRATION','VDI_CLIENT_OTHER','WAIT_FOR_RESULTS',
        'WAIT_XTP_CKPT_CLOSE','WAIT_XTP_HOST_WAIT','WAIT_XTP_OFFLINE_CKPT_NEW_LOG',
        'WAIT_XTP_RECOVERY','WAITFOR','WAITFOR_TASKSHUTDOWN','XE_DISPATCHER_JOIN',
        'XE_DISPATCHER_WAIT','XE_LIVE_TARGET_TVF','XE_TIMER_EVENT')
)
SELECT TOP (@TopN)
       '4 server waits' AS section,
       w.wait_type,
       CAST(w.wait_time_ms / 1000.0 AS decimal(18,1))                         AS wait_seconds,
       CAST(100.0 * w.wait_time_ms / SUM(w.wait_time_ms) OVER () AS decimal(5,2)) AS pct_of_waits,
       w.waiting_tasks_count,
       CAST(1.0 * w.wait_time_ms / w.waiting_tasks_count AS decimal(18,2))     AS avg_wait_ms,
       CAST(100.0 * w.signal_wait_time_ms / NULLIF(w.wait_time_ms, 0) AS decimal(5,2)) AS pct_signal_cpu
FROM w
ORDER BY w.wait_time_ms DESC;

/* ---------------------------------------------------------------------------
 5. LIVE: what is running and who is blocking RIGHT NOW
--------------------------------------------------------------------------- */
SELECT '5a running requests' AS section,
       r.session_id, r.blocking_session_id, r.status, r.command,
       r.wait_type, r.wait_time AS wait_ms, r.wait_resource,
       r.total_elapsed_time AS elapsed_ms, r.cpu_time AS cpu_ms, r.logical_reads,
       r.open_transaction_count,
       DB_NAME(r.database_id) AS database_name,
       s.program_name, s.host_name, s.login_name,
       OBJECT_SCHEMA_NAME(st.objectid, st.dbid) + '.' +
           OBJECT_NAME(st.objectid, st.dbid)                                  AS procedure_name,
       SUBSTRING(st.text, (r.statement_start_offset / 2) + 1,
                 ((CASE r.statement_end_offset WHEN -1 THEN DATALENGTH(st.text)
                   ELSE r.statement_end_offset END - r.statement_start_offset) / 2) + 1)
                                                                              AS current_statement
FROM sys.dm_exec_requests AS r
JOIN sys.dm_exec_sessions AS s ON s.session_id = r.session_id
OUTER APPLY sys.dm_exec_sql_text(r.sql_handle) AS st
WHERE s.is_user_process = 1
  AND r.session_id <> @@SPID
ORDER BY CASE WHEN r.blocking_session_id > 0 THEN 0 ELSE 1 END, r.total_elapsed_time DESC;

-- Head blockers: sessions blocking others but not blocked themselves.
-- status = sleeping + open_transaction_count > 0 means the APP opened a
-- transaction and has not committed it (very common .NET cause).
WITH blocked AS (
    SELECT r.blocking_session_id, COUNT(*) AS sessions_blocked,
           MAX(r.wait_time) AS longest_wait_ms
    FROM sys.dm_exec_requests AS r
    WHERE r.blocking_session_id > 0
    GROUP BY r.blocking_session_id
)
SELECT '5b head blockers' AS section,
       s.session_id, s.status, b.sessions_blocked, b.longest_wait_ms,
       s.open_transaction_count, s.program_name, s.host_name, s.login_name,
       s.last_request_start_time, s.last_request_end_time,
       t.text AS last_sql_text
FROM blocked AS b
JOIN sys.dm_exec_sessions AS s ON s.session_id = b.blocking_session_id
LEFT JOIN sys.dm_exec_requests AS r ON r.session_id = s.session_id
LEFT JOIN sys.dm_exec_connections AS c ON c.session_id = s.session_id
OUTER APPLY sys.dm_exec_sql_text(c.most_recent_sql_handle) AS t
WHERE ISNULL(r.blocking_session_id, 0) = 0
ORDER BY b.sessions_blocked DESC;

/* ---------------------------------------------------------------------------
 6. Connections per application (connection pool / leaked transactions)
--------------------------------------------------------------------------- */
SELECT '6 sessions per app' AS section,
       s.program_name, s.host_name, s.login_name,
       COUNT(*)                                                               AS sessions,
       SUM(CASE WHEN s.status = 'running'  THEN 1 ELSE 0 END)                 AS running,
       SUM(CASE WHEN s.status = 'sleeping' THEN 1 ELSE 0 END)                 AS sleeping,
       SUM(CASE WHEN s.status = 'sleeping' AND s.open_transaction_count > 0
                THEN 1 ELSE 0 END)                                            AS sleeping_with_open_tran,
       MIN(s.last_request_end_time)                                           AS oldest_last_request_end
FROM sys.dm_exec_sessions AS s
WHERE s.is_user_process = 1
  AND s.database_id = DB_ID()
GROUP BY s.program_name, s.host_name, s.login_name
ORDER BY sessions DESC;

/* ---------------------------------------------------------------------------
 7. Missing index suggestions from the optimizer (review, do not apply blindly)
    Compare with the analyzer's "Index Candidates" sheet.
--------------------------------------------------------------------------- */
SELECT TOP (@TopN)
       '7 missing index hints' AS section,
       OBJECT_SCHEMA_NAME(d.object_id, d.database_id) + '.' +
           OBJECT_NAME(d.object_id, d.database_id)                            AS table_name,
       d.equality_columns, d.inequality_columns, d.included_columns,
       gs.user_seeks, gs.user_scans,
       CAST(gs.avg_total_user_cost AS decimal(18,2))                          AS avg_query_cost,
       CAST(gs.avg_user_impact AS decimal(5,1))                               AS est_improvement_pct,
       CAST(gs.avg_total_user_cost * gs.avg_user_impact
            * (gs.user_seeks + gs.user_scans) AS decimal(18,0))                AS priority_score,
       gs.last_user_seek
FROM sys.dm_db_missing_index_details AS d
JOIN sys.dm_db_missing_index_groups AS g       ON g.index_handle = d.index_handle
JOIN sys.dm_db_missing_index_group_stats AS gs ON gs.group_handle = g.index_group_handle
WHERE d.database_id = DB_ID()
ORDER BY priority_score DESC;

/* ---------------------------------------------------------------------------
 8. Index usage on large tables
    8a: many scans on a big clustered index / heap = full table scans
        many lookups = nonclustered index not covering the query
    8b: indexes that are only written, never read (cost on every INSERT/UPDATE)
--------------------------------------------------------------------------- */
SELECT TOP (@TopN)
       '8a scans and lookups on large tables' AS section,
       OBJECT_SCHEMA_NAME(i.object_id) + '.' + OBJECT_NAME(i.object_id)        AS table_name,
       ISNULL(i.name, '(heap)') AS index_name, i.type_desc,
       rc.row_count,
       us.user_seeks, us.user_scans, us.user_lookups, us.user_updates,
       us.last_user_scan
FROM sys.indexes AS i
JOIN sys.objects AS o ON o.object_id = i.object_id AND o.type = 'U' AND o.is_ms_shipped = 0
JOIN sys.dm_db_index_usage_stats AS us
     ON us.object_id = i.object_id AND us.index_id = i.index_id AND us.database_id = DB_ID()
CROSS APPLY (SELECT SUM(ps.row_count) AS row_count
             FROM sys.dm_db_partition_stats AS ps
             WHERE ps.object_id = i.object_id AND ps.index_id = i.index_id) AS rc
WHERE rc.row_count >= 100000
ORDER BY us.user_scans + us.user_lookups DESC;

SELECT TOP (@TopN)
       '8b write-only indexes' AS section,
       OBJECT_SCHEMA_NAME(i.object_id) + '.' + OBJECT_NAME(i.object_id)        AS table_name,
       i.name AS index_name, i.type_desc,
       ISNULL(us.user_updates, 0) AS user_updates,
       ISNULL(us.user_seeks + us.user_scans + us.user_lookups, 0) AS user_reads
FROM sys.indexes AS i
JOIN sys.objects AS o ON o.object_id = i.object_id AND o.type = 'U' AND o.is_ms_shipped = 0
LEFT JOIN sys.dm_db_index_usage_stats AS us
     ON us.object_id = i.object_id AND us.index_id = i.index_id AND us.database_id = DB_ID()
WHERE i.index_id > 1
  AND i.is_primary_key = 0
  AND i.is_unique_constraint = 0
  AND i.is_disabled = 0
  AND ISNULL(us.user_seeks + us.user_scans + us.user_lookups, 0) = 0
ORDER BY ISNULL(us.user_updates, 0) DESC;

/* ---------------------------------------------------------------------------
 9. Statistics that are stale (bad row estimates -> bad plans)
--------------------------------------------------------------------------- */
SELECT TOP (@TopN)
       '9 stale statistics' AS section,
       OBJECT_SCHEMA_NAME(st.object_id) + '.' + OBJECT_NAME(st.object_id)      AS table_name,
       st.name AS stats_name,
       sp.last_updated,
       DATEDIFF(day, sp.last_updated, SYSDATETIME())                           AS days_old,
       sp.rows,
       CAST(100.0 * sp.rows_sampled / NULLIF(sp.rows, 0) AS decimal(5,1))     AS sample_pct,
       sp.modification_counter,
       CAST(100.0 * sp.modification_counter / NULLIF(sp.rows, 0) AS decimal(9,1)) AS pct_rows_modified
FROM sys.stats AS st
JOIN sys.objects AS o ON o.object_id = st.object_id AND o.type = 'U' AND o.is_ms_shipped = 0
CROSS APPLY sys.dm_db_stats_properties(st.object_id, st.stats_id) AS sp
WHERE sp.rows >= 10000
ORDER BY 1.0 * sp.modification_counter / NULLIF(sp.rows, 0) DESC;

/* ---------------------------------------------------------------------------
 10. Availability Group health (empty if the DB is not in an AG)
     High log_send_queue / sync commit on a slow secondary slows every write.
--------------------------------------------------------------------------- */
SELECT '10 AG replica state' AS section,
       ar.replica_server_name, drs.is_local, drs.is_primary_replica,
       ar.availability_mode_desc, drs.synchronization_state_desc,
       drs.synchronization_health_desc,
       drs.log_send_queue_size AS log_send_queue_kb, drs.log_send_rate AS log_send_kb_per_sec,
       drs.redo_queue_size AS redo_queue_kb, drs.redo_rate AS redo_kb_per_sec,
       drs.last_commit_time
FROM sys.dm_hadr_database_replica_states AS drs
JOIN sys.availability_replicas AS ar ON ar.replica_id = drs.replica_id
WHERE drs.database_id = DB_ID();

/* ---------------------------------------------------------------------------
 11. Disk latency for this database and tempdb (since SQL start)
     Rough guide: data reads < 20 ms and log writes < 5 ms are healthy.
--------------------------------------------------------------------------- */
SELECT '11 file latency' AS section,
       DB_NAME(vfs.database_id) AS database_name, mf.type_desc, mf.name AS logical_name,
       mf.physical_name,
       vfs.num_of_reads, vfs.num_of_writes,
       CAST(1.0 * vfs.io_stall_read_ms  / NULLIF(vfs.num_of_reads, 0)  AS decimal(10,1)) AS avg_read_ms,
       CAST(1.0 * vfs.io_stall_write_ms / NULLIF(vfs.num_of_writes, 0) AS decimal(10,1)) AS avg_write_ms,
       CAST(vfs.size_on_disk_bytes / 1024.0 / 1024 / 1024 AS decimal(10,1))   AS size_gb
FROM sys.dm_io_virtual_file_stats(NULL, NULL) AS vfs
JOIN sys.master_files AS mf ON mf.database_id = vfs.database_id AND mf.file_id = vfs.file_id
WHERE vfs.database_id IN (DB_ID(), 2)
ORDER BY vfs.io_stall_read_ms + vfs.io_stall_write_ms DESC;
