"""MSSQL Stored Procedure Dependency Analyzer - command-line entry point.

Static analysis only: SQL files are read as untrusted text, never executed,
never modified, and no database connection is used.

    python main.py
    python main.py --input "C:\\StoredProcedures" --output "C:\\Reports"
"""
from __future__ import annotations

import argparse
import datetime as dt
import logging
import sys
import time
from pathlib import Path
from typing import List, Optional

from analyzer.engine import AnalysisEngine
from analyzer.file_reader import discover_sql_files
from analyzer.schema_catalog import load_schema_catalog
from config import ConfigError, load_config
from models import IssueType, ProcedureAnalysis, Status
from reports.excel_report import ExcelReportWriter
from reports.performance_builder import PerformanceBuilder
from reports.summary_builder import SummaryBuilder, mark_duplicate_procedures
from utils.logger import setup_logging

APP_NAME = "MSSQL Stored Procedure Dependency Analyzer"
APP_VERSION = "1.0.0"

log = logging.getLogger("main")


def parse_args(argv: Optional[List[str]] = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description=APP_NAME)
    p.add_argument("--config", help="path to config.ini (default: config.ini next to main.py)")
    p.add_argument("--input", help="directory containing stored procedure .sql files")
    p.add_argument("--output", help="directory for the Excel report")
    p.add_argument("--log-dir", help="directory for analyzer.log")
    p.add_argument("--log-level", help="DEBUG, INFO, WARNING or ERROR")
    p.add_argument("--schema", help="optional folder with CREATE TABLE / CREATE INDEX scripts "
                                    "and table_metadata.csv (overrides [Schema] schema_directory)")
    p.add_argument("--version", action="version", version=f"{APP_NAME} {APP_VERSION}")
    return p.parse_args(argv)


def _write_report(writer: ExcelReportWriter, analyses: List[ProcedureAnalysis], path: Path,
                  run_info: dict, catalog=None) -> Path:
    try:
        return writer.write(analyses, path, run_info, catalog=catalog)
    except PermissionError:
        # Typically the previous report is still open in Excel.
        stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
        alt = path.with_name(f"{path.stem}_{stamp}{path.suffix}")
        log.warning("Cannot overwrite %s (open in Excel?); writing %s instead", path, alt)
        print(f"WARNING: {path} is locked (open in Excel?). Writing {alt.name} instead.")
        return writer.write(analyses, alt, run_info, catalog=catalog)


def analyze_files(engine: AnalysisEngine, files: List[Path], root: Path) -> List[ProcedureAnalysis]:
    analyses: List[ProcedureAnalysis] = []
    for idx, path in enumerate(files, start=1):
        display = path.relative_to(root).as_posix()
        log.info("[%d/%d] Current file: %s", idx, len(files), display)
        try:
            results = engine.analyze_file(path, display)
        except Exception as exc:  # last-resort guard: one file never stops the run
            log.exception("Unexpected failure analysing %s", display)
            results = [engine.failed_result(display, IssueType.INTERNAL_ERROR,
                                            f"Unexpected error: {exc}")]
        for result in results:
            log.info("Result: %s -> %s (%d tables, %d joins, %d filters, dynamic=%s)",
                     result.full_name, result.status, len(result.physical_tables),
                     len(result.joins), len(result.filters), result.dynamic_sql_detected)
        analyses.extend(results)
    return analyses


def main(argv: Optional[List[str]] = None) -> int:
    args = parse_args(argv)
    try:
        cfg = load_config(Path(args.config) if args.config else None, args.input, args.output,
                          args.log_dir, args.log_level, args.schema)
    except ConfigError as exc:
        print(f"Configuration error: {exc}", file=sys.stderr)
        return 2

    log_path = setup_logging(cfg.log_path, cfg.log_level, cfg.console_log_level)
    started = time.perf_counter()
    log.info("Application start: %s %s (Python %s)", APP_NAME, APP_VERSION, sys.version.split()[0])
    for line in cfg.describe():
        log.info("Configuration: %s", line)

    if not cfg.input_directory.is_dir():
        log.error("Input directory not found: %s", cfg.input_directory)
        print(f"Input directory not found: {cfg.input_directory}", file=sys.stderr)
        return 2

    files = discover_sql_files(cfg.input_directory, cfg.file_extensions, cfg.recursive)
    log.info("SQL files discovered: %d in %s", len(files), cfg.input_directory)

    cfg.analysis.extra["max_file_bytes"] = cfg.max_file_size_mb * 1024 * 1024
    catalog = load_schema_catalog(cfg.schema_directory, cfg.schema_extensions,
                                  cfg.summary.default_schema)
    if catalog is not None:
        for warning in catalog.warnings:
            log.warning("Schema definitions: %s", warning)
    cfg.analysis.catalog = catalog
    engine = AnalysisEngine(cfg.analysis)
    analyses = analyze_files(engine, files, cfg.input_directory)
    mark_duplicate_procedures(analyses)

    builder = SummaryBuilder(analyses, cfg.summary)
    counts = builder.status_counts()
    run_info = {
        "generated": dt.datetime.now().strftime("%Y-%m-%d %H:%M"),
        "input": str(cfg.input_directory),
    }
    log.info("Excel report generation started")
    report_path = _write_report(ExcelReportWriter(cfg), analyses, cfg.report_path, run_info,
                                catalog)
    elapsed = time.perf_counter() - started
    perf = PerformanceBuilder(analyses, cfg.summary, cfg.performance, catalog)
    finding_counts = perf.finding_counts()

    summary = [
        "",
        "MSSQL Stored Procedure Analysis Complete",
        "",
        f"SQL files discovered:      {len(files):>6}",
        f"Procedures analysed:       {builder.procedure_count():>6}",
        f"Duplicate definitions:     {builder.duplicate_definitions():>6}",
        f"Successfully analyzed:     {counts[Status.SUCCESS]:>6}",
        f"Partially analyzed:        {counts[Status.PARTIAL]:>6}",
        f"Manual review required:    {counts[Status.MANUAL_REVIEW]:>6}",
        f"Failed:                    {counts[Status.FAILED]:>6}",
        "",
        f"Unique physical tables:    {builder.unique_physical_tables():>6}",
        "",
        "Performance review (static; review items, not measured results):",
        f"SP findings H/M/L/Info:    {finding_counts['HIGH']}/{finding_counts['MEDIUM']}/"
        f"{finding_counts['LOW']}/{finding_counts['INFO']}",
        f"Index candidates:          {len(perf.index_candidates()):>6}",
        f"Partitioning reviews:      {len(perf.partition_assessments()):>6}",
        "Schema definitions:        "
        + (f"{catalog.table_count} tables, {catalog.index_count} indexes"
           if catalog is not None else "not provided"),
        f"Elapsed seconds:           {elapsed:>6.1f}",
        "",
        "Report:",
        str(report_path),
        "",
        "Log:",
        str(log_path),
        "",
    ]
    for line in summary:
        if line:
            log.info("Execution summary: %s", line.strip())
    print("\n".join(summary))
    log.info("Application completion")
    return 0


if __name__ == "__main__":
    sys.exit(main())
