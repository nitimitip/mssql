"""Predicate, projection and loop rules; literal preservation; rule switches."""
import pytest

from analyzer.options import PerformanceOptions
from analyzer.parser import render_tokens
from analyzer.tokenizer import tokenize
from models.common import condition_key
from tests.helpers import proc
from tests.perf_helpers import finding, rules


# ---------------------------------------------------------------- PERF-P001
def test_year_on_column_gets_conditional_range_rewrite():
    f = finding(proc("SELECT o.id FROM dbo.Orders o WHERE YEAR(o.OrderDate) = 2024"), "PERF-P001")
    assert "YEAR()" in f.finding and f.severity == "MEDIUM"
    assert f.action == ("Conditional rewrite: o.OrderDate >= '20240101' AND "
                        "o.OrderDate < '20250101'")
    assert "date/time type" in f.assumptions


@pytest.mark.parametrize("pred, rewrite", [
    ("DATEADD(day, 30, a.d) < @now", "a.d < DATEADD(day, -30, @now)"),
    ("a.n + 1 > @x", "a.n > @x - 1"),
])
def test_rewrites_preserve_null_handling(pred, rewrite):
    f = finding(proc(f"SELECT a.x FROM dbo.A a WHERE {pred}"), "PERF-P001")
    assert f.action == f"Conditional rewrite: {rewrite}"


def test_isnull_without_declared_type_is_manual_review():
    # ISNULL converts the replacement to the column type, unknown without the schema
    f = finding(proc("SELECT a.x FROM dbo.A a WHERE ISNULL(a.s, '') = 'A'"), "PERF-P001")
    assert f.action.startswith("Manual review") and "declared type of a.s is not known" in f.action


def test_case_dependent_isnull_gets_no_concrete_rewrite():
    f = finding(proc("SELECT a.x FROM dbo.A a WHERE ISNULL(a.s, 'a') = 'A'"), "PERF-P001")
    assert not f.action.startswith("Conditional rewrite")


def test_dateadd_with_month_is_not_inverted():
    f = finding(proc("SELECT a.x FROM dbo.A a WHERE DATEADD(month, 1, a.d) < @now"), "PERF-P001")
    assert not f.action.startswith("Conditional rewrite")


def test_isnull_on_both_join_sides_warns_about_null_matching():
    f = finding(proc("SELECT a.x FROM dbo.A a JOIN dbo.B b ON ISNULL(a.k, 0) = ISNULL(b.k, 0)"),
                "PERF-P001")
    assert "makes NULL values match" in f.finding
    assert not f.action.startswith("Conditional rewrite")


def test_cast_to_date_is_low_severity_and_hedged():
    f = finding(proc("SELECT a.x FROM dbo.A a WHERE CAST(a.d AS date) = @d"), "PERF-P001")
    assert f.severity == "LOW" and "can still be seekable" in f.finding


def test_function_on_parameter_side_or_outer_column_is_not_flagged():
    assert "PERF-P001" not in rules(proc("SELECT a.x FROM dbo.A a WHERE a.d >= DATEADD(day, -7, @now)"))
    sql = ("SELECT a.x FROM dbo.A a WHERE EXISTS (SELECT 1 FROM dbo.B b "
           "WHERE b.code = UPPER(a.code))")
    assert "PERF-P001" not in rules(proc(sql))


def test_aggregates_in_having_are_not_flagged():
    sql = "SELECT a.g FROM dbo.A a GROUP BY a.g HAVING SUM(a.v) > 10"
    assert rules(proc(sql)) == []


# ---------------------------------------------------------------- PERF-P002
@pytest.mark.parametrize("pattern", ["'%abc'", "'_bc%'", "'%' + @s", "N'%' + @s + N'%'"])
def test_leading_wildcard_like(pattern):
    assert "PERF-P002" in rules(proc(f"SELECT a.x FROM dbo.A a WHERE a.n LIKE {pattern}"))


@pytest.mark.parametrize("pattern", ["'abc%'", "@s", "@s + '%'"])
def test_prefix_or_runtime_like_is_not_flagged(pattern):
    assert "PERF-P002" not in rules(proc(f"SELECT a.x FROM dbo.A a WHERE a.n LIKE {pattern}"))


# ---------------------------------------------------------------- PERF-P003
def test_optional_parameter_predicates_are_grouped_per_condition():
    r = proc("SELECT a.x FROM dbo.A a WHERE (@s IS NULL OR a.s = @s) "
             "AND (@t IS NULL OR a.t >= @t) AND a.k = 1")
    f = finding(r, "PERF-P003")
    assert "@s IS NULL OR a.s = @s" in f.evidence and "@t IS NULL OR a.t >= @t" in f.evidence
    assert "OPTION (RECOMPILE)" in f.action and "never concatenate" in f.action


def test_isnull_parameter_form_explains_null_trap_and_is_not_double_reported():
    r = proc("SELECT a.x FROM dbo.A a WHERE a.t = ISNULL(@t, a.t)")
    assert rules(r) == ["PERF-P003"]
    assert "rows where the column is NULL are excluded" in r.perf_findings[0].finding


def test_flag_logic_or_without_shared_parameter_is_not_catch_all():
    r = proc("SELECT a.x FROM dbo.A a WHERE (@mode = 1 AND a.s = 1) OR (@mode = 2 AND a.t = 2)")
    assert "PERF-P003" not in rules(r)


# ---------------------------------------------------------------- PERF-S001
def test_select_star_result_set():
    f = finding(proc("SELECT * FROM dbo.A a"), "PERF-S001")
    assert f.severity == "LOW" and "Projection-width review item" in f.action


def test_select_star_not_flagged_inside_exists_or_over_explicit_derived_columns():
    assert rules(proc("SELECT a.x FROM dbo.A a WHERE EXISTS (SELECT * FROM dbo.B b "
                      "WHERE b.id = a.id)")) == []
    assert rules(proc("SELECT * FROM (SELECT a.x, a.y FROM dbo.A a) d")) == []


def test_insert_select_star_mentions_column_order():
    f = finding(proc("INSERT INTO dbo.T SELECT * FROM dbo.A"), "PERF-S001")
    assert "column order" in f.finding


def test_qualified_star_and_set_operations():
    assert "PERF-S001" in rules(proc("SELECT b.* FROM dbo.A a JOIN dbo.B b ON b.id = a.id"))
    r = proc("SELECT a.x FROM dbo.A a UNION ALL SELECT * FROM dbo.B")
    assert finding(r, "PERF-S001").tables == "dbo.B"


# ---------------------------------------------------------------- loops
CURSOR = """DECLARE @id int
DECLARE c CURSOR LOCAL FAST_FORWARD FOR SELECT id FROM dbo.A WHERE s = 1
OPEN c
FETCH NEXT FROM c INTO @id
WHILE @@FETCH_STATUS = 0
BEGIN
    UPDATE dbo.B SET x = 1 WHERE id = @id
    EXEC dbo.usp_Log @id
    FETCH NEXT FROM c INTO @id
END
CLOSE c
DEALLOCATE c"""


def test_cursor_loop_lists_operations_per_iteration():
    f = finding(proc(CURSOR), "PERF-L001")
    assert f.finding.startswith("Cursor loop (FETCH) runs 2 database operation(s)")
    assert "UPDATE dbo.B (line 10)" in f.evidence and "EXEC dbo.usp_Log (line 11)" in f.evidence
    assert "not wrong in itself" in f.finding and "Keep the loop" in f.action


def test_loop_without_database_work_is_not_flagged():
    assert rules(proc("WHILE @i < 10\nBEGIN\n SET @s = @s + 'x'\n SET @i = @i + 1\nEND")) == []


def test_batched_delete_loop_is_info():
    r = proc("WHILE 1 = 1\nBEGIN\n DELETE TOP (5000) FROM dbo.Log WHERE d < @cut\n"
             " IF @@ROWCOUNT = 0 BREAK\nEND")
    f = finding(r, "PERF-L002")
    assert f.severity == "INFO" and "PERF-L001" not in rules(r)


def test_statement_inside_loop_is_marked_on_access_record():
    r = proc(CURSOR)
    update = [a for a in r.access_records if a.operation == "UPDATE"][0]
    assert update.in_loop and not [a for a in r.access_records if a.operation == "SELECT"][0].in_loop


# ---------------------------------------------------------------- literals
def test_condition_key_preserves_literal_case_and_whitespace():
    assert condition_key("x = 'a  b'") != condition_key("x = 'a b'")
    assert condition_key("x = 'ABC'") != condition_key("x = 'abc'")
    assert condition_key("X   =   'abc'") == condition_key("x = 'abc'")
    assert condition_key("x = N'it''s  here'") == condition_key("X = N'it''s  here'")


def test_render_keeps_line_breaks_inside_literals():
    sql = "SELECT 'a\nb' AS v"
    toks = tokenize(sql)
    assert render_tokens(toks, sql, (0, len(toks))) == "SELECT 'a\nb' AS v"


def test_findings_with_differently_spaced_literals_are_not_merged():
    r = proc("""DECLARE @s nvarchar(max) = N'SELECT a.x FROM dbo.A a WHERE a.n LIKE ''%a  b'''
IF @f = 1 SET @s = N'SELECT a.x FROM dbo.A a WHERE a.n LIKE ''%a b'''
EXEC sp_executesql @s""")
    found = [f for f in r.perf_findings if f.rule_id == "PERF-P002"]
    assert len(found) == 2
    assert {f.evidence for f in found} == {"a.n LIKE '%a  b'", "a.n LIKE '%a b'"}


def test_literal_case_is_kept_in_evidence_and_dedupe():
    r = proc("SELECT a.x FROM dbo.A a WHERE a.n LIKE '%Abc'\n"
             "SELECT a.x FROM dbo.A a WHERE a.n LIKE '%abc'")
    assert sorted(f.evidence for f in r.perf_findings) == ["a.n LIKE '%Abc'", "a.n LIKE '%abc'"]


# ---------------------------------------------------------------- switches / separation
def test_rules_can_be_disabled_individually():
    opts = PerformanceOptions(disabled_rules=frozenset({"PERF-J001"}))
    r = proc("SELECT * FROM dbo.A a, dbo.B b", performance=opts)
    assert rules(r) == ["PERF-S001"]


def test_performance_review_can_be_disabled_entirely():
    r = proc("SELECT * FROM dbo.A a, dbo.B b WHERE YEAR(a.d) = 1",
             performance=PerformanceOptions(enabled=False))
    assert r.perf_findings == [] and r.access_records == []


def test_findings_do_not_change_status_or_issues():
    r = proc("SELECT * FROM dbo.A a, dbo.B b WHERE YEAR(a.d) = 2024")
    assert r.status == "SUCCESS" and r.issues == []
    assert len(r.perf_findings) == 3


def test_parse_failures_are_not_turned_into_findings():
    r = proc("SELECT a.x FROM dbo.A a WHERE a.k = 1\nSELECT FROM WHERE ((")
    assert r.statements_failed == 1 and r.perf_findings == []
