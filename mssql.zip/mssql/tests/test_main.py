from pathlib import Path

from analyzer.engine import AnalysisEngine
from main import analyze_files
from models import IssueType, Status


class _BrokenEngine(AnalysisEngine):
    def analyze_file(self, path, display_name=None):
        if path.name == "bad.sql":
            raise ValueError("boom")
        return super().analyze_file(path, display_name)


def test_unexpected_error_records_failed_file_and_run_continues(tmp_path: Path):
    (tmp_path / "bad.sql").write_text("CREATE PROCEDURE dbo.bad AS SELECT 1", encoding="utf-8")
    (tmp_path / "good.sql").write_text("CREATE PROCEDURE dbo.good AS SELECT * FROM T",
                                       encoding="utf-8")
    files = [tmp_path / "bad.sql", tmp_path / "good.sql"]
    results = analyze_files(_BrokenEngine(), files, tmp_path)
    assert [(r.name, r.status) for r in results] == [("bad", Status.FAILED),
                                                      ("good", Status.SUCCESS)]
    assert results[0].issues[0].issue_type == IssueType.INTERNAL_ERROR
    assert "boom" in results[0].issues[0].description
