"""Index candidates: per-statement combinations, consolidation, existing-index comparison."""
from analyzer.options import PerformanceOptions
from reports.performance_builder import (
    ASSESS_CANDIDATE, ASSESS_COVERED, ASSESS_INSUFFICIENT, ASSESS_OVERLAP, filter_key,
)
from tests.perf_helpers import analyze_many, builder, catalog_from, sp

ORDERS_DDL = """
CREATE TABLE dbo.Orders (
    OrderID int NOT NULL CONSTRAINT PK_Orders PRIMARY KEY CLUSTERED,
    CustomerID int NOT NULL,
    OrderDate datetime2(3) NOT NULL,
    Status varchar(20) NOT NULL,
    Region varchar(20) NULL,
    Amount money NULL,
    Notes varchar(max) NULL
);
CREATE NONCLUSTERED INDEX IX_Orders_Customer_Date ON dbo.Orders (CustomerID, OrderDate)
    INCLUDE (Amount);
CREATE NONCLUSTERED INDEX IX_Orders_Open ON dbo.Orders (Region) WHERE ([Status]='OPEN');
"""


def cands(analyses, catalog=None, **perf):
    return builder(analyses, catalog, PerformanceOptions(**perf)).index_candidates()


def keyed(candidates):
    return {(c.table_display, tuple(c.keys), c.filter): c for c in candidates}


# ---------------------------------------------------------------- shape of a candidate
def test_equality_then_range_and_include_from_projection():
    a = analyze_many({"p.sql": sp("p", "SELECT o.Amount FROM dbo.Orders o "
                                       "WHERE o.CustomerID = @c AND o.OrderDate >= @d")})
    (c,) = cands(a)
    assert c.keys == ["CustomerID", "OrderDate"] and c.eq_count == 1
    assert c.includes == ["Amount"] and c.filter == "" and c.candidate_type == "Nonclustered"
    assert "Range predicate on OrderDate follows the equality columns" in c.reasoning


def test_columns_from_unrelated_statements_are_not_combined():
    a = analyze_many({
        "p1.sql": sp("p1", "SELECT o.OrderID FROM dbo.Orders o WHERE o.CustomerID = @c"),
        "p2.sql": sp("p2", "SELECT o.OrderID FROM dbo.Orders o WHERE o.Region = @r"),
    })
    assert sorted(tuple(c.keys) for c in cands(a)) == [("CustomerID",), ("Region",)]


def test_identical_candidates_are_consolidated_and_procedures_counted_distinctly():
    body = "SELECT o.OrderID FROM dbo.Orders o WHERE o.CustomerID = @c"
    a = analyze_many({
        "p1.sql": sp("p1", body + "\n" + body.replace("@c", "@x")),   # same proc twice
        "p2.sql": sp("p2", body),
        "p2_copy.sql": sp("p2", body),                                  # duplicate definition
    })
    (c,) = cands(a)
    assert len(c.procedures) == 2
    assert c.statement_count == 3          # p1 S1, p1 S2, p2 S1 (copy not double counted)
    assert "not how often the procedures run" in c.reasoning


def test_equality_order_follows_statement_frequency_then_name():
    a = analyze_many({
        "p1.sql": sp("p1", "SELECT o.OrderID FROM dbo.Orders o WHERE o.Status = @s AND o.Region = @r"),
        "p2.sql": sp("p2", "SELECT o.OrderID FROM dbo.Orders o WHERE o.Region = @r"),
    })
    two = [c for c in cands(a) if len(c.keys) == 2][0]
    assert two.keys == ["Region", "Status"]
    assert "reasoned guess" in two.reasoning


def test_prefix_overlap_between_candidates_is_reported():
    a = analyze_many({
        "p1.sql": sp("p1", "SELECT o.OrderID FROM dbo.Orders o WHERE o.Region = @r"),
        "p2.sql": sp("p2", "SELECT o.OrderID FROM dbo.Orders o WHERE o.Region = @r AND o.Status = @s"),
    })
    short = [c for c in cands(a) if c.keys == ["Region"]][0]
    long_ = [c for c in cands(a) if len(c.keys) == 2][0]
    assert f"Left prefix of {long_.candidate_id}" in short.overlap
    assert f"Extends {short.candidate_id}" in long_.overlap


def test_constant_predicate_becomes_filtered_candidate_with_exact_literal():
    a = analyze_many({"p.sql": sp("p", "SELECT o.OrderID FROM dbo.Orders o "
                                       "WHERE o.Status = 'Open ' AND o.CustomerID = @c")})
    (c,) = cands(a)
    assert c.filter == "[Status] = 'Open '" and c.keys == ["CustomerID"]
    assert c.candidate_type == "Nonclustered (filtered)"
    assert "parameter such as @Status does not match" in c.validation


def test_or_only_and_wrapped_columns_are_not_keys():
    a = analyze_many({"p.sql": sp("p", "SELECT o.OrderID FROM dbo.Orders o WHERE o.CustomerID = @c "
                                       "AND (o.Region = @r OR o.Status = @s) "
                                       "AND YEAR(o.OrderDate) = 2024")})
    (c,) = cands(a)
    assert c.keys == ["CustomerID"]
    assert "only inside OR branches" in c.reasoning and "PERF-P001" in c.reasoning


def test_star_and_wide_projection_give_key_only_candidates():
    star = analyze_many({"p.sql": sp("p", "SELECT * FROM dbo.Orders o WHERE o.CustomerID = @c")})
    (c,) = cands(star)
    assert c.includes == [] and "SELECT *" in c.reasoning
    wide = analyze_many({"p.sql": sp("p", "SELECT o.a, o.b, o.c, o.d FROM dbo.Orders o "
                                          "WHERE o.CustomerID = @c")})
    (c,) = cands(wide, max_include_columns=3)
    assert c.includes == [] and "key-only" in c.reasoning


def test_key_width_is_capped():
    a = analyze_many({"p.sql": sp("p", "SELECT o.x FROM dbo.Orders o WHERE o.a = 1 AND o.b = @b "
                                       "AND o.c = @c AND o.d = @d")})
    (c,) = cands(a, max_key_columns=2)
    assert len(c.keys) == 2 and "Key limited to 2 columns" in c.reasoning


def test_left_join_on_predicates_apply_to_the_inner_side_only():
    a = analyze_many({"p.sql": sp("p", "SELECT c.Name FROM dbo.Customer c LEFT JOIN dbo.Orders o "
                                       "ON o.CustomerID = c.CustomerID AND c.Region = 'X'")})
    tables = {c.table_display for c in cands(a)}
    assert tables == {"dbo.Orders"}       # c.Region in ON does not filter the preserved side


def test_correlated_subquery_columns_feed_include_of_outer_table():
    a = analyze_many({"p.sql": sp("p", "SELECT o.OrderID FROM dbo.Orders o WHERE o.Region = @r "
                                       "AND EXISTS (SELECT 1 FROM dbo.Pay p WHERE p.OrderID = o.OrderID)")})
    orders = [c for c in cands(a) if c.table_display == "dbo.Orders"][0]
    pay = [c for c in cands(a) if c.table_display == "dbo.Pay"][0]
    assert orders.includes == ["OrderID"] and pay.keys == ["OrderID"]
    assert "Join-only support" in pay.reasoning


def test_unresolved_columns_are_never_candidate_columns():
    a = analyze_many({"p.sql": sp("p", "SELECT o.OrderID FROM dbo.Orders o JOIN dbo.Customer c "
                                       "ON c.CustomerID = o.CustomerID WHERE Region = @r")})
    for c in cands(a):
        assert "Region" not in c.keys + c.includes
        assert c.confidence == "LOW"


def test_temp_tables_and_views_get_no_candidates():
    a = analyze_many({"p.sql": sp("p", "SELECT t.x FROM #t t WHERE t.k = 1\n"
                                       "SELECT v.x FROM dbo.vw_Orders v WHERE v.k = 1")})
    assert cands(a) == []


def test_dynamic_support_caps_confidence():
    a = analyze_many({"p.sql": sp("p", "DECLARE @s nvarchar(max) = N'SELECT o.OrderID FROM "
                                       "dbo.Orders o WHERE o.CustomerID = 5'\nEXEC sp_executesql @s")})
    (c,) = cands(a)
    assert c.confidence == "MEDIUM" and "dynamic SQL" in c.supports[0].label


def test_candidates_can_be_disabled():
    a = analyze_many({"p.sql": sp("p", "SELECT o.OrderID FROM dbo.Orders o WHERE o.Region = @r")})
    assert builder(a, None, PerformanceOptions(disabled_rules=frozenset({"IDX-001"}))) \
        .index_candidates() == []


# ---------------------------------------------------------------- existing indexes
def test_without_definitions_nothing_is_claimed_missing():
    a = analyze_many({"p.sql": sp("p", "SELECT o.OrderID FROM dbo.Orders o WHERE o.Region = @r")})
    (c,) = cands(a)
    assert c.assessment == ASSESS_INSUFFICIENT
    assert "not provided" in c.assessment_detail and "missing" not in c.assessment_detail.lower()


def test_covered_overlap_and_new_candidate_against_definitions(tmp_path):
    cat = catalog_from(tmp_path, ORDERS_DDL)
    a = analyze_many({
        "covered.sql": sp("covered", "SELECT o.Amount FROM dbo.Orders o "
                                     "WHERE o.CustomerID = @c AND o.OrderDate >= @d"),
        "overlap.sql": sp("overlap", "SELECT o.Status FROM dbo.Orders o "
                                     "WHERE o.CustomerID = @c AND o.OrderDate >= @d AND o.Region = @r"),
        "new.sql": sp("new", "SELECT o.OrderID FROM dbo.Orders o WHERE o.Status = @s"),
        "filtered.sql": sp("filtered", "SELECT o.Region FROM dbo.Orders o "
                                       "WHERE o.Status = 'OPEN' AND o.Region = @r"),
    }, catalog=cat)
    by_proc = {c.procedures[0].name: c for c in cands(a, cat)}
    assert by_proc["covered"].assessment == ASSESS_COVERED
    assert "IX_Orders_Customer_Date" in by_proc["covered"].assessment_detail
    assert by_proc["overlap"].assessment == ASSESS_OVERLAP
    assert by_proc["new"].assessment == ASSESS_CANDIDATE
    # [Status] = 'OPEN' matches the SSMS-scripted ([Status]='OPEN') filter
    assert by_proc["filtered"].assessment == ASSESS_COVERED


def test_clustered_key_is_not_repeated_in_include(tmp_path):
    cat = catalog_from(tmp_path, ORDERS_DDL)
    a = analyze_many({"p.sql": sp("p", "SELECT o.OrderID, o.Amount FROM dbo.Orders o "
                                       "WHERE o.Status = @s")}, catalog=cat)
    (c,) = cands(a, cat)
    assert c.includes == ["Amount"] and "Clustered key column(s) OrderID" in c.reasoning


def test_equality_columns_match_existing_index_in_any_order(tmp_path):
    cat = catalog_from(tmp_path, "CREATE TABLE dbo.T (a int, b int, c int);\n"
                                 "CREATE INDEX IX_T_ba ON dbo.T (b, a);")
    a = analyze_many({"p.sql": sp("p", "SELECT t.a FROM dbo.T t WHERE t.a = @a AND t.b = @b")},
                     catalog=cat)
    (c,) = cands(a, cat)
    assert c.assessment == ASSESS_COVERED


def test_filtered_existing_index_does_not_cover_unfiltered_need(tmp_path):
    cat = catalog_from(tmp_path, ORDERS_DDL)
    a = analyze_many({"p.sql": sp("p", "SELECT o.Region FROM dbo.Orders o WHERE o.Region = @r")},
                     catalog=cat)
    (c,) = cands(a, cat)
    assert c.assessment == ASSESS_OVERLAP and "filtered differently" in c.assessment_detail


def test_unknown_column_or_lob_key_is_insufficient(tmp_path):
    cat = catalog_from(tmp_path, ORDERS_DDL)
    a = analyze_many({
        "p1.sql": sp("p1", "SELECT o.OrderID FROM dbo.Orders o WHERE o.Missing = @m"),
        "p2.sql": sp("p2", "SELECT o.OrderID FROM dbo.Orders o WHERE o.Notes = @n"),
    }, catalog=cat)
    by_proc = {c.procedures[0].name: c for c in cands(a, cat)}
    assert by_proc["p1"].assessment == ASSESS_INSUFFICIENT
    assert "not in the provided definition" in by_proc["p1"].assessment_detail
    assert "cannot be index key columns" in by_proc["p2"].assessment_detail


def test_ddl_is_review_only_commented_and_never_unique(tmp_path):
    cat = catalog_from(tmp_path, ORDERS_DDL)
    a = analyze_many({"p.sql": sp("p", "SELECT o.OrderID FROM dbo.Orders o WHERE o.OrderID = @id")},
                     catalog=cat)
    (c,) = cands(a, cat)
    assert c.assessment == ASSESS_COVERED                     # the PK already serves it
    assert all(line.startswith("--") for line in c.ddl.splitlines())
    assert "REVIEW-ONLY" in c.ddl and "UNIQUE" not in c.ddl.upper()


def test_write_overhead_mentions_updates_of_indexed_columns(tmp_path):
    a = analyze_many({
        "r.sql": sp("r", "SELECT o.OrderID FROM dbo.Orders o WHERE o.Status = @s"),
        "w.sql": sp("w", "UPDATE dbo.Orders SET Status = 'X' WHERE OrderID = @id\n"
                         "INSERT INTO dbo.Orders (OrderID) VALUES (1)"),
    })
    status = [c for c in cands(a) if c.keys == ["Status"]][0]
    assert "INSERT 1" in status.tradeoffs and "UPDATE 1" in status.tradeoffs
    assert "UPDATEs change indexed column(s): Status" in status.tradeoffs


def test_filter_key_normalisation():
    assert filter_key("[Status] = 'OPEN'") == filter_key("([status]='OPEN')")
    assert filter_key("[Status] = 'OPEN'") != filter_key("[Status] = 'open'")
    assert filter_key("[Status] = 'OPEN '") != filter_key("[Status] = 'OPEN'")
