from helpers import filter_columns, filters, proc, table, unresolved

from models import Confidence, Status


def _where(condition: str):
    return proc(f"SELECT * FROM Customer c JOIN Orders o ON c.Id = o.CustomerId WHERE {condition}")


def test_where_equals_and_comparisons():
    r = _where("c.Status = 'Active' AND o.OrderDate >= @StartDate AND o.Amount > 1000 "
               "AND o.Qty <> 0 AND o.Code != 'X' AND o.Rank <= 3")
    assert filters(r) == {"Customer.Status =", "Orders.OrderDate >=", "Orders.Amount >",
                          "Orders.Qty <>", "Orders.Code !=", "Orders.Rank <="}
    f = next(f for f in r.filters if f.column.column == "Status")
    assert f.compared_with == "'Active'"
    assert f.original == "c.Status = 'Active'"


def test_is_null_and_is_not_null():
    r = _where("c.DeletedOn IS NULL AND o.ShippedOn IS NOT NULL")
    assert filters(r) == {"Customer.DeletedOn IS NULL", "Orders.ShippedOn IS NOT NULL"}


def test_in_and_not_in_lists():
    r = _where("c.Status IN ('OPEN', 'PENDING', 'HOLD') AND o.Type NOT IN (1, 2)")
    assert filters(r) == {"Customer.Status IN", "Orders.Type NOT IN"}
    f = next(f for f in r.filters if f.column.column == "Status")
    assert f.compared_with == "('OPEN', 'PENDING', 'HOLD')"


def test_between_and_not_between():
    r = _where("o.OrderDate BETWEEN @StartDate AND @EndDate AND o.Amount NOT BETWEEN 1 AND 5")
    assert filters(r) == {"Orders.OrderDate BETWEEN", "Orders.Amount NOT BETWEEN"}


def test_like_and_not_like():
    r = _where("c.CustomerName LIKE @SearchText + '%' AND c.Email NOT LIKE '%@test.com'")
    assert filters(r) == {"Customer.CustomerName LIKE", "Customer.Email NOT LIKE"}


def test_and_or_not_conditions():
    r = _where("(c.A = 1 OR c.B = 2) AND NOT (o.C = 3) AND (@p IS NULL OR o.D = @p)")
    assert filters(r) == {"Customer.A =", "Customer.B =", "Orders.C NOT =", "Orders.D ="}


def test_column_compared_with_column_records_both_sides():
    r = _where("o.ShipDate > c.CreatedOn")
    assert filters(r) == {"Orders.ShipDate >", "Customer.CreatedOn <"}


def test_having_is_distinguished_from_where():
    r = proc("""
        SELECT CustomerID FROM Orders WHERE Status = 'X'
        GROUP BY CustomerID
        HAVING COUNT(OrderID) > 5""")
    assert filters(r, "WHERE") == {"Orders.Status ="}
    assert filters(r, "HAVING") == {"Orders.OrderID >"}
    having = next(f for f in r.filters if f.clause == "HAVING")
    assert having.confidence == Confidence.MEDIUM
    assert "aggregate" in having.notes
    assert set(table(r, "Orders").having_columns) == {"ORDERID"}


def test_group_by_and_order_by_columns_are_not_reported():
    r = proc("SELECT Region, COUNT(*) FROM Orders WHERE Year = 2024 GROUP BY Region ORDER BY Region, Total")
    usage = table(r, "Orders")
    assert set(usage.where_columns) == {"YEAR"}
    assert not usage.join_columns and not usage.having_columns


def test_ambiguous_unqualified_column_is_not_guessed():
    r = proc("SELECT * FROM Customer c JOIN Orders o ON c.CustomerID = o.CustomerID WHERE Status = 1")
    f = next(f for f in r.filters if f.column.column == "Status")
    assert f.column.table is None
    assert f.confidence == Confidence.LOW
    assert set(f.column.candidates) == {"Customer", "Orders"}
    assert "Status" in unresolved(r)
    assert "STATUS" not in table(r, "Customer").where_columns
    assert "STATUS" not in table(r, "Orders").where_columns
    assert r.status == Status.PARTIAL


def test_unqualified_column_single_table_is_high_confidence():
    r = proc("SELECT * FROM StagingCustomer WHERE IsValid = 1")
    assert filters(r) == {"StagingCustomer.IsValid ="}
    assert r.filters[0].confidence == Confidence.HIGH


def test_unqualified_column_resolved_by_known_temp_columns():
    r = proc("""
        CREATE TABLE #t (Id int, Name varchar(10));
        SELECT * FROM #t t JOIN dbo.Orders o ON o.Id = t.Id WHERE Amount > 5""")
    f = next(f for f in r.filters if f.column.column == "Amount")
    assert f.column.table is not None and f.column.table.name == "Orders"
    assert f.confidence == Confidence.MEDIUM


def test_case_expression_in_where_is_flagged():
    r = proc("SELECT * FROM dbo.X x WHERE CASE WHEN x.b > 0 THEN x.c ELSE x.d END = 5")
    assert filter_columns(r) == {"X.b", "X.c", "X.d"}
    assert all("CASE" in f.notes for f in r.filters)


def test_duplicate_conditions_are_deduplicated_with_count():
    r = proc("""
        SELECT * FROM T WHERE T.A = 1;
        SELECT * FROM T WHERE T.A = 1;""")
    # different statements -> different contexts, so two rows; same statement twice -> one row
    r2 = proc("SELECT * FROM T WHERE T.A = 1 OR T.A = 1")
    assert len(r2.filters) == 1 and r2.filters[0].occurrences == 2
    assert len(r.filters) == 1 and r.filters[0].occurrences == 2


def test_and_or_logic_and_full_condition_are_kept():
    r_and = proc("SELECT * FROM T WHERE T.A = 1 AND T.B = 2")
    r_or = proc("SELECT * FROM T WHERE T.A = 1 OR T.B = 2")
    assert {f.logic for f in r_and.filters} == {"AND"}
    assert {f.logic for f in r_or.filters} == {"OR"}
    assert {f.full_condition for f in r_or.filters} == {"T.A = 1 OR T.B = 2"}

    r = proc("SELECT * FROM T WHERE T.A = 1 AND (T.B = 2 OR NOT (T.C = 3 AND T.D = 4))")
    logic = {f.column.column: f.logic for f in r.filters}
    assert logic == {"A": "AND", "B": "AND > OR", "C": "AND > OR > NOT > AND",
                     "D": "AND > OR > NOT > AND"}
    single = proc("SELECT * FROM T WHERE T.A = 1").filters[0]
    assert (single.logic, single.full_condition) == ("", "T.A = 1")


def test_literal_case_is_preserved_in_deduplication():
    r = proc("SELECT * FROM T WHERE T.Name = 'abc'; SELECT * FROM T WHERE T.Name = 'ABC'")
    assert sorted(f.compared_with for f in r.filters) == ["'ABC'", "'abc'"]


def test_merged_condition_keeps_every_location():
    r = proc("SELECT * FROM T WHERE T.A = 1;\nDELETE FROM T WHERE T.A = 1")
    assert len(r.filters) == 1
    f = r.filters[0]
    assert f.occurrences == 2
    assert [loc.split(" ")[0] for loc in f.locations] == ["SELECT", "DELETE"]


def test_same_predicate_under_different_rules_is_not_merged():
    r = proc("SELECT * FROM T WHERE T.A = 1 AND T.B = 2;\nSELECT * FROM T WHERE T.A = 1 OR T.B = 2")
    assert sorted(f.logic for f in r.filters if f.column.column == "A") == ["AND", "OR"]
