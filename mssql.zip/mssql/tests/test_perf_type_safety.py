"""Review feedback 2026-10-08: rewrites must follow SQL Server types exactly;
index candidates must not lose procedure versions or hide uncertainty."""
import pytest

from analyzer.sql_types import coalesce_result, compare_literals, isnull_result, to_decimal
from reports.performance_builder import ASSESS_COVERED, ASSESS_OVERLAP
from tests.perf_helpers import analyze_many, builder, catalog_from, sp

DDL = """
CREATE TABLE dbo.T (
    Id bigint NOT NULL,
    Code varchar(2) NULL,
    Name varchar(10) NULL,
    Uni nvarchar(5) NULL,
    Qty int NULL,
    Tiny tinyint NULL,
    Price decimal(5, 2) NULL,
    Cash money NULL,
    D date NULL,
    DT datetime NULL,
    SD smalldatetime NULL,
    Ratio float NULL
);
"""


def action_for(tmp_path, predicate: str, with_schema: bool = True) -> str:
    cat = catalog_from(tmp_path, DDL) if with_schema else None
    (a,) = analyze_many({"p.sql": sp("p", f"SELECT t.Id FROM dbo.T t WHERE {predicate}")},
                        catalog=cat)
    found = [f for f in a.perf_findings if f.rule_id == "PERF-P001"]
    assert len(found) == 1, [f.rule_id for f in a.perf_findings]
    return found[0].action


# ---------------------------------------------------------------- ISNULL / COALESCE
@pytest.mark.parametrize("pred, expected", [
    # the reported case: varchar(2) truncates 'LONG' to 'LO', so NULL rows DO match
    ("ISNULL(t.Code, 'LONG') = 'LO'", "Conditional rewrite: (t.Code = 'LO' OR t.Code IS NULL)"),
    ("ISNULL(t.Name, 'LONG') = 'LO'", "Conditional rewrite: t.Name = 'LO'"),
    # COALESCE keeps the longer type: no truncation, NULL rows do not match
    ("COALESCE(t.Code, 'LONG') = 'LO'", "Conditional rewrite: t.Code = 'LO'"),
    ("ISNULL(t.Code, '') = 'A'", "Conditional rewrite: t.Code = 'A'"),
    ("ISNULL(t.Code, 'A ') = 'A'", "Conditional rewrite: (t.Code = 'A' OR t.Code IS NULL)"),
    # numeric -> int truncates 1.9 to 1
    ("ISNULL(t.Qty, 1.9) = 1", "Conditional rewrite: (t.Qty = 1 OR t.Qty IS NULL)"),
    ("COALESCE(t.Qty, 1.9) = 1", "Conditional rewrite: t.Qty = 1"),
    # decimal(5,2) rounds 1.005 to 1.01
    ("ISNULL(t.Price, 1.005) = 1.01", "Conditional rewrite: (t.Price = 1.01 OR t.Price IS NULL)"),
    # money rounds to 4 places, also under COALESCE (money outranks decimal)
    ("COALESCE(t.Cash, 0.00005) > 0", "Conditional rewrite: (t.Cash > 0 OR t.Cash IS NULL)"),
    ("ISNULL(t.Id, -1) > 0", "Conditional rewrite: t.Id > 0"),
])
def test_null_replacement_rewrites_follow_sql_server_conversion(tmp_path, pred, expected):
    assert action_for(tmp_path, pred) == expected


@pytest.mark.parametrize("pred, reason", [
    ("ISNULL(t.Tiny, 300) = 300", "outside the tinyint range"),
    ("ISNULL(t.Code, 'a') = 'A'", "depends on the collation"),
    ("ISNULL(t.Uni, N'é') = N'e'", "depends on the collation"),
    ("ISNULL(t.Ratio, 1) = 1", "not modelled"),
    ("ISNULL(t.Code, 1) = 1", "not modelled"),
    ("ISNULL(t.Price, 12345) = 1", "arithmetic overflow"),
])
def test_undecidable_null_replacement_is_manual_review(tmp_path, pred, reason):
    action = action_for(tmp_path, pred)
    assert action.startswith("Manual review") and reason in action


def test_no_rewrite_without_declared_type_even_for_obvious_values(tmp_path):
    action = action_for(tmp_path, "ISNULL(t.Code, 'LONG') = 'LO'", with_schema=False)
    assert action.startswith("Manual review") and "not known" in action


def test_isnull_and_coalesce_result_values():
    assert isnull_result(("string", "LONG"), "VARCHAR", ["2"]) == (("string", "LO"), "")
    assert isnull_result(("string", "LONG"), "VARCHAR", ["MAX"]) == (("string", "LONG"), "")
    assert isnull_result(("string", "LONG"), "CHAR", []) == (("string", "L"), "")
    assert isnull_result(("number", "-1.9"), "INT", []) == (("number", "-1"), "")
    assert isnull_result(("number", "2147483648"), "INT", [])[0] is None
    assert coalesce_result(("string", "LONG"), "VARCHAR", ["2"]) == (("string", "LONG"), "")


# ---------------------------------------------------------------- exact numerics
def test_large_integers_compare_exactly():
    a, b = ("number", "9007199254740992"), ("number", "9007199254740993")
    assert compare_literals("=", a, b) is False and compare_literals("<", a, b) is True
    assert compare_literals("=", ("number", "0.1"), ("number", "0.10")) is True
    assert to_decimal("1e3") is None and to_decimal("0x1F") is None


def test_large_integer_isnull_rewrite_is_not_inverted(tmp_path):
    action = action_for(tmp_path, "ISNULL(t.Id, 9007199254740992) = 9007199254740993")
    assert action == "Conditional rewrite: t.Id = 9007199254740993"


def test_large_integer_on_clause_is_not_constant_true(tmp_path):
    (a,) = analyze_many({"p.sql": sp("p", "SELECT t.Id FROM dbo.T t JOIN dbo.U u "
                                          "ON 9007199254740992 = 9007199254740993")})
    assert [f.rule_id for f in a.perf_findings] == ["PERF-J002"]


# ---------------------------------------------------------------- YEAR boundaries
@pytest.mark.parametrize("pred, expected", [
    ("YEAR(t.D) = 9999", "Conditional rewrite: t.D >= '99990101'"),
    ("YEAR(t.D) = 2024", "Conditional rewrite: t.D >= '20240101' AND t.D < '20250101'"),
    ("YEAR(t.D) = 1", "Conditional rewrite: t.D >= '00010101' AND t.D < '00020101'"),
    ("YEAR(t.SD) = 2079", "Conditional rewrite: t.SD >= '20790101'"),
    ("YEAR(t.SD) = 2078", "Conditional rewrite: t.SD >= '20780101' AND t.SD < '20790101'"),
])
def test_year_rewrite_respects_type_range(tmp_path, pred, expected):
    action = action_for(tmp_path, pred)
    assert action == expected
    assert "100000101" not in action


@pytest.mark.parametrize("pred, with_schema, reason", [
    ("YEAR(t.DT) = 1500", True, "never true"),
    ("YEAR(t.SD) = 2080", True, "never true"),
    ("YEAR(t.D) = 10000", True, "never true"),
    ("YEAR(t.Name) = 2024", True, "not a date/time type"),
    ("YEAR(t.D) = 9999", False, "outside 1900-2078"),
    ("YEAR(t.D) = 1800", False, "outside 1900-2078"),
])
def test_year_rewrite_refused_at_boundaries(tmp_path, pred, with_schema, reason):
    action = action_for(tmp_path, pred, with_schema)
    assert action.startswith("Manual review") and reason in action


def test_year_with_variable_is_a_template_with_validity_range(tmp_path):
    cat = catalog_from(tmp_path, DDL)
    (a,) = analyze_many({"p.sql": sp("p", "SELECT t.Id FROM dbo.T t WHERE YEAR(t.D) = @y")},
                        catalog=cat)
    f = a.perf_findings[0]
    assert f.action.startswith("Manual review (template")
    assert "between 1 and 9998" in f.assumptions and "@y = 9999 fails" in f.assumptions


# ---------------------------------------------------------------- index candidates
def test_differing_procedure_versions_keep_their_columns():
    v1 = sp("usp_Get", "SELECT o.Name FROM dbo.Orders o WHERE o.CustomerID = @c")
    v2 = sp("usp_Get", "SELECT o.Email FROM dbo.Orders o WHERE o.CustomerID = @c")
    analyses = analyze_many({"v1.sql": v1, "v2.sql": v2})
    (cand,) = builder(analyses).index_candidates()
    assert cand.includes == ["Name", "Email"]
    assert len(cand.procedures) == 1 and cand.statement_count == 2
    labels = [s.label for s in cand.supports]
    assert any("(v1.sql)" in l for l in labels) and any("(v2.sql)" in l for l in labels)


def test_identical_copies_are_still_counted_once():
    body = sp("usp_Get", "SELECT o.Name FROM dbo.Orders o WHERE o.CustomerID = @c")
    (cand,) = builder(analyze_many({"a.sql": body, "b.sql": body})).index_candidates()
    assert len(cand.supports) == 1 and cand.statement_count == 1


ORDERS = """CREATE TABLE dbo.Orders (OrderID int NOT NULL PRIMARY KEY, CustomerID int,
    OrderDate datetime2, Amount money, Region varchar(10));
CREATE TABLE dbo.Customer (CustomerID int NOT NULL PRIMARY KEY, Region varchar(10));
CREATE INDEX IX_Orders_Customer_Date ON dbo.Orders (CustomerID, OrderDate) INCLUDE (Amount);"""


def test_mixed_confidence_support_is_not_a_confident_coverage_claim(tmp_path):
    cat = catalog_from(tmp_path, ORDERS)
    analyses = analyze_many({
        "clean.sql": sp("clean", "SELECT o.Amount FROM dbo.Orders o "
                                 "WHERE o.CustomerID = @c AND o.OrderDate >= @d"),
        "vague.sql": sp("vague", "SELECT o.Amount FROM dbo.Orders o JOIN dbo.Customer c "
                                 "ON c.CustomerID = o.CustomerID "
                                 "WHERE o.CustomerID = @c AND o.OrderDate >= @d AND Region = @r"),
    }, catalog=cat)
    cand = [c for c in builder(analyses, cat).index_candidates()
            if c.table_display == "dbo.Orders"][0]
    assert {s.analysis.name for s in cand.supports} == {"clean", "vague"}
    assert cand.confidence == "LOW"
    assert cand.assessment == ASSESS_OVERLAP and "unresolved columns (Region)" in cand.assessment_detail
    assert "HIGH 1, LOW 1" in cand.reasoning
    assert any("confidence LOW; unresolved: Region" in s.label for s in cand.supports)
    # the clean statement alone is a confident coverage claim
    clean_only = analyze_many({"clean.sql": sp("clean", "SELECT o.Amount FROM dbo.Orders o "
                                                         "WHERE o.CustomerID = @c AND o.OrderDate >= @d")},
                              catalog=cat)
    (alone,) = builder(clean_only, cat).index_candidates()
    assert alone.assessment == ASSESS_COVERED and alone.confidence == "HIGH"
