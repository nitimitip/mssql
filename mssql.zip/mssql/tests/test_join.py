import pytest
from helpers import join_types, joins, ops, physical, proc, table

from models import Confidence


def test_one_join():
    r = proc("SELECT * FROM Customer c JOIN Orders o ON c.CustomerID = o.CustomerID")
    assert joins(r) == {"Customer.CustomerID = Orders.CustomerID"}
    assert ops(r, "Customer") == {"SELECT"}
    assert ops(r, "Orders") == {"SELECT", "JOIN"}


@pytest.mark.parametrize("sql_join, expected", [
    ("JOIN", "INNER JOIN"),
    ("INNER JOIN", "INNER JOIN"),
    ("LEFT JOIN", "LEFT JOIN"),
    ("LEFT OUTER JOIN", "LEFT JOIN"),
    ("RIGHT JOIN", "RIGHT JOIN"),
    ("RIGHT OUTER JOIN", "RIGHT JOIN"),
    ("FULL JOIN", "FULL JOIN"),
    ("FULL OUTER JOIN", "FULL JOIN"),
    ("INNER HASH JOIN", "INNER JOIN"),
])
def test_join_types(sql_join, expected):
    r = proc(f"SELECT * FROM A a {sql_join} B b ON a.Id = b.AId")
    assert join_types(r) == {expected}
    assert joins(r) == {"A.Id = B.AId"}


def test_cross_join_has_no_condition():
    r = proc("SELECT * FROM A a CROSS JOIN B b WHERE a.X = 1")
    assert physical(r) == {"A", "B"}
    assert ops(r, "B") == {"SELECT", "JOIN"}
    assert r.joins == []


def test_multiple_joins():
    r = proc("""
        SELECT * FROM Customer c
        JOIN Orders o ON c.CustomerID = o.CustomerID
        LEFT JOIN Payments p ON p.OrderID = o.OrderID
        RIGHT JOIN Region g ON g.RegionID = c.RegionID""")
    assert joins(r) == {
        "Customer.CustomerID = Orders.CustomerID",
        "Payments.OrderID = Orders.OrderID",
        "Region.RegionID = Customer.RegionID",
    }
    assert join_types(r) == {"INNER JOIN", "LEFT JOIN", "RIGHT JOIN"}


def test_multiple_column_join_is_not_collapsed():
    r = proc("""
        SELECT * FROM Customer c
        JOIN Orders o ON c.CustomerID = o.CustomerID AND c.RegionID = o.RegionID""")
    assert joins(r) == {
        "Customer.CustomerID = Orders.CustomerID",
        "Customer.RegionID = Orders.RegionID",
    }


def test_complex_join_conditions_with_functions():
    r = proc("""
        SELECT * FROM Customer a JOIN Orders b
          ON a.CustomerID = b.CustomerID
         AND a.StartDate <= b.OrderDate
         AND ISNULL(a.RegionID, 0) = ISNULL(b.RegionID, 0)""")
    assert joins(r) == {
        "Customer.CustomerID = Orders.CustomerID",
        "Customer.StartDate <= Orders.OrderDate",
        "Customer.RegionID = Orders.RegionID",
    }
    wrapped = [j for j in r.joins if "ISNULL" in j.normalized]
    assert wrapped and "ISNULL()" in wrapped[0].notes
    assert wrapped[0].normalized == "ISNULL(Customer.RegionID, 0) = ISNULL(Orders.RegionID, 0)"


def test_join_predicate_with_literal_is_a_join_column():
    r = proc("SELECT * FROM A a JOIN H h ON a.Id = h.AId AND h.Kind = 'X'")
    assert "H.Kind = 'X'" in joins(r)
    assert "KIND" in table(r, "H").join_columns


def test_literal_on_left_is_oriented():
    r = proc("SELECT * FROM A a JOIN H h ON a.Id = h.AId AND 5 < h.Level")
    assert "H.Level > 5" in joins(r)


def test_nested_join_syntax():
    r = proc("SELECT * FROM A a JOIN B b JOIN C c ON b.Id = c.BId ON a.Id = b.AId")
    assert joins(r) == {"B.Id = C.BId", "A.Id = B.AId"}


def test_comma_join_with_where_predicate():
    r = proc("SELECT * FROM A a, B b WHERE a.Id = b.AId AND a.X = 1")
    assert joins(r, "WHERE (join predicate)") == {"A.Id = B.AId"}
    assert ops(r, "B") == {"SELECT", "JOIN"}


def test_original_and_normalized_condition():
    r = proc("SELECT * FROM BT_ENQUIRY_MASTER e LEFT JOIN BT_ACT_HIST h ON e.ae_internalref = h.hist_internalref")
    j = r.joins[0]
    assert j.original == "e.ae_internalref = h.hist_internalref"
    assert j.normalized == "BT_ENQUIRY_MASTER.ae_internalref = BT_ACT_HIST.hist_internalref"
    assert j.confidence == Confidence.HIGH


def test_unknown_alias_in_join_is_not_guessed():
    r = proc("SELECT * FROM A a JOIN B b ON a.Id = zz.BId")
    j = r.joins[0]
    assert j.right[0].table is None
    assert j.confidence == Confidence.LOW
    assert "zz.BId" in {u.ref.original for u in r.unresolved}


def test_on_condition_keeps_and_or_logic_and_full_condition():
    r = proc("SELECT * FROM T t JOIN U u ON t.Id = u.Id OR t.A = u.A")
    assert {j.logic for j in r.joins} == {"OR"}
    assert {j.full_condition for j in r.joins} == {"t.Id = u.Id OR t.A = u.A"}

    r = proc("SELECT * FROM T t JOIN U u ON t.Id = u.Id AND (u.A = 1 OR u.B = t.B)")
    assert {j.normalized: j.logic for j in r.joins} == {
        "T.Id = U.Id": "AND", "U.A = 1": "AND > OR", "U.B = T.B": "AND > OR"}


def test_where_join_predicate_under_or_is_marked():
    r = proc("SELECT * FROM T t, U u WHERE t.Id = u.Id OR t.X = 1")
    assert [(j.join_type, j.logic) for j in r.joins] == [("WHERE (join predicate)", "OR")]


def test_join_literals_keep_case_but_identifiers_do_not():
    r = proc("SELECT * FROM T t JOIN U u ON t.Id = u.Id AND u.Code = 'abc' AND u.Code = 'ABC'")
    assert sorted(j.right_value for j in r.joins if j.right_value) == ["'ABC'", "'abc'"]
    assert all(j.occurrences == 1 for j in r.joins)

    r = proc("SELECT * FROM T t JOIN U u ON t.Id = u.Id AND T.ID = U.ID")
    assert len(r.joins) == 1 and r.joins[0].occurrences == 2
