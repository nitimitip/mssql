from pathlib import Path

import openpyxl
import pytest

from analyzer.engine import AnalysisEngine
from config import AppConfig
from reports.excel_report import ExcelReportWriter
from reports.summary_builder import SummaryBuilder
from config import SummaryOptions
from utils.excel_helpers import SheetNameRegistry, internal_link, sanitize_sheet_name


def test_sheet_name_sanitising():
    assert sanitize_sheet_name("a[b]:c*d?e/f\\g") == "a_b__c_d_e_f_g"
    assert sanitize_sheet_name("'quoted'") == "quoted"


def test_long_and_duplicate_sheet_names_are_unique_and_valid():
    reg = SheetNameRegistry(reserved=["Summary"])
    a = reg.assign(1, "usp_Very_Long_Stored_Procedure_For_Searching_Enquiry")
    b = reg.assign(2, "usp_Very_Long_Stored_Procedure_For_Searching_Orders")
    c = reg.assign(3, "summary")             # collides with reserved name (case-insensitive)
    d = reg.assign(4, "usp_Short")
    e = reg.assign(5, "USP_SHORT")
    assert a == "usp_Very_Long_Stored_Procedu_01"
    assert b == "usp_Very_Long_Stored_Procedu_02"
    assert c == "summary_01"
    assert (d, e) == ("usp_Short", "USP_SHORT_01")
    assert all(len(n) <= 31 for n in reg.mapping.values())
    assert reg.assign(1, "ignored") == a       # stable mapping


def test_internal_link_escapes_apostrophes():
    assert internal_link("O'Brien") == "internal:'O''Brien'!A1"


def _config(tmp_path: Path) -> AppConfig:
    return AppConfig(config_file=None, input_directory=tmp_path, output_directory=tmp_path,
                     log_directory=tmp_path)


SQL_A = """CREATE PROCEDURE dbo.usp_A AS
SELECT * FROM BT_ACT_HIST h WHERE h.x = 1
SELECT * FROM BT_ACT_HIST h2 JOIN dbo.T t ON t.id = h2.id
UPDATE BT_ACT_HIST SET y = 1"""
SQL_B = "CREATE PROCEDURE dbo.usp_B AS SELECT * FROM dbo.BT_ACT_HIST; SELECT * INTO #tmp FROM dbo.T"
SQL_LONG = ("CREATE PROCEDURE dbo.usp_Very_Long_Stored_Procedure_For_Searching_Enquiry AS "
            "SELECT * FROM dbo.T WHERE Status = 1")


def _analyses():
    engine = AnalysisEngine()
    return (engine.analyze_text(SQL_A, "a.sql") + engine.analyze_text(SQL_B, "b.sql")
            + engine.analyze_text(SQL_LONG, "long.sql"))


def test_sp_count_counts_each_procedure_once():
    rows = {r.name: r for r in SummaryBuilder(_analyses(), SummaryOptions()).table_rows()}
    # usp_A references BT_ACT_HIST three times, usp_B once (schema-qualified)
    assert rows["BT_ACT_HIST"].sp_count == 2
    assert rows["BT_ACT_HIST"].schema == "dbo"
    assert rows["T"].sp_count == 3
    assert "#tmp" not in rows
    assert rows["T"].rank == 1 and rows["BT_ACT_HIST"].rank == 2


def test_workbook_structure_and_hyperlinks(tmp_path: Path):
    analyses = _analyses()
    path = ExcelReportWriter(_config(tmp_path)).write(analyses, tmp_path / "r.xlsx",
                                                     {"generated": "now", "input": "x"})
    wb = openpyxl.load_workbook(path)
    assert wb.sheetnames[0] == "Summary"
    assert {"SP Index", "Column Usage", "Join Relationships", "Analysis Issues"} <= set(wb.sheetnames)
    long_proc = next(a for a in analyses if a.name.startswith("usp_Very"))
    assert long_proc.sheet_name in wb.sheetnames and len(long_proc.sheet_name) <= 31

    summary = wb["Summary"]
    header = [c.value for c in summary[5]]
    assert header[:6] == ["Rank", "Database", "Schema", "Table Name", "Object Type", "SP Count"]
    sp_col = header.index("SP 1") + 1
    links = {}
    for row in summary.iter_rows(min_row=6):
        cell = row[sp_col - 1]
        if cell.hyperlink is not None:
            links[cell.value] = cell.hyperlink.location
    for analysis in analyses:
        if analysis.full_name in links:
            assert links[analysis.full_name] == f"'{analysis.sheet_name}'!A1"
    assert links, "summary has no procedure hyperlinks"

    for analysis in analyses:
        ws = wb[analysis.sheet_name]
        assert ws["A1"].hyperlink.location == "'Summary'!A1"
        assert "Back to Summary" in ws["A1"].value
        values = [c.value for c in ws["B"]]
        assert analysis.full_name in values          # full original name inside the sheet


def test_report_writes_formula_like_text_as_text(tmp_path: Path):
    analyses = AnalysisEngine().analyze_text(
        "CREATE PROCEDURE dbo.p AS SELECT * FROM dbo.T t WHERE t.a = '=1+1'", "p.sql")
    path = ExcelReportWriter(_config(tmp_path)).write(analyses, tmp_path / "r.xlsx", {})
    wb = openpyxl.load_workbook(path)
    ws = wb[analyses[0].sheet_name]
    texts = [c.value for row in ws.iter_rows() for c in row if isinstance(c.value, str)]
    assert "'=1+1'" in texts


DUP_V1 = "CREATE PROCEDURE dbo.usp_Dup AS\n-- version 1\nSELECT * FROM dbo.T WHERE Status = 1"
DUP_V1_COPY = "CREATE PROCEDURE usp_Dup AS /* copy */ select *   from dbo.T where Status = 1"
DUP_V2 = "CREATE PROCEDURE dbo.usp_Dup AS SELECT * FROM dbo.T JOIN dbo.U ON U.id = T.id"


def _dup_analyses(*sources):
    from reports.summary_builder import mark_duplicate_procedures
    engine = AnalysisEngine()
    analyses = [a for i, sql in enumerate(sources) for a in engine.analyze_text(sql, f"f{i}.sql")]
    mark_duplicate_procedures(analyses)
    return analyses


def test_identical_duplicate_procedure_counts_once():
    analyses = _dup_analyses(DUP_V1, DUP_V1_COPY)
    builder = SummaryBuilder(analyses, SummaryOptions())
    assert builder.procedure_count() == 1 and builder.duplicate_definitions() == 1
    assert {r.name: r.sp_count for r in builder.table_rows()} == {"T": 1}
    assert builder.status_counts()["SUCCESS"] == 1
    assert all(a.status == "SUCCESS" for a in analyses)
    assert analyses[0].also_defined_in == ["f1.sql (line 1)"]
    assert [i.severity for i in analyses[0].issues] == ["INFO"]


def test_different_duplicate_procedure_is_flagged():
    analyses = _dup_analyses(DUP_V1, DUP_V2)
    builder = SummaryBuilder(analyses, SummaryOptions())
    assert builder.procedure_count() == 1
    assert {r.name: r.sp_count for r in builder.table_rows()} == {"T": 1, "U": 1}
    assert builder.status_counts()["PARTIAL"] == 1
    assert all(a.status == "PARTIAL" for a in analyses)
    assert all("DIFFERENT" in a.issues[-1].description for a in analyses)


def test_filter_sheet_has_logic_full_condition_and_locations(tmp_path: Path):
    analyses = AnalysisEngine().analyze_text(
        "CREATE PROCEDURE dbo.p AS SELECT * FROM dbo.T t WHERE t.a = 1 OR t.b = 2", "p.sql")
    path = ExcelReportWriter(_config(tmp_path)).write(analyses, tmp_path / "r.xlsx", {})
    ws = openpyxl.load_workbook(path)[analyses[0].sheet_name]
    rows = [[c.value for c in row] for row in ws.iter_rows()]
    header = next(r for r in rows if r[:2] == ["#", "Clause"])
    for name in ("Logic", "Full Condition", "Locations"):
        assert name in header
    data = rows[rows.index(header) + 1]
    assert data[header.index("Logic")] == "OR"
    assert data[header.index("Full Condition")] == "t.a = 1 OR t.b = 2"
