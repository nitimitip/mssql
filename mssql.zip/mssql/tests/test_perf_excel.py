"""Workbook contents and navigation for the performance sheets."""
from pathlib import Path

import openpyxl

from config import AppConfig
from reports.excel_report import ExcelReportWriter
from tests.perf_helpers import analyze_many, catalog_from, sp

FINDING_HEADERS = ["Rule ID", "Severity", "Confidence", "Procedure", "Source File", "Statement ID",
                   "Line", "Tables/Aliases", "Finding", "SQL Evidence", "Suggested Action",
                   "Assumptions", "Required Validation"]
INDEX_HEADERS = ["Candidate ID", "Table", "Key Columns", "INCLUDE Columns", "Filter",
                 "Existing Index Assessment", "Supporting SP Count", "Supporting Procedures",
                 "Statement Evidence", "Reasoning", "Trade-offs", "Confidence",
                 "Required Validation"]
PARTITION_HEADERS = ["Table", "Candidate Column", "Observed Pattern", "Supporting Procedures",
                     "Available Evidence", "Missing Evidence", "Potential Benefit", "Assessment"]

SOURCES = {
    "cart.sql": sp("usp_Cartesian", "SELECT * FROM dbo.Orders o, dbo.Customer c WHERE o.Status = 'OPEN'"),
    "purge.sql": sp("usp_Purge", "DELETE FROM dbo.Orders WHERE OrderDate < @cut"),
    "dyn.sql": sp("usp_Dyn", "DECLARE @s nvarchar(max) = N'SELECT * FROM ' + @tbl\nEXEC (@s)"),
    "clean.sql": sp("usp_Clean", "SELECT o.OrderID FROM dbo.Orders o WHERE o.CustomerID = @c"),
}


def _write(tmp_path: Path, catalog=None) -> openpyxl.Workbook:
    cfg = AppConfig(config_file=None, input_directory=tmp_path, output_directory=tmp_path,
                    log_directory=tmp_path)
    analyses = analyze_many(SOURCES, catalog=catalog)
    path = ExcelReportWriter(cfg).write(analyses, tmp_path / "r.xlsx", {"generated": "now"},
                                        catalog=catalog)
    return openpyxl.load_workbook(path), analyses


def _table(ws, first_header: str):
    rows = [[c.value for c in row] for row in ws.iter_rows()]
    start = next(i for i, r in enumerate(rows) if r and r[0] == first_header)
    header = rows[start]
    data = []
    for r in rows[start + 1:]:
        if r[0] is None:
            break
        data.append(dict(zip(header, r)))
    return header, data, start


def test_sheet_order_and_navigation(tmp_path):
    wb, analyses = _write(tmp_path)
    names = wb.sheetnames
    assert names[:9] == ["Summary", "SP Index", "Column Usage", "Join Relationships",
                         "Analysis Issues", "SP Performance Findings", "Index Candidates",
                         "Partitioning Review", "Performance Coverage"]
    summary_link = wb["Summary"]["A4"]
    assert summary_link.hyperlink.location == "'SP Performance Findings'!A1"
    assert "SP findings" in summary_link.value
    for name in names[5:9]:
        ws = wb[name]
        assert ws["A1"].hyperlink.location == "'Summary'!A1"
        targets = {c.hyperlink.location for c in ws[1] if c.hyperlink is not None}
        assert {f"'{n}'!A1" for n in names[5:9] if n != name} <= targets
    proc_ws = wb[analyses[0].sheet_name]
    assert proc_ws["C1"].hyperlink.location == "'SP Performance Findings'!A1"
    assert any(c.value == "7. Performance Findings" for c in proc_ws["A"])


def test_findings_sheet_columns_links_and_content(tmp_path):
    wb, analyses = _write(tmp_path)
    ws = wb["SP Performance Findings"]
    header, rows, start = _table(ws, "Rule ID")
    assert header[:13] == FINDING_HEADERS
    cart = [r for r in rows if r["Rule ID"] == "PERF-J001"][0]
    assert cart["Severity"] == "HIGH" and cart["Statement ID"] == "S1" and cart["Line"] == 4
    assert cart["SQL Evidence"].startswith("FROM dbo.Orders o, dbo.Customer c")
    assert "Possible impact" in cart["Finding"] and cart["SQL Origin"] == "Static SQL"
    sheet = next(a.sheet_name for a in analyses if a.name == "usp_Cartesian")
    link_cell = ws.cell(row=start + 1 + rows.index(cart) + 1, column=header.index("Procedure") + 1)
    assert link_cell.hyperlink.location == f"'{sheet}'!A1"
    # most severe first
    order = {"HIGH": 0, "MEDIUM": 1, "LOW": 2, "INFO": 3}
    assert [order[r["Severity"]] for r in rows] == sorted(order[r["Severity"]] for r in rows)


def test_index_candidates_sheet(tmp_path):
    wb, _ = _write(tmp_path)
    header, rows, _ = _table(wb["Index Candidates"], "Candidate ID")
    assert header[:13] == INDEX_HEADERS
    customer = [r for r in rows if r["Key Columns"] == "CustomerID"][0]
    assert customer["Existing Index Assessment"].startswith("Insufficient information")
    assert customer["Supporting SP Count"] == 1
    assert customer["Review-only DDL"].startswith("-- REVIEW-ONLY CANDIDATE")
    assert "usp_Clean S1 (line 4) SELECT: o.CustomerID = @c" in customer["Statement Evidence"]


def test_index_candidates_sheet_with_schema(tmp_path):
    cat = catalog_from(tmp_path, "CREATE TABLE dbo.Orders (OrderID int PRIMARY KEY, "
                                 "CustomerID int, Status varchar(10), OrderDate datetime);"
                                 "CREATE INDEX IX_C ON dbo.Orders (CustomerID);")
    wb, _ = _write(tmp_path, cat)
    _, rows, _ = _table(wb["Index Candidates"], "Candidate ID")
    customer = [r for r in rows if r["Key Columns"] == "CustomerID"][0]
    assert customer["Existing Index Assessment"].startswith("Already covered")
    _, schema_rows, _ = _table(wb["Performance Coverage"], "Item")
    assert {r["Item"]: r["Value"] for r in schema_rows}["Tables defined"] == 1


def test_partitioning_sheet_reports_insufficient_evidence(tmp_path):
    wb, _ = _write(tmp_path)
    header, rows, _ = _table(wb["Partitioning Review"], "Table")
    assert header[:8] == PARTITION_HEADERS
    (row,) = rows
    assert row["Table"] == "dbo.Orders" and row["Candidate Column"] == "OrderDate"
    assert row["Assessment"] == "Insufficient evidence for a partitioning recommendation."


def test_coverage_sheet_shows_runtime_sql_and_rules(tmp_path):
    wb, _ = _write(tmp_path)
    ws = wb["Performance Coverage"]
    _, rows, _ = _table(ws, "Procedure")
    gaps = {(r["Procedure"], r["Gap Type"]) for r in rows}
    assert ("dbo.usp_Dyn", "Runtime-generated SQL not analysed") in gaps
    assert ("dbo.usp_Clean", "No coverage gaps") in gaps
    _, rule_rows, _ = _table(ws, "Rule ID")
    assert {r["Rule ID"] for r in rule_rows} >= {"PERF-J001", "PERF-P003", "IDX-001", "PART-001"}


def test_existing_sheets_still_work(tmp_path):
    wb, analyses = _write(tmp_path)
    header = [c.value for c in wb["Summary"][5]]
    assert header[:6] == ["Rank", "Database", "Schema", "Table Name", "Object Type", "SP Count"]
    index_header, index_rows, _ = _table(wb["SP Index"], "#")
    assert index_header[-1] == "Performance Findings"
    counts = {r["Stored Procedure"]: r["Performance Findings"] for r in index_rows}
    assert counts["dbo.usp_Cartesian"] == 2 and counts["dbo.usp_Clean"] == 0
