from helpers import filters, joins, ops, proc, table

from models import Confidence


def test_simple_update():
    r = proc("UPDATE dbo.Customer SET Status = 3 WHERE CustomerID = @Id")
    assert ops(r, "Customer") == {"UPDATE"}
    assert filters(r) == {"Customer.CustomerID ="}


def test_update_from_join_spec_example():
    r = proc("""
        UPDATE c
        SET c.Status = o.Status, c.LastUpdated = GETDATE()
        FROM Customer c
        JOIN Orders o ON c.CustomerID = o.CustomerID
        WHERE o.OrderStatus = 'COMPLETE';""")
    assert ops(r, "Customer") == {"UPDATE"}
    assert ops(r, "Orders") == {"SELECT", "JOIN"}
    assert joins(r) == {"Customer.CustomerID = Orders.CustomerID"}
    assert filters(r) == {"Orders.OrderStatus ="}
    assert set(table(r, "Customer").join_columns) == {"CUSTOMERID"}
    # SET clause columns are not reported
    assert "STATUS" not in table(r, "Customer").where_columns
    assert "LASTUPDATED" not in table(r, "Customer").where_columns


def test_update_target_is_joined_table():
    r = proc("UPDATE o SET o.Flag = 1 FROM Customer c JOIN Orders o ON o.CustomerID = c.CustomerID")
    assert ops(r, "Orders") == {"UPDATE", "JOIN"}
    assert ops(r, "Customer") == {"SELECT"}


def test_update_by_table_name_with_from():
    r = proc("UPDATE Customer SET Flag = 1 FROM Customer JOIN Orders o ON o.CustomerID = Customer.CustomerID")
    assert ops(r, "Customer") == {"UPDATE"}
    assert joins(r) == {"Orders.CustomerID = Customer.CustomerID"}


def test_update_with_subquery_in_set_and_where():
    r = proc("""
        UPDATE dbo.Customer
        SET Total = (SELECT SUM(o.Amount) FROM dbo.Orders o WHERE o.CustomerID = dbo.Customer.CustomerID)
        WHERE EXISTS (SELECT 1 FROM dbo.Flags f WHERE f.Id = dbo.Customer.CustomerID AND f.On = 1)""")
    assert ops(r, "Customer") == {"UPDATE"}
    assert ops(r, "Orders") == {"SELECT"}
    assert "Orders.CustomerID = Customer.CustomerID" in joins(r, "CORRELATED SUBQUERY")
    assert "Flags.On =" in filters(r)


def test_update_through_cte_attributes_base_table():
    r = proc("""
        WITH d AS (SELECT Id, Flag FROM dbo.Items WHERE Batch = 1)
        UPDATE d SET Flag = 0""")
    items = table(r, "Items")
    assert "UPDATE" in items.operations
    assert "SELECT" in items.operations


def test_update_top_and_hints():
    r = proc("UPDATE TOP (100) dbo.Queue WITH (ROWLOCK, READPAST) SET Locked = 1 OUTPUT inserted.Id WHERE Locked = 0")
    assert ops(r, "Queue") == {"UPDATE"}
    assert filters(r) == {"Queue.Locked ="}
    assert r.filters[0].confidence == Confidence.HIGH
