from helpers import filters, joins, ops, physical, proc, table

from models import Confidence


def test_merge_spec_example():
    r = proc("""
        MERGE Customer AS Target
        USING StagingCustomer AS Source
        ON Target.CustomerID = Source.CustomerID
        WHEN MATCHED THEN
            UPDATE SET Target.Name = Source.Name
        WHEN NOT MATCHED THEN
            INSERT (CustomerID, Name)
            VALUES (Source.CustomerID, Source.Name);""")
    assert ops(r, "Customer") == {"MERGE", "UPDATE", "INSERT"}
    assert ops(r, "StagingCustomer") == {"SELECT", "MERGE SOURCE"}
    assert joins(r, "MERGE ON") == {"Customer.CustomerID = StagingCustomer.CustomerID"}
    assert set(table(r, "Customer").join_columns) == {"CUSTOMERID"}
    assert set(table(r, "StagingCustomer").join_columns) == {"CUSTOMERID"}
    assert table(r, "Customer").aliases == ["Target"]


def test_merge_with_derived_source_delete_and_when_condition():
    r = proc("""
        MERGE INTO dbo.Customer T
        USING (SELECT s.CustomerID, s.Name FROM staging.Customer s WHERE s.IsValid = 1) S
        ON T.CustomerID = S.CustomerID
        WHEN MATCHED AND T.Name <> S.Name THEN UPDATE SET T.Name = S.Name
        WHEN NOT MATCHED BY TARGET THEN INSERT (CustomerID, Name) VALUES (S.CustomerID, S.Name)
        WHEN NOT MATCHED BY SOURCE THEN DELETE;""")
    assert ops(r, "Customer", "dbo") == {"MERGE", "UPDATE", "INSERT", "DELETE"}
    assert ops(r, "Customer", "staging") == {"SELECT"}
    assert physical(r) == {"Customer"}            # two schemas, same name
    assert "Customer.IsValid =" in filters(r)
    merge_on = [j for j in r.joins if j.join_type == "MERGE ON"]
    assert len(merge_on) == 1
    right = merge_on[0].right[0]
    assert right.table.schema == "staging" and right.confidence == Confidence.MEDIUM
    assert {"Customer.Name <>", "Customer.Name <>"} & filters(r, "MERGE WHEN")


def test_merge_output_into():
    r = proc("""
        MERGE dbo.T AS t USING dbo.S AS s ON t.Id = s.Id
        WHEN MATCHED THEN DELETE
        OUTPUT $action, deleted.Id INTO dbo.Log (Action, Id);""")
    assert ops(r, "T") == {"MERGE", "DELETE"}
    assert ops(r, "Log") == {"INSERT"}
