"""Join-connectivity rules: Cartesian products, unconnected / constant ON, OR bypass."""
import pytest

from analyzer.options import AnalysisOptions
from analyzer.engine import AnalysisEngine
from tests.helpers import proc
from tests.perf_helpers import catalog_from, finding, rules


# ---------------------------------------------------------------- genuine vs connected
def test_comma_join_without_relating_predicate_is_potential_cartesian():
    r = proc("SELECT a.x, b.y FROM dbo.A a, dbo.B b WHERE a.Status = 1")
    f = finding(r, "PERF-J001")
    assert (f.severity, f.confidence) == ("HIGH", "HIGH")
    assert "Potential Cartesian product" in f.finding
    assert f.evidence.startswith("FROM dbo.A a, dbo.B b") and "WHERE a.Status = 1" in f.evidence
    assert f.statement_id == "S1" and f.line == 4


def test_comma_join_connected_by_where_is_not_flagged():
    assert rules(proc("SELECT a.x FROM dbo.A a, dbo.B b WHERE a.id = b.id AND b.s = 1")) == []


def test_three_way_comma_join_flags_only_the_unconnected_source():
    r = proc("SELECT a.x FROM dbo.A a, dbo.B b, dbo.C c WHERE a.id = c.a_id")
    f = finding(r, "PERF-J001")
    assert "dbo.B" in f.finding.split("no WHERE")[0]


def test_explicit_inner_join_on_keys_is_not_flagged():
    sql = ("SELECT o.id FROM dbo.Orders o JOIN dbo.Customer c ON c.id = o.customer_id "
           "LEFT JOIN dbo.Region r ON r.id = c.region_id")
    assert rules(proc(sql)) == []


def test_unresolved_column_lowers_confidence_to_manual_review():
    r = proc("SELECT 1 AS x FROM dbo.A a, dbo.B b WHERE Code = OtherCode")
    f = finding(r, "PERF-J001")
    assert f.confidence == "LOW" and "manual review" in f.finding


# ---------------------------------------------------------------- CROSS JOIN / single row
def test_explicit_cross_join_is_low_severity_manual_review():
    f = finding(proc("SELECT a.x FROM dbo.A a CROSS JOIN dbo.Calendar d"), "PERF-J006")
    assert f.severity == "LOW" and "often intentional" in f.finding
    assert "PERF-J001" not in rules(proc("SELECT a.x FROM dbo.A a CROSS JOIN dbo.Calendar d"))


def test_cross_join_related_in_where_is_not_flagged():
    assert rules(proc("SELECT a.x FROM dbo.A a CROSS JOIN dbo.B b WHERE b.id = a.id")) == []


@pytest.mark.parametrize("source", [
    "(SELECT MAX(d) AS m FROM dbo.B) z",                     # scalar aggregate
    "(SELECT TOP (1) b.v FROM dbo.B b ORDER BY b.d DESC) z",  # TOP 1
    "(SELECT @p AS p) z",                                     # no FROM
    "(VALUES (1, 2)) v(a, b)",                                # one VALUES row
])
def test_provably_single_row_sources_are_not_cartesian(source):
    assert rules(proc(f"SELECT a.x FROM dbo.A a CROSS JOIN {source}")) == []
    assert rules(proc(f"SELECT a.x FROM dbo.A a, {source}")) == []


def test_aggregate_with_group_by_is_not_single_row():
    r = proc("SELECT a.x FROM dbo.A a, (SELECT g, MAX(d) m FROM dbo.B GROUP BY g) z")
    assert "PERF-J001" in rules(r)


def test_top_with_ties_is_not_single_row():
    r = proc("SELECT a.x FROM dbo.A a CROSS JOIN (SELECT TOP (1) WITH TIES b.v FROM dbo.B b "
             "ORDER BY b.d) z")
    assert "PERF-J006" in rules(r)


def test_cte_single_row_and_multi_row():
    single = proc("WITH m AS (SELECT MAX(d) AS d FROM dbo.B) SELECT a.x FROM dbo.A a, m")
    multi = proc("WITH m AS (SELECT d FROM dbo.B) SELECT a.x FROM dbo.A a, m")
    assert rules(single) == [] and rules(multi) == ["PERF-J001"]


def test_unique_key_bound_by_equality_is_single_row_with_schema(tmp_path):
    cat = catalog_from(tmp_path, "CREATE TABLE dbo.Cfg (Id int NOT NULL PRIMARY KEY, v int)")
    sql = "CREATE PROCEDURE dbo.p AS SELECT a.x, c.v FROM dbo.A a, dbo.Cfg c WHERE c.Id = 1"
    with_schema = AnalysisEngine(AnalysisOptions(catalog=cat)).analyze_text(sql, "p.sql")[0]
    without = AnalysisEngine(AnalysisOptions()).analyze_text(sql, "p.sql")[0]
    assert rules(with_schema) == []
    assert rules(without) == ["PERF-J001"]          # uniqueness is never assumed


# ---------------------------------------------------------------- ON clauses
def test_constant_true_on_is_flagged_high():
    f = finding(proc("SELECT a.x FROM dbo.A a JOIN dbo.B b ON 1 = 1"), "PERF-J003")
    assert f.severity == "HIGH" and "always true" in f.finding


def test_constant_true_on_related_in_where_is_low():
    f = finding(proc("SELECT a.x FROM dbo.A a JOIN dbo.B b ON 1 = 1 WHERE a.id = b.id"),
                "PERF-J003")
    assert f.severity == "LOW"


def test_on_1_1_combined_with_a_real_link_is_not_flagged():
    assert rules(proc("SELECT a.x FROM dbo.A a JOIN dbo.B b ON 1 = 1 AND a.id = b.id")) == []


def test_on_that_only_filters_is_not_connecting():
    f = finding(proc("SELECT a.x FROM dbo.A a JOIN dbo.B b ON b.s = @p"), "PERF-J002")
    assert f.severity == "HIGH"


def test_outer_join_link_in_where_is_medium_and_warns_about_semantics():
    f = finding(proc("SELECT a.x FROM dbo.A a LEFT JOIN dbo.B b ON a.s = 1 WHERE b.id = a.id"),
                "PERF-J002")
    assert f.severity == "MEDIUM"
    assert "Do NOT" in f.action and "unmatched rows" in f.action


def test_nested_join_tree_is_resolved_per_join():
    sql = ("SELECT a.x FROM dbo.A a LEFT JOIN (dbo.B b JOIN dbo.C c ON c.b_id = b.id) "
           "ON b.a_id = a.id")
    assert rules(proc(sql)) == []


# ---------------------------------------------------------------- OR / NOT logic
def test_or_branch_bypassing_link_in_on():
    f = finding(proc("SELECT a.x FROM dbo.A a JOIN dbo.B b ON a.id = b.id OR b.flag = 1"),
                "PERF-J005")
    assert f.severity == "HIGH" and "inside an OR" in f.finding


def test_or_where_every_branch_links_is_connected():
    assert rules(proc("SELECT a.x FROM dbo.A a JOIN dbo.B b ON a.id = b.id OR a.alt = b.id")) == []


def test_or_branch_bypass_in_where_for_comma_join():
    r = proc("SELECT a.x FROM dbo.A a, dbo.B b WHERE (a.id = b.id AND a.s = 1) OR b.s = 2")
    assert rules(r) == ["PERF-J005"]


def test_parentheses_keep_link_outside_the_or():
    r = proc("SELECT a.x FROM dbo.A a, dbo.B b WHERE a.id = b.id AND (a.s = 1 OR b.s = 2)")
    assert rules(r) == []


def test_not_over_or_is_a_conjunction():
    # NOT (x OR y) = NOT x AND NOT y: the relating predicate holds on every path
    r = proc("SELECT a.x FROM dbo.A a, dbo.B b WHERE NOT (a.id <> b.id OR a.s = 1)")
    assert rules(r) == []


def test_not_over_and_is_a_disjunction():
    # NOT (x AND y) = NOT x OR NOT y: the link can be bypassed
    r = proc("SELECT a.x FROM dbo.A a, dbo.B b WHERE NOT (a.id = b.id AND a.s = 1)")
    assert rules(r) == ["PERF-J005"]


# ---------------------------------------------------------------- self / same alias
def test_same_alias_comparison_is_flagged_without_inventing_a_column():
    r = proc("SELECT a.x FROM dbo.A a JOIN dbo.B b ON a.Id = a.Id")
    f = finding(r, "PERF-J004")
    assert "IS NOT NULL" in f.finding and "does not suggest one" in f.action
    assert "PERF-J002" in rules(r)


def test_self_join_on_two_aliases_is_not_flagged():
    assert rules(proc("SELECT a.x FROM dbo.Emp a JOIN dbo.Emp m ON m.Id = a.ManagerId")) == []


def test_unqualified_self_comparison_in_single_table_query():
    assert "PERF-J004" in rules(proc("SELECT x FROM dbo.A WHERE Id = Id"))


# ---------------------------------------------------------------- APPLY / correlation
def test_correlated_apply_is_not_flagged():
    sql = ("SELECT a.x FROM dbo.A a OUTER APPLY (SELECT b.v FROM dbo.B b "
           "WHERE b.a_id = a.id) z")
    assert rules(proc(sql)) == []


def test_uncorrelated_apply_behaves_like_cross_join():
    f = finding(proc("SELECT a.x FROM dbo.A a CROSS APPLY (SELECT b.v FROM dbo.B b) z"),
                "PERF-J006")
    assert "behaves like a CROSS JOIN" in f.finding


def test_tvf_apply_correlated_through_arguments():
    assert rules(proc("SELECT a.x FROM dbo.A a CROSS APPLY dbo.fn_Items(a.id) f")) == []
    assert "PERF-J006" in rules(proc(
        "SELECT a.x FROM dbo.A a CROSS APPLY STRING_SPLIT(@list, ',') s"))
    assert rules(proc("SELECT a.x FROM dbo.A a CROSS APPLY STRING_SPLIT(@list, ',') s "
                      "WHERE s.value = a.code")) == []


def test_correlated_subquery_sources_linked_through_outer_row():
    sql = ("SELECT a.x FROM dbo.A a WHERE a.v > (SELECT AVG(b.v) FROM dbo.B b, dbo.C c "
           "WHERE b.g = a.g AND c.g = a.g)")
    assert rules(proc(sql)) == []


def test_correlated_subquery_with_unlinked_inner_source_is_flagged():
    sql = ("SELECT a.x FROM dbo.A a WHERE EXISTS (SELECT 1 FROM dbo.B b, dbo.C c "
           "WHERE b.a_id = a.id)")
    assert rules(proc(sql)) == ["PERF-J001"]


def test_exists_relating_two_outer_sources_connects_them():
    sql = ("SELECT a.x FROM dbo.A a, dbo.B b WHERE EXISTS (SELECT 1 FROM dbo.C c "
           "WHERE c.a = a.id AND c.b = b.id)")
    assert rules(proc(sql)) == []


def test_alias_reused_in_subquery_does_not_leak():
    sql = ("SELECT c.x FROM dbo.Customer c, dbo.Orders o WHERE o.cid = c.id AND EXISTS "
           "(SELECT 1 FROM dbo.Contract c WHERE c.k = 1)")
    assert rules(proc(sql)) == []


# ---------------------------------------------------------------- DML
def test_update_target_not_in_from_is_checked():
    assert rules(proc("UPDATE dbo.T SET x = 1 FROM dbo.U u WHERE u.k = 5")) == ["PERF-J001"]
    assert rules(proc("UPDATE dbo.T SET x = 1 FROM dbo.U u WHERE u.id = T.id")) == []


def test_update_join_without_link():
    r = proc("UPDATE t SET t.x = 1 FROM dbo.T t JOIN dbo.U u ON u.k = 5")
    assert rules(r) == ["PERF-J002"]


def test_merge_on_without_relating_predicate():
    r = proc("MERGE dbo.T AS t USING dbo.S AS s ON t.k = 1 WHEN MATCHED THEN UPDATE SET x = s.x;")
    assert "PERF-J002" in rules(r)
    ok = proc("MERGE dbo.T AS t USING dbo.S AS s ON t.k = s.k WHEN MATCHED THEN UPDATE SET x = s.x;")
    assert rules(ok) == []


# ---------------------------------------------------------------- dynamic SQL
def test_dynamic_sql_findings_are_separate_and_capped():
    r = proc("DECLARE @s nvarchar(max) = N'SELECT a.x FROM dbo.A a, dbo.B b'\n"
             "EXEC sp_executesql @s")
    f = finding(r, "PERF-J001")
    assert f.origin.startswith("Dynamic SQL") and f.confidence == "MEDIUM"
    assert f.statement_id == "S2.D1"


def test_dynamic_variants_with_identical_evidence_are_merged():
    r = proc("""DECLARE @s nvarchar(max) = N'SELECT a.x FROM dbo.A a, dbo.B b WHERE a.k = 1'
IF @flag = 1 SET @s = @s + N' ORDER BY a.x'
EXEC sp_executesql @s""")
    f = finding(r, "PERF-J001")
    assert f.occurrences == 2 and f.statement_ids == ["S4.V1.D1", "S4.V2.D1"]


def test_dynamic_variants_with_different_sql_stay_separate():
    r = proc("""DECLARE @s nvarchar(max) = N'SELECT a.x FROM dbo.A a, dbo.B b WHERE a.k = 1'
IF @flag = 1 SET @s = @s + N' AND b.k = 2'
EXEC sp_executesql @s""")
    found = [f for f in r.perf_findings if f.rule_id == "PERF-J001"]
    assert sorted(f.statement_id for f in found) == ["S4.V1.D1", "S4.V2.D1"]


def test_runtime_dynamic_sql_produces_no_finding_but_is_recorded():
    r = proc("DECLARE @s nvarchar(max) = N'SELECT * FROM ' + @tbl\nEXEC (@s)")
    assert r.perf_findings == []
    assert any(d.resolution.startswith("Manual") for d in r.dynamic_sql)
