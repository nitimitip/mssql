from helpers import filters, issue_types, physical, proc, table

from models import Confidence, IssueType, Status


def test_static_dynamic_sql_is_analysed_spec_example():
    r = proc("""
        DECLARE @SQL nvarchar(max);
        SET @SQL = '
        SELECT *
        FROM Customer
        WHERE Status = ''ACTIVE''
        ';
        EXEC sp_executesql @SQL;""")
    assert r.dynamic_sql_detected
    assert physical(r) == {"Customer"}
    customer = table(r, "Customer")
    assert customer.dynamic and customer.confidence == Confidence.MEDIUM
    assert filters(r) == {"Customer.Status ="}
    assert r.filters[0].confidence == Confidence.MEDIUM and r.filters[0].dynamic
    assert r.status == Status.SUCCESS
    assert r.dynamic_sql[0].resolution.startswith("Analyzed")


def test_runtime_built_object_name_requires_manual_review_spec_example():
    r = analyze_runtime = proc("""
        DECLARE @TableName sysname, @SQL nvarchar(max), @Type varchar(10) = 'X';
        SET @TableName = 'BT_' + @Type2 + '_MASTER';
        SET @SQL = 'SELECT * FROM ' + @TableName + ' WHERE Status = @Status';
        EXEC(@SQL);""")
    assert analyze_runtime.dynamic_sql_detected
    assert r.status == Status.MANUAL_REVIEW
    assert r.confidence == Confidence.MANUAL
    assert physical(r) == set()                       # no guessed table names
    assert r.dynamic_sql[0].resolution.startswith("Manual review")
    assert "@TableName" in r.dynamic_sql[0].notes


def test_runtime_sql_from_parameter():
    from helpers import analyze
    r = analyze("""
        CREATE PROCEDURE dbo.usp_X @Type varchar(10) AS
        DECLARE @sql nvarchar(max) = N'SELECT * FROM dbo.BT_' + @Type
        EXEC sp_executesql @sql""")
    assert r.status == Status.MANUAL_REVIEW
    assert "procedure parameter" in r.dynamic_sql[0].notes


def test_literal_directly_in_exec():
    r = proc("EXEC ('DELETE FROM dbo.Staging WHERE Batch = 1')")
    assert table(r, "Staging").operations == ["DELETE"]
    assert filters(r) == {"Staging.Batch ="}


def test_sp_executesql_with_literal_and_params():
    r = proc("EXEC sp_executesql N'SELECT * FROM dbo.Orders WHERE Id = @Id', N'@Id int', @Id = 5")
    assert physical(r) == {"Orders"}


def test_conditional_appends_produce_variants():
    r = proc("""
        DECLARE @sql nvarchar(max) = N'SELECT * FROM dbo.Products p WHERE 1 = 1';
        IF @Name IS NOT NULL SET @sql = @sql + N' AND p.Name LIKE @Name';
        IF @Cat IS NOT NULL SET @sql = @sql + N' AND p.CategoryID = @Cat';
        EXEC sp_executesql @sql, N'@Name nvarchar(50), @Cat int', @Name, @Cat;""")
    assert r.dynamic_sql[0].variants == 4
    assert filters(r) == {"Products.Name LIKE", "Products.CategoryID ="}
    assert r.status == Status.SUCCESS


def test_sql_built_in_loop_is_manual_review():
    r = proc("""
        DECLARE @sql nvarchar(max) = N'';
        WHILE @i < 10 BEGIN SET @sql = @sql + N'SELECT 1; '; SET @i += 1; END
        EXEC (@sql);""")
    assert r.status == Status.MANUAL_REVIEW


def test_exec_procedure_name_variable_is_manual_review():
    r = proc("DECLARE @p sysname = 'dbo.usp_A'; EXEC @p;")
    assert r.status == Status.MANUAL_REVIEW
    assert IssueType.DYNAMIC_SQL in issue_types(r)


def test_dynamic_sql_analysis_can_be_disabled():
    r = proc("EXEC ('SELECT * FROM dbo.T')", analyze_dynamic_sql=False)
    assert physical(r) == set()
    assert r.status == Status.MANUAL_REVIEW


def test_normal_exec_is_a_procedure_call_not_dynamic_sql():
    r = proc("EXEC dbo.usp_Other @a = 1, @b = @x OUTPUT; EXECUTE usp_Third")
    assert r.procedures_called == ["dbo.usp_Other", "usp_Third"]
    assert not r.dynamic_sql_detected
    assert r.status == Status.SUCCESS
