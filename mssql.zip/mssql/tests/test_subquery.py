from helpers import filters, joins, ops, physical, proc, table

from models import Confidence, ObjectType


def test_derived_table_lineage():
    r = proc("""
        SELECT * FROM
        (SELECT CustomerID FROM Orders WHERE Status = 'OPEN') x
        JOIN Customer c ON x.CustomerID = c.CustomerID;""")
    assert physical(r) == {"Orders", "Customer"}
    assert table(r, "x").obj.object_type == ObjectType.DERIVED
    assert filters(r) == {"Orders.Status ="}
    assert joins(r) == {"Orders.CustomerID = Customer.CustomerID"}


def test_derived_table_select_star_lineage():
    r = proc("SELECT * FROM (SELECT * FROM dbo.Orders WHERE IsOpen = 1) x WHERE x.Amount > 5")
    f = next(f for f in r.filters if f.column.column == "Amount")
    assert f.column.table.name == "Orders" and f.confidence == Confidence.MEDIUM


def test_nested_and_correlated_subquery_spec_example():
    r = proc("""
        SELECT * FROM Customer c
        WHERE EXISTS (SELECT 1 FROM Orders o WHERE o.CustomerID = c.CustomerID AND o.Status = 'OPEN');""")
    assert physical(r) == {"Customer", "Orders"}
    assert "Orders.Status =" in filters(r)
    assert joins(r, "CORRELATED SUBQUERY") == {"Orders.CustomerID = Customer.CustomerID"}


def test_not_exists():
    r = proc("SELECT * FROM A a WHERE NOT EXISTS (SELECT 1 FROM B b WHERE b.AId = a.Id)")
    assert physical(r) == {"A", "B"}
    assert joins(r, "CORRELATED SUBQUERY") == {"B.AId = A.Id"}


def test_alias_shadowing_in_subquery_spec_example():
    r = proc("""
        SELECT * FROM Customer c
        WHERE EXISTS (SELECT 1 FROM Contract c WHERE c.CustomerID = 10);""")
    assert filters(r) == {"Contract.CustomerID ="}
    assert not table(r, "Customer").where_columns


def test_in_subquery_creates_semi_join():
    r = proc("SELECT * FROM dbo.A a WHERE a.k IN (SELECT b.k FROM dbo.B b WHERE b.flag = 1)")
    assert joins(r, "IN SUBQUERY") == {"A.k = B.k"}
    assert filters(r) == {"A.k IN", "B.flag ="}


def test_scalar_subquery_in_select_list_is_analysed():
    r = proc("SELECT c.Id, (SELECT COUNT(*) FROM dbo.Orders o WHERE o.CustId = c.Id) AS Cnt FROM dbo.Customer c")
    assert physical(r) == {"Customer", "Orders"}
    assert joins(r, "CORRELATED SUBQUERY") == {"Orders.CustId = Customer.Id"}
    # the outer select-list column itself is not a filter column
    assert set(table(r, "Customer").where_columns) <= {"ID"}


def test_unqualified_column_in_subquery_is_medium():
    r = proc("SELECT * FROM dbo.A a WHERE EXISTS (SELECT 1 FROM dbo.B WHERE Flag = 1)")
    f = r.filters[0]
    assert f.column.table.name == "B" and f.confidence == Confidence.MEDIUM


def test_union_and_union_all_branches():
    r = proc("""
        SELECT a.Id FROM dbo.TableA a WHERE a.X = 1
        UNION
        SELECT b.Id FROM dbo.TableB b JOIN dbo.TableC c ON c.BId = b.Id WHERE b.Y = 2
        UNION ALL
        SELECT d.Id FROM dbo.TableD d WHERE d.Z = 3""")
    assert physical(r) == {"TableA", "TableB", "TableC", "TableD"}
    assert filters(r) == {"TableA.X =", "TableB.Y =", "TableD.Z ="}
    assert joins(r) == {"TableC.BId = TableB.Id"}


def test_cross_apply_and_outer_apply():
    r = proc("""
        SELECT * FROM dbo.Customer c
        CROSS APPLY (SELECT TOP 1 o.Amount FROM dbo.Orders o WHERE o.CustomerID = c.CustomerID ORDER BY o.Dt DESC) lo
        OUTER APPLY dbo.fn_Flags(c.CustomerID) f
        WHERE c.Active = 1""")
    assert physical(r) == {"Customer", "Orders"}
    assert ops(r, "Orders") == {"SELECT", "APPLY"}
    assert ops(r, "fn_Flags") == {"SELECT", "APPLY"}
    assert joins(r, "CORRELATED SUBQUERY") == {"Orders.CustomerID = Customer.CustomerID"}
    assert "Customer.Active =" in filters(r)


def test_pivot_source_tables_are_found():
    r = proc("""
        SELECT * FROM (SELECT Region, Qty FROM dbo.Sales WHERE Yr = 2024) s
        PIVOT (SUM(Qty) FOR Region IN ([North], [South])) p""")
    assert physical(r) == {"Sales"}
    assert filters(r) == {"Sales.Yr ="}
