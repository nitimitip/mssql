"""Commented-out SQL never becomes a dependency; GO lines may carry comments."""
from helpers import analyze, filters, physical, proc

from analyzer.engine import AnalysisEngine
from models import IssueType, Status


def test_commented_join_and_where_inside_a_statement():
    r = proc("""
        SELECT * FROM Real r
        -- JOIN FakeLine f ON f.id = r.id
        /* JOIN FakeBlock b ON b.id = r.id */
        WHERE r.x = 1 -- AND r.y = 2""")
    assert physical(r) == {"Real"}
    assert filters(r) == {"Real.x ="}


def test_commented_dml_and_cte_parts():
    r = proc("""
        --DELETE FROM F1
        /*UPDATE F2 SET a = 1*/
        ;WITH a AS (SELECT * FROM Real)
        --, b AS (SELECT * FROM Fake)
        SELECT * FROM a""")
    assert physical(r) == {"Real"}


def test_comment_markers_inside_strings_and_brackets_are_data():
    r = proc("SELECT '--x' AS a, '/*y' AS b FROM [Real--Tbl] WHERE Note = '*/'")
    assert physical(r) == {"Real--Tbl"}


def test_block_comment_without_spaces_and_line_comment_at_eof():
    r = analyze("CREATE PROCEDURE dbo.p AS SELECT * FROM/*Fake*/Real -- JOIN Fake2 ON 1 = 1")
    assert physical(r) == {"Real"}


def test_commented_out_old_procedure_is_not_analysed():
    r = analyze("/*\nCREATE PROCEDURE dbo.usp_Old AS SELECT * FROM Fake\n*/\n"
                "-- CREATE PROCEDURE dbo.usp_Old2 AS SELECT * FROM Fake2\n"
                "CREATE PROCEDURE dbo.usp_New AS SELECT * FROM Real")
    assert r.name == "usp_New" and physical(r) == {"Real"}


def test_comments_inside_dynamic_sql_text():
    r = proc("DECLARE @s nvarchar(max) = N'/* SELECT * FROM DynFake */ SELECT * FROM DynReal "
             "-- JOIN DynFake2 ON 1 = 1'\nEXEC sp_executesql @s")
    assert physical(r) == {"DynReal"}


def test_unterminated_block_comment_fails_the_file_only():
    results = AnalysisEngine().analyze_text("CREATE PROCEDURE dbo.p AS SELECT * FROM T /* oops",
                                            "p.sql")
    assert [r.status for r in results] == [Status.FAILED]
    assert results[0].issues[0].issue_type == IssueType.PARSING_FAILURE


def test_go_followed_by_comments_separates_batches():
    for go_line in ("GO /* end of usp_A */", "GO -- end", "GO 2 -- twice", "/* x */ GO",
                    "GO /* starts here\n   and ends here */"):
        sql = (f"CREATE PROCEDURE dbo.usp_A AS SELECT * FROM TA\n{go_line}\n"
               f"CREATE PROCEDURE dbo.usp_B AS SELECT * FROM TB\n")
        results = AnalysisEngine().analyze_text(sql, "t.sql")
        assert [r.name for r in results] == ["usp_A", "usp_B"], go_line
        assert [physical(r) for r in results] == [{"TA"}, {"TB"}], go_line
        assert all(r.status == Status.SUCCESS for r in results), go_line


def test_commented_go_is_not_a_separator():
    r = analyze("CREATE PROCEDURE dbo.p AS\n-- GO\nSELECT * FROM Real")
    assert physical(r) == {"Real"}
