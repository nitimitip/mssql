"""Helpers for the performance-review tests."""
from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Optional

from analyzer.engine import AnalysisEngine
from analyzer.options import AnalysisOptions, PerformanceOptions
from analyzer.schema_catalog import load_schema_catalog
from config import SummaryOptions
from models import ProcedureAnalysis
from reports.performance_builder import PerformanceBuilder
from reports.summary_builder import mark_duplicate_procedures


def rules(result: ProcedureAnalysis) -> List[str]:
    return sorted(f.rule_id for f in result.perf_findings)


def finding(result: ProcedureAnalysis, rule_id: str):
    matches = [f for f in result.perf_findings if f.rule_id == rule_id]
    assert len(matches) == 1, f"{rule_id}: {[f.rule_id for f in result.perf_findings]}"
    return matches[0]


def catalog_from(tmp_path: Path, ddl: str = "", metadata: Optional[str] = None):
    folder = tmp_path / "schema"
    folder.mkdir(exist_ok=True)
    (folder / "schema.sql").write_text(ddl, encoding="utf-8")
    if metadata is not None:
        (folder / "table_metadata.csv").write_text(metadata, encoding="utf-8")
    return load_schema_catalog(folder)


def analyze_many(sources: Dict[str, str], catalog=None,
                 performance: Optional[PerformanceOptions] = None) -> List[ProcedureAnalysis]:
    options = AnalysisOptions(catalog=catalog, performance=performance or PerformanceOptions())
    engine = AnalysisEngine(options)
    analyses = [a for name, sql in sources.items() for a in engine.analyze_text(sql, name)]
    mark_duplicate_procedures(analyses)
    return analyses


def builder(analyses, catalog=None, performance: Optional[PerformanceOptions] = None):
    return PerformanceBuilder(analyses, SummaryOptions(), performance or PerformanceOptions(),
                              catalog)


def sp(name: str, body: str) -> str:
    return f"CREATE PROCEDURE dbo.{name}\nAS\nBEGIN\n{body}\nEND\n"
