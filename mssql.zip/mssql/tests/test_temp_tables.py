from config import SummaryOptions
from helpers import joins, ops, physical, proc, table
from reports.summary_builder import SummaryBuilder

from models import ObjectType


def test_temp_table_reuse():
    r = proc("""
        SELECT Id, Name INTO #Temp FROM dbo.TableA WHERE Active = 1;
        UPDATE #Temp SET Name = 'x' WHERE Id = 3;
        SELECT * FROM #Temp t JOIN dbo.TableB b ON t.ID = b.ID;
        DROP TABLE #Temp;""")
    temp = table(r, "#Temp")
    assert temp.obj.object_type == ObjectType.TEMP_TABLE
    assert set(temp.operations) == {"SELECT INTO", "UPDATE", "SELECT", "DROP"}
    assert joins(r) == {"#Temp.ID = TableB.ID"}
    assert physical(r) == {"TableA", "TableB"}


def test_global_temp_table():
    r = proc("CREATE TABLE ##Shared (Id int); INSERT INTO ##Shared SELECT Id FROM dbo.Src")
    assert table(r, "##Shared").obj.object_type == ObjectType.GLOBAL_TEMP_TABLE
    assert ops(r, "##Shared") == {"CREATE", "INSERT"}


def test_table_variable():
    r = proc("""
        DECLARE @Customers TABLE (CustomerID INT PRIMARY KEY, Status INT);
        INSERT INTO @Customers SELECT CustomerID, Status FROM dbo.Customer;
        SELECT * FROM @Customers x JOIN dbo.Orders o ON o.CustomerID = x.CustomerID WHERE x.Status = 1;""")
    tv = table(r, "@Customers")
    assert tv.obj.object_type == ObjectType.TABLE_VARIABLE
    assert {"DECLARE", "INSERT", "SELECT"} <= set(tv.operations)
    assert physical(r) == {"Customer", "Orders"}
    assert len(r.table_variables) == 1


def test_temp_tables_and_table_variables_excluded_from_summary_by_default():
    r = proc("""
        DECLARE @t TABLE (Id int);
        SELECT * INTO #x FROM dbo.Real;
        INSERT INTO @t SELECT Id FROM #x;""")
    names = {row.name for row in SummaryBuilder([r], SummaryOptions()).table_rows()}
    assert names == {"Real"}
    names_all = {row.name for row in SummaryBuilder(
        [r], SummaryOptions(include_temp_tables=True, include_table_variables=True)).table_rows()}
    assert names_all == {"Real", "#x", "@t"}
