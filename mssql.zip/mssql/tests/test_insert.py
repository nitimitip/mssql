from helpers import filters, ops, physical, proc, table

from models import ObjectType


def test_insert_values():
    r = proc("INSERT INTO dbo.AuditLog (EventType, EventDate) VALUES ('X', GETDATE()), ('Y', GETDATE())")
    assert physical(r) == {"AuditLog"}
    assert ops(r, "AuditLog") == {"INSERT"}
    assert r.filters == [] and r.joins == []


def test_insert_select_spec_example():
    r = proc("""
        INSERT INTO Customer (CustomerName, Email, Status)
        SELECT Name, EmailAddress, 1
        FROM StagingCustomer
        WHERE IsValid = 1;""")
    assert ops(r, "Customer") == {"INSERT"}
    assert ops(r, "StagingCustomer") == {"SELECT"}
    assert filters(r) == {"StagingCustomer.IsValid ="}
    # insert column list / select list columns are not reported
    assert not table(r, "Customer").where_columns
    assert set(table(r, "StagingCustomer").where_columns) == {"ISVALID"}


def test_insert_without_into_keyword():
    r = proc("INSERT dbo.T (A) SELECT A FROM dbo.S")
    assert ops(r, "T") == {"INSERT"}
    assert ops(r, "S") == {"SELECT"}


def test_insert_exec():
    r = proc("INSERT INTO #Results EXEC dbo.usp_GetResults @Id = 5")
    assert ops(r, "#Results") == {"INSERT"}
    assert r.procedures_called == ["dbo.usp_GetResults"]


def test_select_into_creates_temp_table():
    r = proc("SELECT * INTO #CustomerTemp FROM Customer WHERE Status = 'ACTIVE';")
    temp = table(r, "#CustomerTemp")
    assert temp.obj.object_type == ObjectType.TEMP_TABLE
    assert temp.operations == ["SELECT INTO"]
    assert ops(r, "Customer") == {"SELECT"}
    assert filters(r) == {"Customer.Status ="}
    assert physical(r) == {"Customer"}


def test_output_into_records_insert():
    r = proc("""
        DELETE FROM dbo.Queue OUTPUT deleted.Id, deleted.Payload INTO dbo.QueueArchive (Id, Payload)
        WHERE Processed = 1""")
    assert ops(r, "Queue") == {"DELETE"}
    assert ops(r, "QueueArchive") == {"INSERT"}


def test_insert_with_cte():
    r = proc("""
        WITH src AS (SELECT Id FROM dbo.Source WHERE Ready = 1)
        INSERT INTO dbo.Target (Id) SELECT Id FROM src""")
    assert ops(r, "Target") == {"INSERT"}
    assert ops(r, "Source") == {"SELECT"}
    assert physical(r) == {"Target", "Source"}
