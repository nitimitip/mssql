from pathlib import Path

from helpers import analyze, filters, issue_types, physical, proc, table

from analyzer.engine import AnalysisEngine
from models import Confidence, IssueType, Status


def test_procedure_name_forms():
    for header, schema, name in [
        ("CREATE PROCEDURE dbo.usp_GetEnquiry", "dbo", "usp_GetEnquiry"),
        ("CREATE PROC usp_GetEnquiry", None, "usp_GetEnquiry"),
        ("ALTER PROCEDURE [dbo].[usp_GetEnquiry]", "dbo", "usp_GetEnquiry"),
        ("ALTER PROC usp_GetEnquiry", None, "usp_GetEnquiry"),
        ("CREATE OR ALTER PROCEDURE sales.usp_GetEnquiry", "sales", "usp_GetEnquiry"),
    ]:
        r = analyze(f"{header} @a int = 1, @b varchar(10) OUTPUT AS SELECT 1 FROM T")
        assert (r.schema, r.name) == (schema, name), header
        assert r.parameters == ["@a", "@b"]


def test_procedure_with_options_and_parenthesised_params():
    r = analyze("CREATE PROCEDURE dbo.p (@a int, @b nvarchar(max) = N'x') WITH RECOMPILE, EXECUTE AS OWNER AS SELECT * FROM T")
    assert r.parameters == ["@a", "@b"]
    assert physical(r) == {"T"}


def test_go_batches_and_preamble():
    r = analyze("""
SET ANSI_NULLS ON
GO
IF OBJECT_ID('dbo.usp_A') IS NOT NULL DROP PROCEDURE dbo.usp_A
GO
CREATE PROCEDURE dbo.usp_A AS SELECT * FROM dbo.T
GO
GRANT EXECUTE ON dbo.usp_A TO SomeRole
GO""")
    assert r.full_name == "dbo.usp_A"
    assert physical(r) == {"T"}
    assert r.status == Status.SUCCESS


def test_control_flow_if_else_while_try_catch_cursor():
    r = proc("""
        IF EXISTS (SELECT 1 FROM dbo.Flags WHERE Code = 'X')
            UPDATE dbo.A SET V = 1 WHERE Id = 1
        ELSE IF @p = 2
        BEGIN
            DELETE FROM dbo.B WHERE Id = 2
        END
        ELSE
            INSERT INTO dbo.C (Id) VALUES (3)
        BEGIN TRY
            DECLARE cur CURSOR LOCAL FAST_FORWARD FOR SELECT o.Id FROM dbo.Orders o WHERE o.Done = 0
            OPEN cur
            FETCH NEXT FROM cur INTO @Id
            WHILE @@FETCH_STATUS = 0
            BEGIN
                UPDATE dbo.Orders SET Done = 1 WHERE Id = @Id
                FETCH NEXT FROM cur INTO @Id
            END
            CLOSE cur DEALLOCATE cur
        END TRY
        BEGIN CATCH
            IF @@TRANCOUNT > 0 ROLLBACK
            ;THROW
        END CATCH""")
    assert physical(r) == {"Flags", "A", "B", "C", "Orders"}
    assert set(table(r, "Orders").operations) == {"SELECT", "UPDATE"}
    assert "Flags.Code =" in filters(r)
    assert r.status == Status.SUCCESS


def test_malformed_statement_is_reported_not_guessed():
    r = proc("""
        SELECT a.Col1 FROM dbo.GoodTable a WHERE a.Flag = 1;
        SELECT * FROM dbo.BrokenTable WHERE = 5;
        UPDATE dbo.GoodTable SET Flag = 0 WHERE Flag = 1;""")
    assert physical(r) == {"GoodTable"}                 # BrokenTable only via token scan
    broken = table(r, "BrokenTable")
    assert broken.fallback_only and broken.confidence == Confidence.LOW
    assert r.statements_failed == 1
    assert IssueType.UNSUPPORTED_SYNTAX in issue_types(r)
    assert r.status == Status.PARTIAL


def test_unsupported_statement_is_partial():
    r = proc("SELECT * FROM dbo.T; FROBNICATE dbo.T WITH VIGOUR; SELECT * FROM dbo.U")
    assert physical(r) == {"T", "U"}
    assert r.status == Status.PARTIAL


def test_tokenizer_failure_is_failed_status():
    r = analyze("CREATE PROCEDURE dbo.p AS SELECT 'unterminated FROM T")
    assert r.status == Status.FAILED
    assert IssueType.PARSING_FAILURE in issue_types(r)


def test_all_statements_unparseable_is_failed():
    r = proc("SELECT FROM WHERE = = ;")
    assert r.status == Status.FAILED


def test_missing_procedure_definition_is_analysed_as_script():
    results = AnalysisEngine().analyze_text("SELECT * FROM dbo.T WHERE x = 1", "adhoc.sql")
    r = results[0]
    assert r.name == "adhoc"
    assert physical(r) == {"T"}
    assert IssueType.MISSING_SP_DEFINITION in issue_types(r)
    assert r.status == Status.PARTIAL


def test_multiple_procedures_in_one_file():
    results = AnalysisEngine().analyze_text(
        "CREATE PROC dbo.a AS SELECT * FROM T1\nGO\nCREATE PROC dbo.b AS SELECT * FROM T2\nGO", "two.sql")
    assert [(r.name, physical(r)) for r in results] == [("a", {"T1"}), ("b", {"T2"})]


def test_unterminated_begin_block_is_partial_but_analysed():
    r = analyze("CREATE PROCEDURE dbo.p AS BEGIN SELECT * FROM dbo.T WHERE x = 1")
    assert physical(r) == {"T"}
    assert r.status == Status.PARTIAL


def test_statements_without_semicolons():
    r = proc("""
        SELECT a FROM dbo.T1 t
        SELECT b FROM dbo.T2
        UPDATE dbo.T3 SET c = 1
        SET @x = (SELECT MAX(d) FROM dbo.T4 WHERE e = 1)
        RETURN""")
    assert physical(r) == {"T1", "T2", "T3", "T4"}
    assert table(r, "T1").aliases == ["t"]
    assert filters(r) == {"T4.e ="}


def test_encodings(tmp_path: Path):
    sql = "CREATE PROCEDURE dbo.p AS SELECT * FROM dbo.Café WHERE x = 1"
    engine = AnalysisEngine()
    variants = {
        "utf8.sql": sql.encode("utf-8"),
        "utf8bom.sql": b"\xef\xbb\xbf" + sql.encode("utf-8"),
        "utf16.sql": b"\xff\xfe" + sql.encode("utf-16-le"),
        "cp1252.sql": sql.encode("cp1252"),
    }
    for name, data in variants.items():
        (tmp_path / name).write_bytes(data)
        r = engine.analyze_file(tmp_path / name)[0]
        assert physical(r) == {"Café"}, name
        assert r.status == Status.SUCCESS, name


def test_unreadable_file_is_failed(tmp_path: Path):
    r = AnalysisEngine().analyze_file(tmp_path / "missing.sql")[0]
    assert r.status == Status.FAILED


def test_window_functions_and_misc_syntax():
    r = proc("""
        SELECT ROW_NUMBER() OVER (PARTITION BY o.CustId ORDER BY o.Dt DESC) AS rn,
               STRING_AGG(o.Code, ',') WITHIN GROUP (ORDER BY o.Code),
               CONVERT(varchar(10), o.Dt, 120), CAST(o.Amt AS decimal(10, 2)),
               IIF(o.Amt > 0, 1, 0), o.Dt AT TIME ZONE 'UTC'
        FROM dbo.Orders o
        WHERE o.Dt >= DATEADD(month, -1, SYSDATETIME()) AND o.Name COLLATE Latin1_General_CI_AS = @n
        ORDER BY o.Dt OFFSET 10 ROWS FETCH NEXT 10 ROWS ONLY
        OPTION (RECOMPILE)""")
    assert filters(r) == {"Orders.Dt >=", "Orders.Name ="}
    assert r.status == Status.SUCCESS
