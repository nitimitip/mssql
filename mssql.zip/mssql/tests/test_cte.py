from helpers import filters, issue_types, joins, physical, proc, table

from models import Confidence, IssueType, ObjectType, Status


def test_cte_is_not_a_physical_table_and_lineage_resolves():
    r = proc("""
        WITH LatestStatus AS
        (
            SELECT hist_internalref, MAX(hist_datecreated) AS LastDate
            FROM BT_ACT_HIST
            WHERE hist_columnname = 'AE_status'
            GROUP BY hist_internalref
        )
        SELECT * FROM LatestStatus l
        JOIN BT_ENQUIRY_MASTER e ON l.hist_internalref = e.ae_internalref;""")
    assert physical(r) == {"BT_ACT_HIST", "BT_ENQUIRY_MASTER"}
    assert table(r, "LatestStatus").obj.object_type == ObjectType.CTE
    assert joins(r) == {"BT_ACT_HIST.hist_internalref = BT_ENQUIRY_MASTER.ae_internalref"}
    j = r.joins[0]
    assert j.left[0].confidence == Confidence.MEDIUM
    assert "via CTE LatestStatus" in j.left[0].note
    assert filters(r) == {"BT_ACT_HIST.hist_columnname ="}
    assert r.status == Status.SUCCESS


def test_cte_computed_column_is_reported_as_cte_derived_low():
    r = proc("""
        WITH L AS (SELECT k, MAX(d) AS LastDate FROM dbo.H GROUP BY k)
        SELECT * FROM L JOIN dbo.E e ON e.k = L.k WHERE L.LastDate > @x""")
    f = next(f for f in r.filters if f.column.column == "LastDate")
    assert f.column.table is None
    assert f.column.owner_label == "CTE L"
    assert f.confidence == Confidence.LOW
    assert "MAX(dbo.H.d)" in f.column.note
    assert r.status == Status.PARTIAL


def test_multiple_dependent_ctes():
    r = proc("""
        WITH A AS (SELECT Id, Val FROM dbo.Base WHERE Active = 1),
             B AS (SELECT a.Id, a.Val FROM A a WHERE a.Val > 0),
             C AS (SELECT b.Id FROM B b JOIN dbo.Other o ON o.Id = b.Id)
        SELECT * FROM C c JOIN dbo.Final f ON f.Id = c.Id""")
    assert physical(r) == {"Base", "Other", "Final"}
    assert "Other.Id = Base.Id" in joins(r)
    assert "Final.Id = Base.Id" in joins(r)
    assert filters(r) == {"Base.Active =", "Base.Val >"}


def test_cte_with_column_list():
    r = proc("""
        WITH X (CustId, Amt) AS (SELECT CustomerID, Amount FROM dbo.Orders)
        SELECT * FROM X JOIN dbo.Customer c ON c.CustomerID = X.CustId""")
    assert joins(r) == {"Customer.CustomerID = Orders.CustomerID"}


def test_recursive_cte_detected():
    r = proc("""
        WITH Org (EmpID, MgrID) AS (
            SELECT e.EmpID, e.MgrID FROM dbo.Employee e WHERE e.MgrID IS NULL
            UNION ALL
            SELECT e.EmpID, e.MgrID FROM dbo.Employee e JOIN Org o ON e.MgrID = o.EmpID
        )
        SELECT * FROM Org""")
    assert physical(r) == {"Employee"}
    assert IssueType.RECURSIVE_CTE in issue_types(r)
    assert r.status == Status.PARTIAL


def test_cte_name_shadowing_a_table_name():
    r = proc("""
        WITH Customer AS (SELECT Id FROM dbo.CustomerArchive)
        SELECT * FROM Customer WHERE Id = 1""")
    assert physical(r) == {"CustomerArchive"}
    assert filters(r) == {"CustomerArchive.Id ="}
