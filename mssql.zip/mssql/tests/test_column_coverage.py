"""SELECT / SET / GROUP BY / ORDER BY column usage."""
from pathlib import Path

import openpyxl
from helpers import issue_types, proc, table

from analyzer.engine import AnalysisEngine
from config import AppConfig, SummaryOptions
from models import IssueType, Severity, Status
from reports.excel_report import ExcelReportWriter
from reports.summary_builder import SummaryBuilder


def cols(result, name: str, clause: str) -> set:
    return set(table(result, name).columns_for(clause).values())


def test_select_group_by_order_by_columns():
    r = proc("""
        SELECT c.Name, SUM(o.Amt) AS Total
        FROM Customer c JOIN Orders o ON o.CustId = c.Id
        GROUP BY c.Name, c.Region
        ORDER BY c.Region""")
    assert cols(r, "Customer", "SELECT") == {"Name"}
    assert cols(r, "Orders", "SELECT") == {"Amt"}
    assert cols(r, "Customer", "GROUP BY") == {"Name", "Region"}
    assert cols(r, "Customer", "ORDER BY") == {"Region"}
    # clauses stay separate: JOIN columns are not reported as SELECT columns
    assert cols(r, "Customer", "JOIN") == {"Id"}


def test_order_by_alias_and_ordinal_bind_to_select_list():
    r = proc("SELECT o.Dt, SUM(o.Amt) AS Total FROM Orders o GROUP BY o.Dt ORDER BY Total DESC, 1")
    assert cols(r, "Orders", "ORDER BY") == {"Amt", "Dt"}
    assert IssueType.AMBIGUOUS_COLUMN not in issue_types(r)
    assert not r.unresolved


def test_order_by_of_union_follows_output_columns():
    r = proc("SELECT a.x AS v FROM A a UNION SELECT b.y FROM B b ORDER BY v")
    assert cols(r, "A", "ORDER BY") == {"x"}
    assert cols(r, "B", "ORDER BY") == {"y"}


def test_window_partition_and_order_columns_count_as_select():
    r = proc("SELECT ROW_NUMBER() OVER (PARTITION BY o.Region ORDER BY o.Dt DESC "
             "ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS rn FROM Orders o")
    assert cols(r, "Orders", "SELECT") == {"Region", "Dt"}
    assert r.status == Status.SUCCESS


def test_select_star_is_recorded_but_not_inside_exists():
    r = proc("""
        SELECT * FROM A a JOIN B b ON a.id = b.id;
        SELECT c.* FROM C c WHERE EXISTS (SELECT * FROM D WHERE D.id = c.id)""")
    assert cols(r, "A", "SELECT") == {"*"} and cols(r, "B", "SELECT") == {"*"}
    assert cols(r, "C", "SELECT") == {"*"}
    assert cols(r, "D", "SELECT") == set()


def test_select_through_cte_and_subqueries():
    r = proc("""
        ;WITH x AS (SELECT a.k, COUNT(*) AS n FROM A a GROUP BY a.k)
        SELECT x.k, x.n, (SELECT MAX(b.v) FROM B b WHERE b.k = x.k) AS mv FROM x""")
    assert cols(r, "A", "SELECT") == {"k"}
    assert cols(r, "A", "GROUP BY") == {"k"}
    assert cols(r, "B", "SELECT") == {"v"}          # scalar subquery's own select list
    assert not r.unresolved                          # computed CTE column n is not a gap


def test_update_set_target_and_value_columns():
    r = proc("""
        UPDATE o SET Status = c.Status, o.Amt = o.Amt * 2, @last = c.Id
        FROM Orders o JOIN Customer c ON c.Id = o.CustId""")
    # the unqualified target column belongs to the UPDATE target, not Customer
    assert cols(r, "Orders", "SET") == {"Status", "Amt"}
    assert cols(r, "Customer", "SET") == {"Status", "Id"}
    assert r.status == Status.SUCCESS


def test_merge_update_set_columns():
    r = proc("""
        MERGE Tgt t USING Src s ON t.Id = s.Id
        WHEN MATCHED THEN UPDATE SET Val = s.Val
        WHEN NOT MATCHED THEN INSERT (Id, Val) VALUES (s.Id, s.Val);""")
    assert cols(r, "Tgt", "SET") == {"Val"}
    assert cols(r, "Src", "SET") == {"Val"}


def test_dynamic_sql_columns_are_recorded():
    r = proc("DECLARE @s nvarchar(max) = N'SELECT d.Col FROM Dyn d ORDER BY d.Col2'\nEXEC (@s)")
    assert cols(r, "Dyn", "SELECT") == {"Col"}
    assert cols(r, "Dyn", "ORDER BY") == {"Col2"}


def test_ambiguous_select_column_is_info_only():
    r = proc("SELECT Name FROM A JOIN B ON A.id = B.id")
    assert [(u.clause, u.ref.candidates) for u in r.unresolved] == [("SELECT", ("A", "B"))]
    assert [i.severity for i in r.issues if i.issue_type == IssueType.AMBIGUOUS_COLUMN] \
        == [Severity.INFO]
    assert r.status == Status.SUCCESS


def test_column_usage_rows_and_sheet(tmp_path: Path):
    engine = AnalysisEngine()
    analyses = (engine.analyze_text("CREATE PROCEDURE dbo.p1 AS SELECT t.a FROM dbo.T t "
                                    "WHERE t.a = 1 ORDER BY t.b", "p1.sql")
                + engine.analyze_text("CREATE PROCEDURE dbo.p2 AS UPDATE dbo.T SET a = 2",
                                      "p2.sql"))
    rows = {r.column: r for r in SummaryBuilder(analyses, SummaryOptions()).column_rows()}
    assert (rows["a"].clause_count("SELECT"), rows["a"].clause_count("WHERE"),
            rows["a"].clause_count("SET"), len(rows["a"].procedures)) == (1, 1, 1, 2)
    assert rows["b"].clause_count("ORDER BY") == 1

    cfg = AppConfig(config_file=None, input_directory=tmp_path, output_directory=tmp_path,
                    log_directory=tmp_path)
    path = ExcelReportWriter(cfg).write(analyses, tmp_path / "r.xlsx", {})
    ws = openpyxl.load_workbook(path)["Column Usage"]
    header = [c.value for c in ws[5]]
    for label in ("SELECT", "JOIN", "WHERE", "GROUP BY", "HAVING", "ORDER BY", "SET"):
        assert f"{label} SP Count" in header
