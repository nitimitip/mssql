from helpers import analyze, filter_columns, filters, joins, ops, physical, proc, table

from models import Confidence, ObjectType, Status


def test_simple_select():
    r = proc("SELECT CustomerID, Name FROM Customer WHERE Status = 'A';")
    assert physical(r) == {"Customer"}
    assert ops(r, "Customer") == {"SELECT"}
    assert filters(r) == {"Customer.Status ="}
    assert r.status == Status.SUCCESS


def test_select_list_columns_are_not_reported():
    r = proc("""
        SELECT c.CustomerID, c.Name, o.Amount
        FROM Customer c LEFT JOIN Orders o ON c.CustomerID = o.CustomerID
        WHERE c.Status = 'ACTIVE' AND o.OrderDate >= @StartDate;""")
    assert physical(r) == {"Customer", "Orders"}
    assert joins(r) == {"Customer.CustomerID = Orders.CustomerID"}
    assert filter_columns(r) == {"Customer.Status", "Orders.OrderDate"}
    customer = table(r, "Customer")
    assert set(customer.join_columns) == {"CUSTOMERID"}
    assert set(customer.where_columns) == {"STATUS"}
    assert "NAME" not in customer.where_columns and "NAME" not in customer.join_columns
    assert "AMOUNT" not in table(r, "Orders").where_columns


def test_spec_example_89():
    r = analyze("""
CREATE PROCEDURE dbo.usp_GetActiveEnquiries @StartDate datetime AS
BEGIN
    SELECT e.ae_internalref, h.hist_descr
    FROM BT_ENQUIRY_MASTER e
    LEFT JOIN BT_ACT_HIST h ON e.ae_internalref = h.hist_internalref AND h.hist_columnname = 'AE_status'
    LEFT JOIN MT_SYS_LOV l ON h.hist_descr = l.lov_desc
    WHERE e.AE_status IS NULL AND e.ae_datecreated >= @StartDate AND l.LOV_NAME = 'sysStatusEnquiry';
END;""")
    assert (r.schema, r.name, r.full_name) == ("dbo", "usp_GetActiveEnquiries", "dbo.usp_GetActiveEnquiries")
    assert ops(r, "BT_ENQUIRY_MASTER") == {"SELECT"}
    assert ops(r, "BT_ACT_HIST") == {"SELECT", "JOIN"}
    assert ops(r, "MT_SYS_LOV") == {"SELECT", "JOIN"}
    assert table(r, "BT_ACT_HIST").aliases == ["h"]
    assert set(table(r, "BT_ACT_HIST").join_columns.values()) == {
        "hist_internalref", "hist_columnname", "hist_descr"}
    assert joins(r) == {
        "BT_ENQUIRY_MASTER.ae_internalref = BT_ACT_HIST.hist_internalref",
        "BT_ACT_HIST.hist_columnname = 'AE_status'",
        "BT_ACT_HIST.hist_descr = MT_SYS_LOV.lov_desc",
    }
    assert filters(r) == {
        "BT_ENQUIRY_MASTER.AE_status IS NULL",
        "BT_ENQUIRY_MASTER.ae_datecreated >=",
        "MT_SYS_LOV.LOV_NAME =",
    }
    assert all(j.confidence == Confidence.HIGH for j in r.joins)
    assert r.status == Status.SUCCESS and r.confidence == Confidence.HIGH


def test_schema_and_database_qualified_names():
    r = proc("""
        SELECT * FROM dbo.Customer c
        JOIN SalesDB.sales.OrderDetails d ON d.CustomerID = c.CustomerID
        JOIN SalesDB..Region g ON g.RegionID = c.RegionID""")
    c = table(r, "Customer")
    assert (c.obj.database, c.obj.schema) == (None, "dbo")
    d = table(r, "OrderDetails")
    assert (d.obj.database, d.obj.schema) == ("SalesDB", "sales")
    g = table(r, "Region")
    assert (g.obj.database, g.obj.schema) == ("SalesDB", None)


def test_bracketed_identifiers_with_spaces():
    r = proc("""
        SELECT * FROM [dbo].[Order Details] od
        JOIN [Order] o ON o.[Order ID] = od.[Order ID]
        WHERE od.[Line Status] = 'OPEN'""")
    assert physical(r) == {"Order Details", "Order"}
    assert table(r, "Order Details").obj.display_name == "dbo.[Order Details]"
    assert joins(r) == {"Order.Order ID = Order Details.Order ID"}
    assert filters(r) == {"Order Details.Line Status ="}


def test_quoted_identifier_double_quotes():
    r = proc('SELECT * FROM "dbo"."Customer" c WHERE c."Status" = 1')
    assert filters(r) == {"Customer.Status ="}


def test_same_table_with_multiple_aliases():
    r = proc("""
        SELECT * FROM Employee e
        JOIN Employee m ON e.ManagerID = m.EmployeeID
        WHERE m.Active = 1""")
    emp = table(r, "Employee")
    assert sorted(emp.aliases) == ["e", "m"]
    assert joins(r) == {"Employee.ManagerID = Employee.EmployeeID"}
    assert filters(r) == {"Employee.Active ="}


def test_comments_containing_sql_are_ignored():
    r = proc("""
        -- SELECT * FROM FakeLineComment
        /* SELECT * FROM FakeBlockComment
           /* nested */ JOIN FakeNested ON 1 = 1 */
        SELECT * FROM RealTable""")
    assert physical(r) == {"RealTable"}


def test_string_literals_containing_sql_are_ignored():
    r = proc("""
        PRINT 'SELECT * FROM FakePrinted';
        SELECT 'DELETE FROM FakeDeleted' AS txt FROM RealTable WHERE Note = 'FROM FakeWhere';""")
    assert physical(r) == {"RealTable"}
    assert r.dynamic_sql == []


def test_select_without_from_and_variable_assignment():
    r = proc("DECLARE @x int; SELECT @x = 1; SELECT @x = MAX(Id) FROM dbo.T WHERE Flag = 1;")
    assert physical(r) == {"T"}
    assert filters(r) == {"T.Flag ="}


def test_view_prefix_classified_as_view():
    r = proc("SELECT * FROM dbo.vw_CustomerOrders v WHERE v.Id = 1")
    assert table(r, "vw_CustomerOrders").obj.object_type == ObjectType.VIEW


def test_unknown_object_type_configurable():
    r = proc("SELECT * FROM dbo.Thing", unknown_object_type=ObjectType.UNKNOWN)
    assert table(r, "Thing").obj.object_type == ObjectType.UNKNOWN


def test_table_valued_function_is_not_a_table():
    r = proc("SELECT * FROM dbo.fn_GetItems(@Id) f WHERE f.Active = 1")
    assert physical(r) == set()
    assert table(r, "fn_GetItems").obj.object_type == ObjectType.TABLE_FUNCTION
    assert "dbo.fn_GetItems" in r.functions_called
