"""Small helpers that turn analysis results into plain sets for assertions."""
from __future__ import annotations

from typing import Optional, Set

from analyzer.engine import AnalysisEngine
from analyzer.options import AnalysisOptions
from models import ObjectType, ProcedureAnalysis, TableUsage


def analyze(sql: str, **options) -> ProcedureAnalysis:
    results = AnalysisEngine(AnalysisOptions(**options)).analyze_text(sql, "test.sql")
    assert len(results) == 1, f"expected one procedure, got {len(results)}"
    return results[0]


def proc(body: str, **options) -> ProcedureAnalysis:
    return analyze(f"CREATE PROCEDURE dbo.usp_Test\nAS\nBEGIN\n{body}\nEND\n", **options)


def table(result: ProcedureAnalysis, name: str, schema: Optional[str] = None) -> TableUsage:
    matches = [u for u in result.tables.values()
               if u.obj.name.upper() == name.upper()
               and (schema is None or (u.obj.schema or "").upper() == schema.upper())]
    assert len(matches) == 1, f"{name}: found {[m.obj.display_name for m in matches]} in " \
                              f"{[u.obj.display_name for u in result.tables.values()]}"
    return matches[0]


def physical(result: ProcedureAnalysis) -> Set[str]:
    return {u.obj.name for u in result.tables.values()
            if u.obj.object_type in ObjectType.DATABASE_OBJECTS and not u.fallback_only}


def ops(result: ProcedureAnalysis, name: str, schema: Optional[str] = None) -> Set[str]:
    return set(table(result, name, schema).operations)


def _q(ref) -> str:
    owner = ref.table.name if ref.table is not None else (ref.owner_label or "?")
    return f"{owner}.{ref.column}"


def joins(result: ProcedureAnalysis, join_type: Optional[str] = None) -> Set[str]:
    """{'Customer.CustomerID = Orders.CustomerID', 'H.c = 'x'' ...}"""
    out = set()
    for j in result.joins:
        if join_type and j.join_type != join_type:
            continue
        left = ", ".join(_q(r) for r in j.left)
        right = ", ".join(_q(r) for r in j.right) if j.right else j.right_value
        out.add(f"{left} {j.operator} {right}")
    return out


def join_types(result: ProcedureAnalysis) -> Set[str]:
    return {j.join_type for j in result.joins}


def filters(result: ProcedureAnalysis, clause: str = "WHERE") -> Set[str]:
    """{'Customer.Status =', 'Orders.OrderDate BETWEEN', ...} for resolved columns."""
    return {f"{_q(f.column)} {f.operator}" for f in result.filters
            if f.clause == clause and f.column.table is not None}


def filter_columns(result: ProcedureAnalysis, clause: str = "WHERE") -> Set[str]:
    return {_q(f.column) for f in result.filters
            if f.clause == clause and f.column.table is not None}


def unresolved(result: ProcedureAnalysis) -> Set[str]:
    return {u.ref.original or u.ref.column for u in result.unresolved}


def issue_types(result: ProcedureAnalysis) -> Set[str]:
    return {i.issue_type for i in result.issues}
