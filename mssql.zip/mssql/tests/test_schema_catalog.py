"""Folder-based schema definitions (read as text, never executed)."""
from analyzer.schema_catalog import load_schema_catalog
from models.common import ObjectRef, ObjectType
from tests.perf_helpers import catalog_from

DDL = """
CREATE TABLE [dbo].[Orders] (
    [OrderID] int IDENTITY(1,1) NOT NULL,
    [CustomerID] int NOT NULL,
    [Code] nvarchar(40) NULL,
    [Payload] varbinary(max) NULL,
    [Total] AS ([Qty] * [Price]),
    CONSTRAINT [PK_Orders] PRIMARY KEY CLUSTERED ([OrderID] ASC),
    CONSTRAINT [FK_Cust] FOREIGN KEY ([CustomerID]) REFERENCES dbo.Customer (CustomerID),
    INDEX IX_inline NONCLUSTERED (Code)
) ON ps_Orders(OrderID)
GO
CREATE UNIQUE NONCLUSTERED INDEX [UX_Orders_Code] ON [dbo].[Orders] ([Code] ASC)
    INCLUDE ([CustomerID]) WHERE ([Code] IS NOT NULL) WITH (ONLINE = ON) ON [PRIMARY]
GO
ALTER TABLE dbo.Customer ADD CONSTRAINT PK_Customer PRIMARY KEY NONCLUSTERED (CustomerID);
CREATE CLUSTERED COLUMNSTORE INDEX CCI_Fact ON dbo.Fact;
CREATE INDEX IX_tmp ON #tmp (a);
CREATE TABLE #scratch (a int);
CREATE INDEX broken ON dbo.Orders (
"""


def test_tables_columns_indexes_and_partitioning(tmp_path):
    cat = catalog_from(tmp_path, DDL)
    orders = cat.lookup(ObjectRef("Orders", ObjectType.PHYSICAL_TABLE, "dbo"))
    assert orders.defined and list(orders.columns) == ["ORDERID", "CUSTOMERID", "CODE", "PAYLOAD",
                                                       "TOTAL"]
    assert orders.column("Code").max_bytes == 80 and orders.column("Payload").lob
    assert orders.column("Total").computed
    assert orders.partition_column == "OrderID" and orders.partition_scheme == "ps_Orders"
    names = {i.name: i for i in orders.indexes}
    assert names["PK_Orders"].primary_key and names["PK_Orders"].clustered
    assert names["IX_inline"].keys == ["Code"] and not names["IX_inline"].unique
    ux = names["UX_Orders_Code"]
    assert ux.unique and ux.includes == ["CustomerID"] and ux.filter == "([Code] IS NOT NULL)"
    customer = cat.lookup(ObjectRef("Customer", ObjectType.PHYSICAL_TABLE))   # default schema
    assert customer.indexes[0].primary_key and not customer.indexes[0].clustered
    fact = cat.lookup(ObjectRef("Fact", ObjectType.PHYSICAL_TABLE, "dbo"))
    assert fact.indexes[0].kind == "COLUMNSTORE"
    assert not any(t.name.startswith("#") for t in cat.tables.values())
    assert cat.warnings and "statement skipped" in cat.warnings[0]


def test_metadata_csv_and_missing_folder(tmp_path):
    cat = catalog_from(tmp_path, "", "table,row_count,retention_policy\n[dbo].[H],100,1 year\n")
    h = cat.lookup(ObjectRef("H", ObjectType.PHYSICAL_TABLE, "dbo"))
    assert h.metadata == {"row_count": "100", "retention_policy": "1 year"} and not h.defined
    missing = load_schema_catalog(tmp_path / "nope")
    assert missing.warnings and missing.table_count == 0
    assert load_schema_catalog(None) is None


def test_database_qualified_reference_matches_unqualified_definition(tmp_path):
    cat = catalog_from(tmp_path, "CREATE TABLE dbo.T (a int);")
    assert cat.lookup(ObjectRef("T", ObjectType.PHYSICAL_TABLE, "dbo", "SalesDB")) is not None
