"""Partitioning review: triggers, evidence, and the insufficient-evidence verdict."""
from analyzer.options import PerformanceOptions
from reports.performance_builder import INSUFFICIENT_PARTITION
from tests.perf_helpers import analyze_many, builder, catalog_from, sp

HISTORY_DDL = """
CREATE TABLE dbo.History (
    HistoryID bigint NOT NULL,
    OrderID int NOT NULL,
    EventDate datetime2(3) NOT NULL,
    CONSTRAINT PK_History PRIMARY KEY CLUSTERED (HistoryID)
);
"""
METADATA = ("table,row_count,data_size_mb,row_distribution,growth,retention_policy,partitioning\n"
            "dbo.History,180000000,42000,even by month,+2.5M rows/month,7 years,none\n")

PURGE = sp("purge", "DELETE FROM dbo.History WHERE EventDate < DATEADD(year, -7, GETDATE())")
REPORT = sp("report", "SELECT h.OrderID FROM dbo.History h WHERE h.EventDate >= @f "
                      "AND h.EventDate < @t\n"
                      "SELECT h.OrderID FROM dbo.History h WHERE h.EventDate BETWEEN @f AND @t\n"
                      "SELECT h.OrderID FROM dbo.History h WHERE h.OrderID = @id")


def assess(sources, catalog=None, **perf):
    analyses = analyze_many(sources, catalog=catalog)
    return builder(analyses, catalog, PerformanceOptions(**perf)).partition_assessments()


def test_date_bounded_delete_triggers_review_with_insufficient_evidence():
    (p,) = assess({"purge.sql": PURGE})
    assert p.column == "EventDate"
    assert "range-bounded DELETE" in p.pattern
    assert p.assessment == INSUFFICIENT_PARTITION
    for item in ("table size", "row distribution", "growth", "retention policy",
                 "existing partitioning", "key constraints"):
        assert item in p.missing
    assert p.benefit.startswith("Maintenance:")


def test_repeated_range_filtering_triggers_review():
    (p,) = assess({"report.sql": REPORT})
    assert p.column == "EventDate" and "2 of 3 statement(s)" in p.pattern
    assert "Query:" in p.benefit and "does not guarantee faster queries" in p.benefit
    assert "1 of 3 statement(s) have no predicate on EventDate" in p.considerations


def test_not_triggered_by_a_date_column_or_many_procedures_alone():
    sources = {f"p{i}.sql": sp(f"p{i}", "SELECT h.EventDate FROM dbo.History h WHERE h.OrderID = @id")
               for i in range(6)}
    sources["one.sql"] = sp("one", "SELECT h.OrderID FROM dbo.History h WHERE h.EventDate >= @f")
    assert assess(sources) == []


def test_share_threshold_requires_consistent_filtering():
    sources = {"r.sql": REPORT}
    sources.update({f"x{i}.sql": sp(f"x{i}", "SELECT h.OrderID FROM dbo.History h WHERE h.OrderID = @i")
                    for i in range(5)})
    assert assess(sources) == []                      # 2 of 8 statements < 50%
    assert len(assess(sources, partition_min_share=0.2)) == 1


def test_full_evidence_gives_review_without_boundaries(tmp_path):
    cat = catalog_from(tmp_path, HISTORY_DDL, METADATA)
    (p,) = assess({"purge.sql": PURGE, "report.sql": REPORT}, catalog=cat)
    assert p.missing == "None"
    assert p.assessment != INSUFFICIENT_PARTITION and "no boundaries are proposed" in p.assessment
    assert "PK_History do not include EventDate" in p.considerations
    assert "180000000 rows" in p.available and "EventDate type: datetime2(3)" in p.available


def test_already_partitioned_table(tmp_path):
    ddl = HISTORY_DDL.replace(");\n", ") ON ps_History(EventDate);\n", 1)
    cat = catalog_from(tmp_path, ddl, METADATA.replace(",none\n", ",\n"))
    (p,) = assess({"purge.sql": PURGE}, catalog=cat)
    assert p.assessment.startswith("Already partitioned on EventDate")


def test_function_wrapped_range_is_reported_as_no_elimination():
    (p,) = assess({"purge.sql": PURGE,
                   "y.sql": sp("y", "SELECT COUNT(*) FROM dbo.History h WHERE YEAR(h.EventDate) = 2024")})
    assert "through a function" in p.pattern and "no partition elimination" in p.considerations


def test_partitioning_review_can_be_disabled():
    assert assess({"purge.sql": PURGE}, disabled_rules=frozenset({"PART-001"})) == []
