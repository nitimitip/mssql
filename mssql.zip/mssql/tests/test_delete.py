from helpers import filters, joins, ops, physical, proc, table

from models import Confidence


def test_simple_delete():
    r = proc("DELETE FROM dbo.AuditLog WHERE LoggedAt < DATEADD(day, -30, GETDATE())")
    assert ops(r, "AuditLog") == {"DELETE"}
    assert filters(r) == {"AuditLog.LoggedAt <"}
    assert r.filters[0].compared_with == "DATEADD(day, -30, GETDATE())"


def test_delete_without_from_keyword():
    r = proc("DELETE dbo.AuditLog WHERE Id = 1")
    assert ops(r, "AuditLog") == {"DELETE"}


def test_delete_with_alias_and_join_spec_example():
    r = proc("""
        DELETE c
        FROM Customer c
        JOIN Orders o ON c.CustomerID = o.CustomerID
        WHERE o.IsDeleted = 1;""")
    assert ops(r, "Customer") == {"DELETE"}
    assert ops(r, "Orders") == {"SELECT", "JOIN"}
    assert "DELETE" not in ops(r, "Orders")
    assert joins(r) == {"Customer.CustomerID = Orders.CustomerID"}
    assert filters(r) == {"Orders.IsDeleted ="}


def test_delete_from_alias_from_form():
    r = proc("DELETE FROM c FROM Customer c JOIN Orders o ON o.CustomerID = c.CustomerID WHERE o.X = 1")
    assert ops(r, "Customer") == {"DELETE"}
    assert ops(r, "Orders") == {"SELECT", "JOIN"}


def test_delete_from_cte_dedupe_pattern():
    r = proc("""
        ;WITH d AS (SELECT *, ROW_NUMBER() OVER (PARTITION BY k ORDER BY id) rn FROM dbo.Dupes)
        DELETE FROM d WHERE rn > 1""")
    dupes = table(r, "Dupes")
    assert {"SELECT", "DELETE"} <= set(dupes.operations)
    assert physical(r) == {"Dupes"}
    rn = next(f for f in r.filters if f.column.column == "rn")
    assert rn.column.table is None and rn.confidence == Confidence.LOW   # computed column


def test_truncate():
    r = proc("TRUNCATE TABLE dbo.Staging")
    assert ops(r, "Staging") == {"TRUNCATE"}
