# MSSQL Stored Procedure Dependency Analyzer

Static analysis of Microsoft SQL Server stored procedures (one or more `.sql` files)
that produces an Excel dependency map:

* which **tables** each procedure uses, and **how** (SELECT / INSERT / UPDATE / DELETE /
  MERGE / JOIN / APPLY / TRUNCATE ...)
* every **JOIN / ON** predicate with resolved left and right `Table.Column`
* every **WHERE / HAVING** filter column with its operator and comparison value
* a **Summary** ranking tables by the number of procedures that use them
* a static **performance review**: statement-level risk findings (Cartesian joins, non-SARGable
  predicates, catch-all parameters, cursors ...), preliminary **index candidates** and a
  **partitioning review**, each with its SQL evidence, assumptions and the validation still needed

Its guiding rule is **a correct result over a complete-looking one**. Any reference that
cannot be resolved with certainty is reported as unresolved, ambiguous, or "manual review",
and is never guessed.

The analyzer never executes SQL, never connects to a database, never applies database changes,
and never modifies input files. Input files are treated as untrusted text. There is no `eval`/`exec` of file content,
and dynamic SQL is analysed as text only.

---

## Contents

1. [Quick start](#quick-start)
2. [Configuration](#configuration)
3. [The Excel report](#the-excel-report)
4. [Performance review](#performance-review)
5. [Confidence levels and analysis status](#confidence-levels-and-analysis-status)
6. [Architecture](#architecture)
7. [Parser choice](#parser-choice)
8. [Supported T-SQL](#supported-t-sql)
9. [Limitations](#limitations)
10. [Testing](#testing)
11. [Troubleshooting](#troubleshooting)

---

## Quick start

Requirements: **Python 3.9+** (developed and tested on Python 3.13, Windows 11).

```bash
pip install -r requirements.txt          # XlsxWriter only
python main.py                            # uses config.ini
python main.py --input "C:\StoredProcedures" --output "C:\Reports"
```

Other options: `--config path\to\config.ini`, `--log-dir`, `--log-level DEBUG`,
`--schema path\to\schema_folder` (optional table/index definitions, see
[Performance review](#performance-review)), `--version`.

Put one stored procedure per `.sql` file in `input/stored_procedures/`. Sub-folders are
scanned by default. A file may contain several procedures separated by `GO`, and each one
gets its own sheet. Fifteen sample procedures (14 files) are included in
`input/stored_procedures/`, with matching sample schema definitions in `input/schema/`.

At the end of a run the console shows (here for
`python main.py --input input/stored_procedures --schema input/schema` with
`file_extensions = .sql`):

```text
MSSQL Stored Procedure Analysis Complete

SQL files discovered:          14
Procedures analysed:           15
Duplicate definitions:          0
Successfully analyzed:         10
Partially analyzed:             4
Manual review required:         1
Failed:                         0

Unique physical tables:        17

Performance review (static; review items, not measured results):
SP findings H/M/L/Info:    2/7/2/1
Index candidates:              32
Partitioning reviews:           1
Schema definitions:        4 tables, 7 indexes
...
Report:
...\output\MSSQL_SP_Dependency_Report.xlsx
Log:
...\logs\analyzer.log
```

---

## Configuration

`config.ini`. Relative paths resolve against the folder that contains the config file, so
the tool works from any current directory.

| Section | Key | Default | Meaning |
|---|---|---|---|
| Paths | `input_directory` | `input/stored_procedures` | folder with `.sql` files |
| Paths | `output_directory` / `log_directory` | `output` / `logs` | |
| Input | `file_extensions` | `.sql` | comma-separated |
| Input | `recursive` | `true` | scan sub-folders |
| Input | `max_file_size_mb` | `50` | larger files are reported as FAILED |
| Analysis | `include_temp_tables_in_summary` | `false` | `#temp` / `##temp` in the Summary ranking |
| Analysis | `include_table_variables_in_summary` | `false` | `@table` variables in the ranking |
| Analysis | `include_views_in_summary` | `true` | |
| Analysis | `include_unparsed_fallback_in_summary` | `false` | names found only by token scan of an unparseable statement |
| Analysis | `analyze_dynamic_sql` | `true` | analyse dynamic SQL whose text is statically known |
| Analysis | `max_dynamic_sql_variants` | `32` | cap on conditional variants of one dynamic SQL string |
| Analysis | `view_name_prefixes` | `vw_` | names with these prefixes are classified as **View** |
| Analysis | `unknown_object_type` | `Physical Table` | type for every other name: `Physical Table` or `Unknown Database Object` |
| Analysis | `default_schema` / `merge_unqualified_with_default_schema` | `dbo` / `true` | in the Summary, treat `Customer` and `dbo.Customer` as one table |
| Analysis | `fallback_scan_unparsed` | `true` | token-scan unparseable statements for table names (LOW confidence) |
| Performance | `enabled` | `true` | run the static performance review |
| Performance | `disabled_rules` | (none) | comma-separated rule IDs to switch off, e.g. `PERF-S001, PART-001`; unknown IDs are a configuration error |
| Performance | `max_key_columns` / `max_include_columns` | `4` / `6` | width limits for index candidates |
| Performance | `partition_min_range_statements` / `partition_min_share` | `2` / `0.5` | partitioning review trigger (see below) |
| Schema | `schema_directory` | (blank) | optional folder of CREATE TABLE / CREATE INDEX scripts and `table_metadata.csv` |
| Schema | `file_extensions` | `.sql` | DDL file extensions in that folder |
| Excel | `output_file`, `freeze_panes`, `enable_filters` | | |
| Logging | `level`, `log_file`, `console_level` | `INFO`, `analyzer.log`, `WARNING` | |

**Two assumptions are configurable because they cannot be known without database metadata:**

* *Is `dbo.Something` a table or a view?* By default, names are assumed to be physical tables
  unless they match a view prefix. Set `unknown_object_type = Unknown Database Object` to make
  no assumption.
* *Is unqualified `Customer` the same object as `dbo.Customer`?* Usually it is, through the
  default schema. The Summary merges them by default. Per-procedure sheets always show the
  schema exactly as written, or "Not Specified".

---

## The Excel report

Sheets, in order:

| Sheet | Answers |
|---|---|
| **Summary** (always first) | Which physical tables are used most? `Rank`, `Schema`, `Table`, `SP Count`, per-operation SP counts, then `SP 1`, `SP 2`, ... with one hyperlink to each procedure's sheet |
| **SP Index** | Every procedure with its status, confidence, dynamic-SQL flag and counts. Each name links to its sheet |
| **Column Usage** | Which columns are used in SELECT / JOIN / WHERE / GROUP BY / HAVING / ORDER BY / SET, and by how many procedures |
| **Join Relationships** | Which procedures join table A to table B, and on which columns |
| **Analysis Issues** | Every warning or manual-review item for every procedure |
| **SP Performance Findings** | Statement-level performance review items (see [Performance review](#performance-review)) |
| **Index Candidates** | Preliminary, review-only index candidates with supporting statements |
| **Partitioning Review** | Tables whose observed usage may justify a partitioning review |
| **Performance Coverage** | What the review could not see (unparsed statements, runtime dynamic SQL, unresolved columns), the rule catalogue, and the schema definitions used |
| one sheet per procedure | Details below |

**SP Count** is the number of *distinct* procedures that reference the table. A procedure that
uses `BT_ACT_HIST` twenty times contributes 1. In the operation columns, INSERT includes
`SELECT INTO`, and DELETE includes `TRUNCATE`.

Each **procedure sheet** has a `<- Back to Summary` link in A1 and a link to the SP Index. It
contains:

* **Header**: name, schema, source file, analysis status, confidence, dynamic SQL detected,
  manual review required, counts of physical tables, temp tables and table variables, warnings,
  statements analysed / failed, parameters, procedures called, functions referenced.
* **1. Table Usage**: one row per object (physical tables first, then temp tables, table
  variables, CTEs, derived tables, table-valued functions). It shows aliases, operations, and
  the columns used in JOIN, WHERE, HAVING, SELECT, SET, GROUP BY and ORDER BY. SELECT includes
  window `PARTITION BY` / `ORDER BY`, and `SELECT *` is shown as column `*`. ORDER BY follows
  select-list aliases and ordinals to the underlying columns. SET covers the assigned column
  and the columns its value reads.
* **2. JOIN / ON Details**: join type, left table and column, operator, right table and column
  (or literal value), confidence, the original condition text, the normalized condition with
  aliases resolved, context, line and notes. Besides `ON` clauses, this section lists
  `MERGE ON`, `IN SUBQUERY` semi-joins, `CORRELATED SUBQUERY` predicates, and
  `WHERE (join predicate)` for old-style comma joins.
* **3. WHERE / HAVING Filter Details**: clause, table, column, operator, compared-with value,
  confidence, original condition, context, line, occurrences (identical conditions are
  deduplicated and counted) and notes. For example: "inside ISNULL()", "aggregate expression",
  "inside CASE".
* **4. Unresolved / Ambiguous Column References**: every reference that could not be tied to
  exactly one table, with the candidate tables.
* **5. Dynamic SQL**: each `EXEC(...)`, `sp_executesql` or `EXEC @proc` and how it was
  resolved.
* **6. Analysis Issues**.
* **7. Performance Findings**: this procedure's findings, linked from the sheet header to the
  SP Performance Findings sheet.

The Summary sheet's fourth row links to the performance sheets with their counts, the SP Index
has a `Performance Findings` count per procedure, and each performance sheet links back to the
Summary and to the other performance sheets.

Worksheet names are sanitised: invalid characters are replaced, names are limited to 31
characters, and they are unique case-insensitively. A name that is too long or collides gets a
suffix, for example `usp_Very_Long_Stored_Procedu_01`. The full procedure name always appears
inside the sheet, and every hyperlink uses the sanitised name.

Statuses are shown in colour and also as text (`SUCCESS`, `PARTIAL`,
`MANUAL REVIEW REQUIRED`, `FAILED`). Sheet tabs are coloured by status.

---

## Performance review

A deterministic, rule-based review layered on the same parser, scopes and alias resolution as
the dependency report. Its results are **review items, not measurements**: nothing is executed,
no index is created, and no percentage improvement is ever reported. Findings, analysis status
and parser errors are kept apart. A finding never changes a procedure's status, and parse
failures appear only in Analysis Issues and Performance Coverage.

Every finding has a **Severity** (the possible impact if the pattern matters at runtime: HIGH,
MEDIUM, LOW, INFO) and a separate **Confidence** (how certain the analyzer is that the pattern is
present as described). It shows the exact SQL evidence, source file, statement ID and line, the
pattern and its possible impact, a suggested action or conditional rewrite, the assumptions, and
what must be checked before accepting it.

Statement IDs number the statements of a procedure in order (`S1`, `S2`, ...). SQL run through
dynamic SQL gets `S7.D1` (statement 1 of the dynamic text executed by S7), or `S7.V2.D1` for the
second conditional variant. Findings from dynamic SQL are labelled `Dynamic SQL (statically
known text)` and capped at MEDIUM confidence. Identical findings from several variants are
merged. Runtime-built dynamic SQL cannot be reviewed and is listed on **Performance Coverage**,
because the absence of findings is not evidence of the absence of risk.

### Statement rules

| Rule | What is detected | Notes |
|---|---|---|
| `PERF-J001` | Potential Cartesian product: a comma-separated FROM source that no WHERE predicate relates to the others | A comma join connected through WHERE (also through `EXISTS`/`IN` subqueries or a shared outer row) is not flagged |
| `PERF-J002` | An `ON` clause with no predicate comparing columns of both sides | LOW if WHERE relates them for an INNER JOIN; MEDIUM with a semantics warning for outer joins |
| `PERF-J003` | Constant-true join predicate (`ON 1 = 1`) | `ON 1 = 1 AND a.id = b.id` is not flagged |
| `PERF-J004` | A column compared with itself on the same source (`a.Id = a.Id`) | Self-joins through two aliases are not flagged; no "intended" column is suggested |
| `PERF-J005` | The only relating predicate sits inside an OR that another branch bypasses | AND / OR / NOT and parentheses evaluated exactly (De Morgan for NOT) |
| `PERF-J006` | Explicit `CROSS JOIN`, or `APPLY` that references nothing on its left | LOW, manual review: often intentional |
| `PERF-P001` | Function, CASE or arithmetic around a filtered or joined column | Conditional rewrites only where NULL handling is provably kept (see below) |
| `PERF-P002` | `LIKE` pattern starting with `%` or `_` | Runtime patterns (`LIKE @p`) are not judged |
| `PERF-P003` | Optional-parameter predicates: `@p IS NULL OR col = @p`, `col = ISNULL(@p, col)` | One finding per condition; explains that the ISNULL form excludes NULL rows |
| `PERF-S001` | `SELECT *` in a result set, `INSERT ... SELECT`, `SELECT INTO` or cursor | Not inside `EXISTS`, and not over a derived table whose columns are listed |
| `PERF-L001` | WHILE / cursor loop with database operations per iteration | Lists each operation with its line; "set-based candidate, manual review" |
| `PERF-L002` | `DELETE/UPDATE TOP (n)` loop with `@@ROWCOUNT` | INFO: batching is usually deliberate |

**Single-row sources** never count as row multiplication. These are: `TOP (1)`, an aggregate
without `GROUP BY`, `SELECT` without `FROM`, a one-row `VALUES`, and, when schema definitions are
supplied, equality on every key column of a unique index. CTEs, derived tables, correlated
subqueries, `APPLY` (correlation through the derived query or TVF arguments) and self-joins are
resolved by query scope, so an alias reused in a subquery does not leak.

**Conditional rewrites** are offered only for cases whose equivalence can be stated:

* `YEAR(col) = 2024` becomes a half-open date range, but only when both bounds are valid for
  the column's type. With a declared type, the type's own range applies: date / datetime2 years
  1-9999, datetime 1753-9999, smalldatetime 1900-2079. The last year of the type gets a lower
  bound only, so `YEAR(d) = 9999` becomes `d >= '99990101'`. Years the type cannot hold, and
  non-date columns, get manual review. Without a declared type only 1900-2078 is rewritten,
  because those bounds are valid for every date/time type. `YEAR(col) = @y` is offered only as a
  manual-review template, because `DATEFROMPARTS(@y + 1, ...)` fails for `@y = 9999`.
* `ISNULL(col, X) op Y` / `COALESCE(col, X) op Y` become `col op Y` when the replacement value
  fails the comparison, or `(col op Y OR col IS NULL)` when it passes. This rewrite **requires
  the column's declared type** from the schema folder, because the value actually compared is
  the replacement *after SQL Server's conversion*:
  * `ISNULL` converts it to the column's type. With `varchar(2)`,
    `ISNULL(Code, 'LONG') = 'LO'` compares `'LO'`, so NULL rows match. Strings are truncated,
    numerics truncated to integers or rounded to the decimal / money scale, and out-of-range
    values are conversion errors.
  * `COALESCE` uses data-type precedence, so strings are not truncated but money still rounds.

  Numbers are compared exactly as decimals, never as floating point. Anything undecidable gets
  manual review instead of a rewrite: an unknown type, a collation-dependent string comparison,
  float / hex literals, a conversion error, or non-ASCII text in `varchar`.
* `DATEADD(<fixed unit>, n, col) op v` becomes `col op DATEADD(unit, -n, v)`.
* `col + n op v` becomes `col op v - n`.
* `CAST(col AS date) = @d` becomes a one-day range. It is flagged LOW, because SQL Server can
  often seek here anyway.
* `RTRIM(col) = v` becomes `col = v`.

Each rewrite states its assumption (data type, collation). Everything else gets generic advice.
`ISNULL` on both sides of a join is never "simplified", because that would change NULL matching.

### Index candidates (`IDX-001`)

For every statement, and for each physical table it reads or modifies, the analyzer records:
* equality and IN predicates, range predicates, and prefix `LIKE`;
* join columns;
* `GROUP BY` and `ORDER BY` columns;
* projected columns, updated columns, and columns used by correlated subqueries;
* predicates inside OR, NOT or a function, which are kept as residual filters, never as keys.

Predicates are taken from AND-level WHERE / ON conditions. Outer-join ON predicates apply only to
the inner side.

One candidate is built per statement:
1. **Key columns:** equality columns first. Their order is by how many statements use them; this
   is a reasoned guess, because selectivity is unknown.
2. Then the first range column. Without a range column, the ORDER BY / GROUP BY columns follow
   instead.
3. **INCLUDE** lists the other columns read, capped by `max_include_columns`. `SELECT *` gives a
   key-only candidate.
4. **Filtered candidate:** constant predicates (`Status = 'OPEN'`, `IsDeleted = 0`,
   `x IS NOT NULL`) become an index filter, with the literal kept exactly.

Candidates are then **consolidated only when identical** (same table, keys and filter), so
columns from unrelated statements are never merged into one wide index. Overlaps between
candidates, such as left prefixes or a shared leading key, are reported. Supporting SP Count
counts *distinct* procedures; it is never presented as execution frequency.

**Duplicate procedure definitions:**
* Identical copies of a procedure count once.
* Copies that differ in what they read are kept as separate supporting statements, so the
  INCLUDE columns of every version survive. The evidence names the source file of each version.

**Candidate confidence** is the lowest confidence of its supporting statements. Statement
Evidence shows each statement's own confidence and any unresolved columns. If some supporting
statements have unresolved columns, the candidate is never reported as *Already covered*: it
becomes *Possible extension or overlap requiring review*, naming those columns.

**Existing Index Assessment** is one of:

* *Candidate to evaluate*: no defined index has a matching leading key.
* *Already covered by an existing index*: the equality columns match in any order, then the
  range / order columns, the filter matches, and the key + INCLUDE (+ clustered key) columns
  cover the statement.
* *Possible extension or overlap requiring review*: the same seek but missing INCLUDE columns, a
  shared leading key, a different filter, or a columnstore index.
* *Insufficient information*: no definitions were provided for the table (the analyzer never
  claims an index is missing without them), a column is absent from the definition, a LOB key,
  or unresolved column ownership.

Unique indexes are never proposed. The DDL column is fully commented out and labelled
`REVIEW-ONLY CANDIDATE`, and nothing executes it. **Trade-offs** list the statements that modify
the table, any UPDATE that changes an indexed column, writes inside loops, and an estimated
per-row width from the declared types.

### Partitioning review (`PART-001`)

A table is listed only when the code shows one of these:
* a **range-bounded DELETE** (archival / purge), or
* **repeated range filtering on one column**: at least `partition_min_range_statements`
  statements, and at least `partition_min_share` of the statements that read, update or delete
  the table.

A date column on its own, or a table used by many procedures, never triggers a review.

Each row shows:
* the candidate column and the observed pattern;
* the supporting procedures and statements;
* the available and missing evidence;
* maintenance benefits (partition SWITCH / TRUNCATE instead of logged deletes, per-partition
  maintenance), described separately from query benefits (partition elimination, only for
  SARGable predicates, never promised);
* considerations: statements without a predicate on the column that would touch every
  partition, function-wrapped predicates, unique constraints that would need the column to be
  aligned, and index alignment for SWITCH.

If any of **table size, row distribution, growth, retention policy, existing partitioning or key
constraints** is unknown, the assessment is exactly *"Insufficient evidence for a partitioning
recommendation."* No partition boundaries are ever proposed.

### Optional schema folder

Set `[Schema] schema_directory` (or `--schema`) to a folder that contains:

* `.sql` scripts with `CREATE TABLE` (columns, types, inline and table-level `PRIMARY KEY` /
  `UNIQUE` / `INDEX`, `ON scheme(column)`), `CREATE [UNIQUE] [CLUSTERED|NONCLUSTERED]
  [COLUMNSTORE] INDEX ... INCLUDE (...) WHERE ...`, `ALTER TABLE ... ADD CONSTRAINT PRIMARY
  KEY/UNIQUE`, and `CREATE PARTITION SCHEME`. Scripts generated by SSMS ("Generate Scripts") work
  as-is. The scripts are tokenised as text and never executed; anything unrecognised is skipped
  with a warning on the Performance Coverage sheet.
* optionally `table_metadata.csv` with the columns `table,row_count,data_size_mb,
  row_distribution,growth,retention_policy,partitioning,notes`. A blank value means unknown.

`input/schema/` is a worked example for the sample procedures:

```bash
python main.py --input input/stored_procedures --schema input/schema
```

---

## Confidence levels and analysis status

| Confidence | Meaning |
|---|---|
| **HIGH** | Resolved directly and unambiguously, e.g. `e.ae_status` with `e` = `BT_ENQUIRY_MASTER` in the same or an outer scope, or an unqualified column when exactly one table is in scope. |
| **MEDIUM** | Resolved through lineage: a CTE or derived-table column traced to its source column, an unqualified column in a subquery (bound to the inner table by SQL scoping rules), dynamic SQL with statically known text, or a column inside an aggregate. |
| **LOW** | Ambiguous or not traceable: an unqualified column with several candidate tables, a computed CTE column (`MAX(x) AS LastDate`), a recursive-CTE self-reference, or a name found only by the fallback token scan. |
| **MANUAL REVIEW** | Cannot be determined statically, e.g. dynamic SQL built from parameters or table data. |

| Status | Rule |
|---|---|
| **SUCCESS** | Every statement parsed and every reported column resolved. |
| **PARTIAL** | Something could not be fully resolved: an unparseable statement, an ambiguous or unresolved column, incomplete CTE lineage, or a recursive CTE. |
| **MANUAL REVIEW REQUIRED** | Dynamic SQL whose text or target is built at runtime, or `EXEC @procName`. |
| **FAILED** | The file could not be read or tokenised, or none of its statements could be parsed. |

A procedure's overall confidence is the lowest confidence among its tables, joins and filters.

---

## Architecture

```text
main.py                       CLI, run loop, console summary
config.py / config.ini        configuration (+ CLI overrides)
analyzer/
  file_reader.py              discovery; BOM / UTF-8 / UTF-16 / cp1252 decoding
  tokenizer.py                T-SQL tokens; comments dropped, strings decoded, [ident] unquoted, GO
  keywords.py                 reserved words, statement starters, hints
  parser.py                   recursive-descent parser -> AST, per-statement error recovery
  ast_nodes.py                AST dataclasses
  scope_manager.py            query scopes, sources, alias + column resolution, CTE/derived lineage
  object_resolver.py          table / view / #temp / @tablevar / function classification
  statement_analyzer.py       semantic walk: operations, JOIN + filter extraction, CTEs, temp tables
  dynamic_sql_analyzer.py     static evaluation of dynamic-SQL strings
  performance.py              statement performance rules + per-statement table access records
  perf_rules.py               rule catalogue (stable rule IDs)
  schema_catalog.py           optional folder-based table / index / partition definitions
  engine.py                   per-file orchestration, de-duplication, status/confidence rules
  options.py                  analysis and performance options
models/                       ProcedureAnalysis, TableUsage, JoinCondition, FilterCondition,
                              PerfFinding, AccessRecord, ...
reports/
  summary_builder.py          cross-procedure aggregation (pure data)
  performance_builder.py      index candidates, partitioning review, coverage (pure data)
  excel_report.py             workbook writer (XlsxWriter)
utils/                        logging, sheet-name sanitising, hyperlinks
tests/                        pytest suite (311 tests)
```

The pipeline is: raw SQL, then tokens, then AST (batches, statements, queries, expressions),
then scopes and sources, then alias and column resolution, then JOIN / WHERE / HAVING
extraction, then operation classification, then the dependency model, then the Excel report.
Parsing knows nothing about Excel, and the report reads only the data model.

The spec's suggested `join_analyzer`, `filter_analyzer`, `cte_analyzer`,
`temp_table_analyzer` and `operation_analyzer` live in `statement_analyzer.py`, because they
share one scope walk. `alias_resolver` corresponds to `scope_manager.py`.

---

## Parser choice

Options evaluated for SQL Server T-SQL:

| Option | Assessment |
|---|---|
| **sqlparse** | A non-validating tokenizer and statement splitter. It has no semantic AST, so it cannot resolve aliases, scopes or clause roles on its own. |
| **sqlglot** (`tsql` dialect) | A real AST with good coverage of ordinary DML (CTEs, `UPDATE ... FROM`, MERGE, APPLY, bracketed identifiers). However, procedural T-SQL in procedure bodies (IF/WHILE/TRY-CATCH/cursors/DECLARE) is not modelled as structured statements. Unsupported constructs degrade to opaque command nodes, and error recovery is coarse. A custom statement splitter and all of the scope and alias resolution would still be needed, and those are the hard parts. |
| **ANTLR grammars-v4 `TSqlParser`** (Python target) | The most complete open grammar, but a very large generated parser on the pure-Python ANTLR runtime. It is slow for thousands of files and a heavy dependency. |
| **Microsoft ScriptDom** (`TSql160Parser`) | The reference T-SQL parser, but it is a .NET library. It would need pythonnet plus Microsoft DLLs, which is deployment friction for an offline tool. |

**Choice:** a purpose-built T-SQL tokenizer and recursive-descent parser (`analyzer/parser.py`)
that covers the dependency-relevant subset of T-SQL, including procedural statements, with
per-statement error recovery. Semantic analysis (`scope_manager.py`,
`statement_analyzer.py`) is separate from parsing.

Why this fits the requirements:

* T-SQL statement boundaries without semicolons are found by the grammar plus the official
  reserved-word list. An unbracketed reserved word can never be an identifier or an implicit
  alias.
* A statement the parser cannot handle becomes an explicit `UnparsedStmt`. It is reported in
  Analysis Issues, the procedure becomes PARTIAL, and parsing resumes at the next statement.
  Nothing is silently dropped.
* There are no third-party parse dependencies and no version drift in someone else's AST.

Regular expressions are not used for parsing. The only "regex-like" component is the optional
fallback token scan of statements that failed to parse. Its results are LOW confidence,
labelled unverified, and excluded from the Summary by default.

---

## Supported T-SQL

* `CREATE`/`ALTER`/`CREATE OR ALTER` `PROC`/`PROCEDURE` (parameters, `WITH RECOMPILE`/`EXECUTE AS`), `GO` batches, several procedures per file
* `SELECT` (TOP, DISTINCT, INTO, GROUP BY / ROLLUP / GROUPING SETS, HAVING, ORDER BY, OFFSET/FETCH, FOR XML/JSON, OPTION), `UNION [ALL]` / `EXCEPT` / `INTERSECT`
* `INSERT` (VALUES, SELECT, EXEC, DEFAULT VALUES, OUTPUT INTO), `UPDATE ... FROM`, `DELETE ... FROM` (incl. `DELETE alias FROM ...`), `MERGE` (all WHEN forms, OUTPUT), `TRUNCATE`, `WHERE CURRENT OF`
* All join types, join hints, nested join syntax, comma joins, `CROSS/OUTER APPLY`, PIVOT/UNPIVOT, `FOR SYSTEM_TIME`, `TABLESAMPLE`, table hints (`WITH (NOLOCK)` and legacy `(NOLOCK)`)
* CTEs (multiple, dependent, column lists, recursive detection), derived tables (with column aliases), nested, correlated and scalar subqueries, `EXISTS`/`NOT EXISTS`, `IN (subquery)`, `ANY/ALL/SOME`
* `=, <>, !=, <, >, <=, >=, !<, !>, IS [NOT] NULL, [NOT] IN, [NOT] BETWEEN, [NOT] LIKE ... ESCAPE, IS [NOT] DISTINCT FROM`, `AND/OR/NOT`
* `CASE`, `CAST/CONVERT/TRY_*`, `DATEADD`-family date parts, window functions (`OVER`, `WITHIN GROUP`), `COLLATE`, `AT TIME ZONE`, XML methods
* IF/ELSE, WHILE, BEGIN/END, TRY/CATCH, transactions, cursors (`DECLARE ... CURSOR FOR`, `SET @c = CURSOR FOR`), labels/GOTO
* `#temp`, `##globaltemp` (with column tracking from `CREATE TABLE` / `SELECT INTO`), `DECLARE @t TABLE`
* Bracketed and double-quoted identifiers, `db.schema.table`, `server.db.schema.table`, `db..table`; nested block comments
* Dynamic SQL: `EXEC (...)`, `EXEC sp_executesql ...`, `EXEC @procName`

**Dynamic SQL.** String assignments (`DECLARE @s = ...`, `SET @s = ...`, `SET @s += ...`,
`SELECT @s = ...`) are tracked in statement order. If the executed text is built only from
literals and other statically known variables, it is parsed and analysed like normal code,
with results capped at MEDIUM. Conditional appends, such as an optional `AND` filter added
inside `IF`, produce several variants, and each one is analysed. Text that depends on
parameters, table data, functions, or loop accumulation is reported as **MANUAL REVIEW**, with
the dependency chain, e.g. `@SQL <- @TableName <- @Type (procedure parameter)`. Table names are
never guessed.

---

## Limitations

These are inherent to static analysis without database metadata:

* **Runtime-built dynamic SQL**: reported for manual review and not analysed.
* **View internals / synonyms**: a view is reported as the referenced object, and its
  underlying tables are not invented. Tables and views are distinguished by
  `view_name_prefixes` only.
* **Function internals**: table-valued functions are listed as functions, and scalar UDF
  bodies are not analysed.
* **Unqualified columns with several tables in scope**: reported as ambiguous (LOW) with the
  candidate list. Column ownership would need table metadata. Temp tables and table variables
  with visible definitions are used to rule out candidates.
* **Computed CTE / derived columns** (e.g. `MAX(d) AS LastDate`): reported as CTE-derived with
  LOW confidence. They are not attributed to the source column.
* **Recursive CTEs**: base tables are reported, but lineage through the recursive member is
  not traced, so the procedure is PARTIAL.
* **Control flow is not evaluated**: every branch of IF/ELSE is analysed, because the report
  lists what a procedure *can* touch.
* **Not modelled**: `OPENQUERY`/`OPENROWSET` remote text, PIVOT output-column lineage, CLR
  types, natively compiled modules, and legacy `*=` outer joins (the last are reported as
  unparsed statements).
* **Column coverage**: INSERT column lists, MERGE `INSERT ... VALUES` and OUTPUT clauses are
  not attributed to columns. Ambiguous columns in SELECT / SET / GROUP BY / ORDER BY are listed
  as INFO issues and do not change a procedure's status.
* Unqualified names in the Summary are merged with `default_schema`. Disable
  `merge_unqualified_with_default_schema` if your users have different default schemas.

Performance review limitations:

* **No runtime information.** Row counts, data distribution, parameter values, statistics,
  actual plans and execution frequency are not visible. Severities describe *possible* impact.
  Every finding and candidate lists the validation it needs (actual plans, Query Store, DMVs).
* **Data types and collations are unknown** unless schema definitions are supplied, so implicit
  conversions are not detected and rewrites state their type/collation assumptions.
* **Join connectivity** treats any predicate that compares columns of two sources as relating
  them, including `<>` and range joins. A relationship through a single-row source is treated as
  connected. Both choices avoid false positives at the cost of some missed cases.
* **Index candidates** use only resolved, directly referenced table columns. Filters applied to
  CTE / derived-table output are attributed to the CTE's own query, not pushed down. `ASC/DESC`
  in ORDER BY is not captured. Views, temp tables and table variables get no candidates.
* **Statements that failed to parse and runtime-built dynamic SQL** are not reviewed. They are
  listed on Performance Coverage, never silently skipped.
* Index comparison understands key order, INCLUDE, filter text (normalised, literals exact),
  uniqueness and clustered keys. It does not evaluate filter *implication* (for example
  `Status IN ('A','B')` versus `Status = 'A'`). Such cases are reported as an overlap to review.

---

## Testing

```bash
pip install -r requirements-dev.txt
python -m pytest
```

There are 311 tests. The performance review is covered by `test_perf_joins.py`,
`test_perf_predicates.py`, `test_perf_type_safety.py` (type-aware rewrites, exact numerics, date
boundaries, procedure versions, mixed confidence), `test_index_candidates.py`, `test_partitioning.py`,
`test_schema_catalog.py` and `test_perf_excel.py`. They cover:
* genuine and connected Cartesian joins, intentional CROSS JOIN and single-row sources;
* outer joins, self-joins, APPLY, correlated subqueries, OR / NOT logic, and dynamic SQL
  variants;
* literal case and whitespace preservation;
* index-candidate consolidation, distinct-procedure counting and existing-index coverage;
* insufficient partitioning evidence, and unresolved columns;
* the contents and links of the new worksheets.

The dependency tests cover: simple and aliased SELECT; one, multiple and multi-column
joins; INNER, LEFT, RIGHT, FULL and CROSS joins; complex join predicates; all WHERE
operators; AND/OR/NOT; HAVING; SELECT / SET / GROUP BY / ORDER BY column usage; INSERT, INSERT SELECT and
INSERT EXEC; UPDATE and UPDATE FROM; DELETE (with alias, with join, through a CTE); MERGE;
single, multiple, dependent and recursive CTEs; derived tables; nested and correlated
subqueries; EXISTS and NOT EXISTS; UNION and UNION ALL; temp, global temp and table
variables; CROSS and OUTER APPLY; schema-, database- and bracket-qualified names; one table
under several aliases; alias shadowing; static, conditional and runtime dynamic SQL; fake SQL
in comments and strings; malformed and unsupported syntax; encodings; GO batches; long and
duplicate sheet names; workbook structure and hyperlinks; SP Count semantics.

During development the parser was also run on every truncation of every sample file (4,408
malformed inputs) with no crashes. 1,000 procedures analyse in about 1 s, and their
1,000-sheet workbook is written in about 6 s.

---

## Troubleshooting

| Symptom | Cause / fix |
|---|---|
| `WARNING: ... is locked (open in Excel?)` | The previous report is open, so a timestamped copy is written instead. Close Excel to keep the default name. |
| `Input directory not found` | Check `[Paths] input_directory` or pass `--input`. Relative paths resolve against the config file's folder. |
| A procedure is PARTIAL | See its sheet's *Analysis Issues* and *Unresolved* sections. Each item has a line number. |
| `Statement not analysed (...)` | That statement uses syntax outside the supported subset. Its names appear only as LOW-confidence "UNPARSED STATEMENT" rows and are excluded from the Summary. |
| Garbled characters | The file was neither UTF-8 nor UTF-16. It was decoded as Windows-1252, and an INFO issue records this. Re-save the file as UTF-8. |
| Need more detail | Run with `--log-level DEBUG` and check `logs/analyzer.log`. |
