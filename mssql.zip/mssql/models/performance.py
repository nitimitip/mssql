"""Performance review records: statement findings and per-statement table access.

Findings describe *possible* performance risks detected statically. Severity
(possible impact) and confidence (certainty that the pattern is present as
described) are independent. Nothing here claims a measured improvement.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List

from .common import ObjectRef, condition_key


class PerfSeverity:
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"
    INFO = "INFO"

    _RANK = {HIGH: 0, MEDIUM: 1, LOW: 2, INFO: 3}

    @classmethod
    def rank(cls, value: str) -> int:
        return cls._RANK.get(value, 4)


class SqlOrigin:
    STATIC = "Static SQL"
    DYNAMIC = "Dynamic SQL (statically known text)"


@dataclass
class PerfFinding:
    rule_id: str
    severity: str
    confidence: str
    statement_id: str
    line: int
    tables: str
    finding: str              # detected pattern + possible impact
    evidence: str             # exact SQL text
    action: str
    assumptions: str
    validation: str
    origin: str = SqlOrigin.STATIC
    context: str = ""
    statement_ids: List[str] = field(default_factory=list)
    occurrences: int = 1

    def dedupe_key(self):
        # Dynamic-SQL variants re-run the same statement text; they are merged.
        # String literals keep their case and inner whitespace (condition_key).
        top = self.statement_id.split(".")[0]
        return (self.rule_id, top, self.tables.upper(), condition_key(self.evidence))


# ColumnAccess.kind values
EQ = "EQUALITY"               # col = value / col IS NULL
EQ_JOIN = "EQUALITY JOIN"     # col = other_source.col / IN (subquery)
IN_LIST = "IN LIST"           # col IN (v1, v2)
RANGE = "RANGE"               # <, >, <=, >=, BETWEEN
PREFIX = "PREFIX LIKE"        # LIKE 'abc%'
RESIDUAL = "RESIDUAL"         # <>, NOT ..., LIKE '%x', IS NOT NULL ...
NONSARGABLE = "NON-SARGABLE"  # column wrapped in a function / calculation
OR_BRANCH = "OR BRANCH"       # only inside an OR (not a guaranteed filter)

SEEK_KINDS = frozenset({EQ, EQ_JOIN, IN_LIST})


@dataclass
class ColumnAccess:
    column: str
    kind: str
    text: str = ""            # original predicate text
    value: str = ""           # compared-with text (literals exactly as written)
    constant: bool = False    # compared with a literal constant (filtered-index eligible)
    wrappers: str = ""        # for NON-SARGABLE: the wrapping functions
    op: str = ""              # =, <, BETWEEN, IS NULL, IS NOT NULL, IN, LIKE ...


@dataclass
class AccessRecord:
    """How one statement (query block) accesses one table source."""
    table: ObjectRef
    alias: str
    statement_id: str
    line: int
    operation: str            # SELECT | INSERT | UPDATE | DELETE | MERGE
    role: str                 # read | write
    predicates: List[ColumnAccess] = field(default_factory=list)
    group_by: List[str] = field(default_factory=list)
    order_by: List[str] = field(default_factory=list)
    projected: List[str] = field(default_factory=list)
    star: bool = False
    updated: List[str] = field(default_factory=list)
    other_columns: List[str] = field(default_factory=list)
    condition_text: str = ""
    context: str = ""
    dynamic: bool = False
    confidence: str = "HIGH"
    in_loop: bool = False
    unresolved: List[str] = field(default_factory=list)
    top: str = ""

    def columns_of(self, *kinds: str) -> List[str]:
        out: List[str] = []
        for p in self.predicates:
            if p.kind in kinds and p.column.upper() not in (c.upper() for c in out):
                out.append(p.column)
        return out
