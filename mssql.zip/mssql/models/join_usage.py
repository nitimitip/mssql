"""JOIN / ON relationship records."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List

from .common import ColumnRef, Confidence, condition_key


@dataclass
class JoinCondition:
    join_type: str                    # INNER JOIN, LEFT JOIN, MERGE ON, CORRELATED SUBQUERY ...
    left: List[ColumnRef]
    operator: str
    right: List[ColumnRef]
    right_value: str = ""             # literal / variable / expression when right has no columns
    original: str = ""
    normalized: str = ""
    context: str = ""
    line: int = 0
    notes: str = ""
    dynamic: bool = False
    occurrences: int = 1
    confidence: str = field(default=Confidence.HIGH)
    # Whole ON / WHERE condition this predicate belongs to and the AND / OR /
    # NOT groups enclosing it (see FilterCondition).
    full_condition: str = ""
    logic: str = ""

    def dedupe_key(self):
        return (self.join_type, condition_key(self.normalized), self.context, self.logic,
                condition_key(self.full_condition))
