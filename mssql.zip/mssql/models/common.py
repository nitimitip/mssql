"""Shared value types: confidence, object types, object and column references."""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Optional, Tuple


class Confidence:
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"
    MANUAL = "MANUAL REVIEW"

    _RANK = {HIGH: 0, MEDIUM: 1, LOW: 2, MANUAL: 3}

    @classmethod
    def rank(cls, value: str) -> int:
        return cls._RANK.get(value, 2)

    @classmethod
    def worst(cls, *values: str) -> str:
        vals = [v for v in values if v]
        if not vals:
            return cls.HIGH
        return max(vals, key=cls.rank)

    @classmethod
    def cap(cls, value: str, ceiling: str) -> str:
        """Lower ``value`` to at most ``ceiling`` (HIGH > MEDIUM > LOW)."""
        return cls.worst(value, ceiling)


class ObjectType:
    PHYSICAL_TABLE = "Physical Table"
    VIEW = "View"
    UNKNOWN = "Unknown Database Object"
    TEMP_TABLE = "Temporary Table"
    GLOBAL_TEMP_TABLE = "Global Temporary Table"
    TABLE_VARIABLE = "Table Variable"
    CTE = "CTE"
    DERIVED = "Derived Table"
    TABLE_FUNCTION = "Table-Valued Function"
    BUILTIN_FUNCTION = "Built-in Rowset Function"

    DATABASE_OBJECTS = frozenset({PHYSICAL_TABLE, VIEW, UNKNOWN})
    TEMP_OBJECTS = frozenset({TEMP_TABLE, GLOBAL_TEMP_TABLE})


def _up(value: Optional[str]) -> str:
    return (value or "").upper()


_SIMPLE_IDENT = re.compile(r"^[A-Za-z_#@][A-Za-z0-9_@#$]*$")


def quote_ident(name: str) -> str:
    """Bracket an identifier for display when it is not a plain identifier."""
    if not name or _SIMPLE_IDENT.match(name):
        return name
    return "[" + name.replace("]", "]]") + "]"


_STRING_LITERAL = re.compile(r"(N?'(?:[^']|'')*')", re.IGNORECASE)


def condition_key(text: str) -> str:
    """Comparison key for SQL condition text.

    Identifiers and keywords compare case-insensitively and whitespace between
    tokens is collapsed, but string literals are kept exactly - case and inner
    whitespace: Code = 'abc' and Code = 'ABC' (or 'a b' and 'a  b') are
    different conditions.
    """
    out = []
    for i, part in enumerate(_STRING_LITERAL.split(text)):
        if i % 2:
            out.append(part)                      # literal: exact
        else:
            norm = " ".join(part.split()).upper()
            if norm:
                out.append(norm)
    return " ".join(out)


@dataclass(frozen=True)
class ObjectRef:
    """A referenced object (table, view, temp table, CTE ...)."""
    name: str
    object_type: str
    schema: Optional[str] = None
    database: Optional[str] = None
    server: Optional[str] = None

    @property
    def key(self) -> Tuple[str, str, str, str, str]:
        # SQL Server identifiers compare case-insensitively under default collations.
        return (_up(self.server), _up(self.database), _up(self.schema), self.name.upper(),
                self.object_type)

    @property
    def display_name(self) -> str:
        parts = [quote_ident(p) for p in (self.server, self.database, self.schema) if p]
        parts.append(quote_ident(self.name))
        return ".".join(parts)

    @property
    def is_database_object(self) -> bool:
        return self.object_type in ObjectType.DATABASE_OBJECTS


@dataclass
class ColumnRef:
    """A column reference resolved (or not) to its owning object."""
    column: str
    table: Optional[ObjectRef]
    confidence: str
    original: str = ""
    note: str = ""
    owner_label: str = ""            # shown when ``table`` is None (CTE expression, TVF ...)
    candidates: Tuple[str, ...] = ()
    # internal: identity of the scope source and whether it came from an outer scope
    source_id: int = field(default=0, repr=False, compare=False)
    outer: bool = field(default=False, repr=False, compare=False)

    @property
    def resolved(self) -> bool:
        return self.table is not None

    @property
    def table_display(self) -> str:
        if self.table is not None:
            return self.table.display_name
        if self.owner_label:
            return self.owner_label
        return "Unknown / Ambiguous"

    @property
    def qualified(self) -> str:
        return f"{self.table_display}.{quote_ident(self.column)}"
