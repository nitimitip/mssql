"""Per-procedure usage of one object."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List

from .common import Confidence, ObjectRef


def _add_unique(target: List[str], value: str) -> None:
    if value and value not in target:
        target.append(value)


def _add_column(target: Dict[str, str], column: str) -> None:
    # case-insensitive de-duplication, first spelling wins
    target.setdefault(column.upper(), column)


@dataclass
class TableUsage:
    obj: ObjectRef
    aliases: List[str] = field(default_factory=list)
    operations: List[str] = field(default_factory=list)
    join_columns: Dict[str, str] = field(default_factory=dict)
    where_columns: Dict[str, str] = field(default_factory=dict)
    having_columns: Dict[str, str] = field(default_factory=dict)
    select_columns: Dict[str, str] = field(default_factory=dict)
    set_columns: Dict[str, str] = field(default_factory=dict)
    group_by_columns: Dict[str, str] = field(default_factory=dict)
    order_by_columns: Dict[str, str] = field(default_factory=dict)
    confidence: str = Confidence.HIGH
    dynamic: bool = False          # seen only / also via dynamic SQL
    static: bool = False           # seen in statically parsed SQL
    fallback_only: bool = True     # True until seen by the real parser
    first_line: int = 0
    references: int = 0
    contexts: List[str] = field(default_factory=list)

    def add_operation(self, op: str) -> None:
        _add_unique(self.operations, op)

    def add_alias(self, alias: str) -> None:
        if alias and alias.upper() not in (a.upper() for a in self.aliases):
            self.aliases.append(alias)

    def add_column(self, clause: str, column: str) -> None:
        _add_column(self.columns_for(clause), column)

    def columns_for(self, clause: str) -> Dict[str, str]:
        """Column bucket for a clause; WHERE also covers MERGE WHEN conditions."""
        return {
            "JOIN": self.join_columns,
            "HAVING": self.having_columns,
            "SELECT": self.select_columns,
            "SET": self.set_columns,
            "GROUP BY": self.group_by_columns,
            "ORDER BY": self.order_by_columns,
        }.get(clause, self.where_columns)

    def note_reference(self, line: int, context: str, confidence: str, dynamic: bool,
                       fallback: bool = False) -> None:
        self.references += 1
        if line and (not self.first_line or line < self.first_line):
            self.first_line = line
        if not fallback:
            if self.fallback_only:
                # a real parse supersedes the LOW confidence of a fallback scan
                self.confidence = confidence
            else:
                self.confidence = self.better_of(self.confidence, confidence)
            self.fallback_only = False
        if dynamic:
            self.dynamic = True
        elif not fallback:
            self.static = True
        _add_unique(self.contexts, context)

    @staticmethod
    def better_of(a: str, b: str) -> str:
        # identification confidence: one clean static reference is enough
        return a if Confidence.rank(a) <= Confidence.rank(b) else b
