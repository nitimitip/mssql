"""WHERE / HAVING / MERGE WHEN filter records."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List

from .common import ColumnRef, condition_key


@dataclass
class FilterCondition:
    clause: str                       # WHERE | HAVING | MERGE WHEN
    column: ColumnRef
    operator: str
    compared_with: str = ""
    original: str = ""
    context: str = ""
    line: int = 0
    notes: str = ""
    dynamic: bool = False
    occurrences: int = 1
    # Whole WHERE / HAVING / WHEN condition this predicate belongs to, and the
    # AND / OR / NOT groups from the outermost condition down to it, e.g.
    # "AND > OR" for b in ``a = 1 AND (b = 2 OR c = 3)``. Empty logic = the
    # predicate is the whole condition.
    full_condition: str = ""
    logic: str = ""
    # Every statement context the (deduplicated) condition was found in.
    locations: List[str] = field(default_factory=list)

    @property
    def confidence(self) -> str:
        return self.column.confidence

    def dedupe_key(self):
        # Identifiers compare case-insensitively; literal values do not
        # (Name = 'abc' and Name = 'ABC' differ under case-sensitive collations).
        return (self.clause, self.column.table_display.upper(), self.column.column.upper(),
                self.operator, condition_key(self.compared_with), self.logic,
                condition_key(self.full_condition))
