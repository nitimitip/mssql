"""Per-procedure analysis result."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from .common import ColumnRef, Confidence, ObjectType
from .filter_usage import FilterCondition
from .join_usage import JoinCondition
from .performance import AccessRecord, PerfFinding
from .table_usage import TableUsage


class Status:
    SUCCESS = "SUCCESS"
    PARTIAL = "PARTIAL"
    MANUAL_REVIEW = "MANUAL REVIEW REQUIRED"
    FAILED = "FAILED"


class Severity:
    INFO = "INFO"           # informational, does not change status
    WARNING = "WARNING"     # -> PARTIAL
    MANUAL = "MANUAL"       # -> MANUAL REVIEW REQUIRED
    ERROR = "ERROR"         # -> FAILED


class IssueType:
    DYNAMIC_SQL = "Dynamic SQL"
    AMBIGUOUS_COLUMN = "Ambiguous Column"
    UNRESOLVED_REFERENCE = "Unresolved Reference"
    UNSUPPORTED_SYNTAX = "Unsupported Syntax"
    PARSING_FAILURE = "Parsing Failure"
    ENCODING_ERROR = "Encoding Error"
    MISSING_SP_DEFINITION = "Missing SP Definition"
    RECURSIVE_CTE = "Recursive CTE"
    LINEAGE = "Incomplete Lineage"
    INTERNAL_ERROR = "Internal Analyzer Error"
    DUPLICATE_PROCEDURE = "Duplicate Procedure"
    OTHER = "Other"


@dataclass
class AnalysisIssue:
    severity: str
    issue_type: str
    description: str
    line: int = 0


@dataclass
class UnresolvedColumn:
    clause: str
    ref: ColumnRef
    context: str = ""
    line: int = 0


@dataclass
class DynamicSqlRecord:
    line: int
    form: str                 # EXEC() | sp_executesql | EXEC @proc
    expression: str
    resolution: str           # "Analyzed (static text)" | "Manual review" | ...
    variants: int = 0
    notes: str = ""


@dataclass
class ProcedureAnalysis:
    source_file: str
    name: str
    schema: Optional[str] = None
    database: Optional[str] = None
    status: str = Status.SUCCESS
    confidence: str = Confidence.HIGH
    tables: Dict[Tuple, TableUsage] = field(default_factory=dict)
    joins: List[JoinCondition] = field(default_factory=list)
    filters: List[FilterCondition] = field(default_factory=list)
    unresolved: List[UnresolvedColumn] = field(default_factory=list)
    issues: List[AnalysisIssue] = field(default_factory=list)
    dynamic_sql: List[DynamicSqlRecord] = field(default_factory=list)
    procedures_called: List[str] = field(default_factory=list)
    functions_called: List[str] = field(default_factory=list)
    parameters: List[str] = field(default_factory=list)
    statements_total: int = 0
    statements_failed: int = 0
    line: int = 0
    elapsed_seconds: float = 0.0
    sheet_name: str = ""      # assigned by the report writer
    # Fingerprint of the definition (tokens after the name; comments, spacing
    # and keyword case ignored) used to tell identical duplicate copies apart.
    definition_hash: str = ""
    # "file (line N)" of other copies of the same procedure, set by
    # reports.summary_builder.mark_duplicate_procedures.
    also_defined_in: List[str] = field(default_factory=list)
    # Performance review (kept apart from issues / status on purpose).
    perf_findings: List[PerfFinding] = field(default_factory=list)
    access_records: List[AccessRecord] = field(default_factory=list)
    statement_ids_assigned: int = 0

    @property
    def full_name(self) -> str:
        parts = [p for p in (self.database, self.schema) if p]
        parts.append(self.name)
        return ".".join(parts)

    @property
    def dynamic_sql_detected(self) -> bool:
        return bool(self.dynamic_sql)

    @property
    def manual_review_required(self) -> bool:
        return self.status == Status.MANUAL_REVIEW

    def usages_of(self, *types: str) -> List[TableUsage]:
        return [u for u in self.tables.values() if u.obj.object_type in types]

    @property
    def physical_tables(self) -> List[TableUsage]:
        return [u for u in self.tables.values()
                if u.obj.is_database_object and not u.fallback_only]

    @property
    def temp_tables(self) -> List[TableUsage]:
        return self.usages_of(*ObjectType.TEMP_OBJECTS)

    @property
    def table_variables(self) -> List[TableUsage]:
        return self.usages_of(ObjectType.TABLE_VARIABLE)

    @property
    def warning_count(self) -> int:
        return sum(1 for i in self.issues if i.severity != Severity.INFO)
